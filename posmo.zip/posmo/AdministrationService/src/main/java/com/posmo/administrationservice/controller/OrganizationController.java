package com.posmo.administrationservice.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.dto.OrganizationIntegrationDto;
import com.posmo.administrationservice.exceptions.ErrorHandler;
import com.posmo.administrationservice.exceptions.IntegrationNotFoundException;
import com.posmo.administrationservice.exceptions.OrganizationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.OrganizationIntegrationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.OrganizationNotFoundException;
import com.posmo.administrationservice.service.OrganizationService;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/organization")
@CrossOrigin("*")
public class OrganizationController {
	@Autowired
	private OrganizationService organizationService;


	@Operation(summary = "Add New Organization")
	@PostMapping
	public ResponseEntity<?> addOrganization(@RequestBody OrganizationDto organizationDto){
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<>(organizationService.addOrganization(organizationDto), HttpStatus.OK);

		} catch (OrganizationAlreadyExistsException e) {
			response = new ResponseEntity<OrganizationNotFoundException>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		catch (Exception e) {
			response = new ResponseEntity<Exception>(new Exception(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Operation(summary = "update organization details")
	@PutMapping
	public ResponseEntity<?> updateOrganization(@RequestBody OrganizationDto organizationDto){
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<OrganizationDto>(organizationService.editOrganization(organizationDto), HttpStatus.OK);
			
		} catch (OrganizationNotFoundException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<OrganizationNotFoundException>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Operation(summary = "get organization integrations")
	@GetMapping("/organizationintegrations")
	public ResponseEntity<?> getOrganizationIntegrations(@RequestParam UUID organizationId){
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<List<OrganizationIntegrationDto>>(organizationService.getOrganizationIntegrations(organizationId), HttpStatus.OK);
			
		} catch (OrganizationNotFoundException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<OrganizationNotFoundException>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@Operation(summary = "edit organization integration status with id and integrationStatus")
	@PutMapping("/editOrganizationintegration")
	public ResponseEntity<?> editIntegrationStatus(@RequestParam UUID id, @RequestParam boolean integrationStatus,@RequestParam String integrationCredentials) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<OrganizationIntegrationDto>(
					organizationService.editIntegrationStatus(id, integrationStatus,integrationCredentials), HttpStatus.OK);

		} catch (IntegrationNotFoundException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<IntegrationNotFoundException>(
					new IntegrationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@Operation(summary = "add organization integrations")
	@PostMapping("/organizationintegrations")
	public ResponseEntity<?> addOrganizationIntegrations(@RequestBody OrganizationDto organizationDto){
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<OrganizationDto>(organizationService.addOrganizationIntegrations(organizationDto), HttpStatus.OK);

		} catch (OrganizationIntegrationAlreadyExistsException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<OrganizationIntegrationAlreadyExistsException>(new OrganizationIntegrationAlreadyExistsException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Operation(summary = "get organization details by client Id")
	@GetMapping("/organizations")
	public ResponseEntity<?> getOrganizationDetails(@RequestParam UUID clientId) {

		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<List<OrganizationDto>>(organizationService.getOrganizationDetails(clientId), HttpStatus.OK);
		} catch (OrganizationNotFoundException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<OrganizationNotFoundException>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Operation(summary = "get all organization details")
	@GetMapping("/organizations/list")
	public ResponseEntity<?> getOrganizations() {

		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<List<OrganizationDto>>(organizationService.getOrganizationDetails(), HttpStatus.OK);
		} catch (OrganizationNotFoundException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<OrganizationNotFoundException>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@Operation(summary = "get all organization details pagewise")
	@GetMapping("/allorganizations")
	public ResponseEntity<?> getAllOrganizations(int limit, int pageNo) {

		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<List<OrganizationDto>>(organizationService.getAllOrganizations(limit,pageNo), HttpStatus.OK);
		} catch (OrganizationNotFoundException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<OrganizationNotFoundException>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Operation(summary = "get organization details")
	@GetMapping("/{organizationId}")
	public ResponseEntity<?> getOrganizationById(@PathVariable UUID organizationId) {

		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<>(organizationService.getOrganizationById(organizationId), HttpStatus.OK);
		} catch (OrganizationNotFoundException e) {
			System.out.println("organization not found");
			response = new ResponseEntity<>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	@Operation(summary = "add organization to user")
    @PostMapping("/addorganizationtouser")
    public ResponseEntity<?> addOrganizationsToUser(@RequestParam UUID userId, @RequestBody List<UUID> organizationIds){
        ResponseEntity<?> response;
        try {
          response = new ResponseEntity<String>(organizationService.addOrganizationsToUser(userId, organizationIds), HttpStatus.OK);

        } catch (Exception e) {
            response = new ResponseEntity<String>("organization could not be added", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
	
	
	@Operation(summary = "update organization and user connections")
    @PutMapping("/addorganizationtouser")
    public ResponseEntity<?> updateUserOrganizationConnections(@RequestParam UUID userId, @RequestBody List<UUID> organizationIds){
        ResponseEntity<?> response;
        try {
          response = new ResponseEntity<String>(organizationService.updateUserOrganizationConnections(userId, organizationIds), HttpStatus.OK);

        } catch (Exception e) {
            response = new ResponseEntity<String>("organization could not be added", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
	
	@Operation(summary = "delete organization")
	@DeleteMapping
	public ResponseEntity<?> deleteOrganization(@RequestParam UUID organizationId){
		
		ResponseEntity<?> response;
		
		try {
			
			response = new ResponseEntity<String>(organizationService.deleteOrganization(organizationId), HttpStatus.OK);

		} catch (OrganizationNotFoundException e) {
			
			response = new ResponseEntity<OrganizationNotFoundException>(new OrganizationNotFoundException(e.getMessage()), HttpStatus.BAD_REQUEST);
		
		}
		
		return response;
	}
	
	@Operation(summary = "set organization Pin")
	@PatchMapping("/setorganizationpin")
	@ResponseBody
	public ResponseEntity<?> addPOSMOTeamPin(@RequestParam UUID clientId,@RequestParam UUID organizationId,@RequestParam String pin) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<Object>(organizationService.setOrganizationPin(clientId, organizationId, pin), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<ErrorHandler>( new ErrorHandler(HttpStatus.BAD_REQUEST.value(), e.getMessage()), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}
	
	@Operation(summary = "edit organization Pin")
	@PatchMapping("/editorganizationpin")
	@ResponseBody
	public ResponseEntity<?> editOrganizationPin(@RequestParam UUID clientId,@RequestParam UUID organizationId,@RequestParam String oldPin, @RequestParam String newPin) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<Object>(organizationService.editOrganizationPin(clientId, organizationId, oldPin, newPin), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<ErrorHandler>( new ErrorHandler(HttpStatus.BAD_REQUEST.value(), e.getMessage()), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}
	
	@Operation(summary = "Verify organization Pin")
	@GetMapping("/verifyorganizationpin")
	@ResponseBody
	public ResponseEntity<?> verifyOrganizationPin(@RequestParam UUID organizationId,@RequestParam String pin) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<Object>(organizationService.verifyOrganizationPin(organizationId,pin), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<ErrorHandler>( new ErrorHandler(HttpStatus.BAD_REQUEST.value(), e.getMessage()), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}
	
}
