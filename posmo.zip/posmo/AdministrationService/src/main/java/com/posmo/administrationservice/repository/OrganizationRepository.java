package com.posmo.administrationservice.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.posmo.administrationservice.model.Organization;

import java.util.List;
import java.util.UUID;

@Repository
public interface OrganizationRepository extends JpaRepository<Organization, UUID> {


	@Query("select u from Organization u where u.id = :id")
	Organization findByUUID(@Param("id") UUID id);

	@Query("select u from Organization u where u.client.id = :id")
	List<Organization> findByClientUUID(@Param("id") UUID id);

	@Query("select u from Organization u ")
	List<Organization> getAllOrganizations();

    @Transactional
    @Modifying
    @Query(value="insert into user_organization values(:user_id, :organization_id)",nativeQuery = true)
    void addOrganizationToUser(@Param("user_id") UUID userId, @Param("organization_id") UUID organizationId);

    @Query(value="SELECT EXISTS(SELECT * FROM user_organization WHERE user_id = :userId and organization_id =:organizationId)",nativeQuery=true)
	boolean checkIfUserOrganizationExists(@Param("userId")UUID userId,@Param("organizationId") UUID organizationId);
    
    @Transactional
    @Modifying
    @Query(value="update organization_config set currency_id= :currencyId where organization_config_id =:organizationConfigId",nativeQuery = true)
	void saveCurrency(@Param("currencyId")UUID currencyId,@Param("organizationConfigId")UUID organizationConfigId);
    
    @Transactional
    @Modifying
    @Query(value="delete from user_organization where user_id=:user_id and organization_id=:organization_id",nativeQuery = true)
	void deleteUserOrganization(@Param("user_id") UUID userId, @Param("organization_id") UUID organizationId);

    @Query(value = "select * from organization limit :limit offset :offset", nativeQuery = true)
	List<Organization> findPagewiseOrganizations(@Param("limit")int limit, @Param("offset") int offset);
    
    @Transactional
    @Modifying
    @Query(value="delete from department where department_id=:departmentId",nativeQuery = true)
	void deleteDepartmentById(@Param("departmentId") UUID departmentId);

    @Transactional
    @Modifying
    @Query(value="delete from organization where organization_id=:organizationId",nativeQuery = true)
	void deleteOrganization( @Param("organizationId") UUID organizationId);

   

}
