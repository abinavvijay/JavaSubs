package com.posmo.administrationservice.service;

import java.util.List;
import java.util.UUID;

//import org.springframework.security.authentication.AccountStatusRestaurantDetailsChecker;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.core.restaurantdetails.RestaurantDetails;
//import org.springframework.security.core.restaurantdetails.RestaurantDetailsService;
//import org.springframework.security.core.restaurantdetails.RestaurantnameNotFoundException;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.posmo.administrationservice.dto.IntegrationDto;
import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.exceptions.IntegrationNotFoundException;
import com.posmo.administrationservice.exceptions.OrganizationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.OrganizationIntegrationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.OrganizationNotFoundException;


@Service
public interface IntegrationService {


	List<IntegrationDto> getAllIntegrations()throws IntegrationNotFoundException;
	
	IntegrationDto saveIntegration(IntegrationDto integration) throws IntegrationNotFoundException;

	IntegrationDto editIntegrationStatus(UUID id, boolean integrationStatus) throws IntegrationNotFoundException;

	boolean deleteIntegration(UUID id)throws IntegrationNotFoundException;
	
	
}
