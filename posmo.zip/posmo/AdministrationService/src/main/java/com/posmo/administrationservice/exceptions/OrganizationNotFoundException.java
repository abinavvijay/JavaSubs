package com.posmo.administrationservice.exceptions;

public class OrganizationNotFoundException extends Exception {

	public OrganizationNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrganizationNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public OrganizationNotFoundException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public OrganizationNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public OrganizationNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
