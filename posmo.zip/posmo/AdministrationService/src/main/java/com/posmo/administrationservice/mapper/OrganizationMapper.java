package com.posmo.administrationservice.mapper;


import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import com.posmo.administrationservice.dto.IntegrationDto;
import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.model.Integration;
import com.posmo.administrationservice.model.Organization;
import com.posmo.administrationservice.model.account.ClientVatInfo;



/**
 *
 * This interface converts user entities to dtos
 *
 */
@Mapper(collectionMappingStrategy = CollectionMappingStrategy.SETTER_PREFERRED)
@Component
public interface OrganizationMapper {
	OrganizationMapper mapper = Mappers.getMapper(OrganizationMapper.class);

	@Mapping(target = "vatCountryId", source = "vatInfo.country.id")
	@Mapping(target = "postalAddress.country.id", source = "postalAddress.country.id")
	@Mapping(target = "postalAddress.country.countryName", source = "postalAddress.country.countryName")
	@Mapping(target = "postalAddress.country.taxCountryCode", source = "postalAddress.country.taxCountryCode")
	@Mapping(target = "physicalAddress.country.id", source = "physicalAddress.country.id")
	@Mapping(target = "physicalAddress.country.countryName", source = "physicalAddress.country.countryName")
	@Mapping(target = "taxRegistrationNo", source = "vatInfo.taxRegistrationNo")
	@Mapping(target = "clientId", source = "client.id")
	@Mapping(target="organizationIntegrations",source="organizationIntegrations")
	@Mapping(target = "vatCountryName", source = "vatCountryName")
	@Mapping(target = "vatCountryCode", source = "vatCountryCode")
	OrganizationDto convertToOrganizationDto(Organization organization);

	Organization convertToOrganization(OrganizationDto organizationDto);

	void updateOrganization(OrganizationDto organizationDto,@MappingTarget Organization organization);


	default String toString(URI uri) {
		return uri.toString();

	}

	default URI toURI(String string) {
		URI uri = null;
		try {
			uri = new URI(string);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return uri;

	}


	List<OrganizationDto> convertToOrganizationDtoList(List<Organization> organizations);
}
