package com.posmo.administrationservice.model.enums;

public enum Gender {
MALE,FEMALE
}
