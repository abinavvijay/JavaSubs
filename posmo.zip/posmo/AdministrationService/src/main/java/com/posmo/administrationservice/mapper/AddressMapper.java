package com.posmo.administrationservice.mapper;


import com.posmo.administrationservice.dto.AddressDto;
import com.posmo.administrationservice.model.Address;
import com.posmo.administrationservice.model.Country;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.UUID;

/**
 *
 * This interface converts user entities to dtos
 *
 */
@Mapper
@Component
public abstract class AddressMapper {



    public abstract AddressDto convertToAddressDto(Address address);

    public abstract Address convertToAddress(AddressDto addressDto);

    public abstract void updateAddress(AddressDto addressDto, @MappingTarget Address address);

    public String toString(URI uri) {
        return uri.toString();

    }

    public URI toURI(String string) {
        URI uri = null;
        try {
            uri = new URI(string);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return uri;

    }
}
