package com.posmo.administrationservice.dto;

import java.util.UUID;

import com.posmo.administrationservice.model.configuration.CurrencySymbol;
import com.posmo.administrationservice.model.configuration.CurrencyType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class CurrencyDto {
	
	private UUID id;

	private CurrencyType currencyType;
	
	private CurrencySymbol symbol;
}
