package com.posmo.administrationservice.dto;

import java.util.List;
import java.util.UUID;

import javax.persistence.Column;

import com.posmo.administrationservice.model.FunctionalModule;
import com.posmo.administrationservice.model.enums.PermissionType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BusinessModuleDto {

	private UUID id;

	private String name;

	private String code;

	private String displayName;

	private List<FunctionalModuleDto> functionalModules;
	
}
