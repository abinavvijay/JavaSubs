package com.posmo.administrationservice.mapper;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import com.posmo.administrationservice.dto.IntegrationDto;
import com.posmo.administrationservice.dto.OrganizationIntegrationDto;
import com.posmo.administrationservice.model.Integration;
import com.posmo.administrationservice.model.OrganizationIntegration;

/**
 * 
 * This interface converts user entities to dtos
 *
 */
@Mapper
@Component
public interface IntegrationMapper {
	IntegrationMapper mapper = Mappers.getMapper(IntegrationMapper.class);

	List<IntegrationDto> convertToIntegrationDtoList(List<Integration> integrations);

	default String toString(URI uri) {
		return uri.toString();

	}

	default URI toURI(String string) {
		URI uri = null;
		try {
			uri = new URI(string);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return uri;

	}
	
	OrganizationIntegrationDto convertToOrganizationIntegrationDto(OrganizationIntegration organizationIntegration);
	
	OrganizationIntegration convertToOrganizationIntegrationEntity(OrganizationIntegrationDto organizationIntegrationDto);

	List<Integration> convertToIntegrationList(List<IntegrationDto> integrations);

	IntegrationDto convertToIntegrationDto(Integration integration);

	Integration convertToIntegration(IntegrationDto integrationDto);

	List<OrganizationIntegrationDto> convertToOrganizationIntegrationDtoList(
			List<OrganizationIntegration> organizationIntegrations);

	List<OrganizationIntegration> convertToOrganizationIntegrationList(
			List<OrganizationIntegrationDto> organizationIntegrationDtos);
}
