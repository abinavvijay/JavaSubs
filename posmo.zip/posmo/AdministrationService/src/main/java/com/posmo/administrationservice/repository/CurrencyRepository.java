package com.posmo.administrationservice.repository;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.posmo.administrationservice.model.configuration.Currency;

@Repository
public interface CurrencyRepository extends JpaRepository<Currency, UUID>{
@Query("select c from Currency c")
List<Currency> findUniqueCurrencyType();
        }

