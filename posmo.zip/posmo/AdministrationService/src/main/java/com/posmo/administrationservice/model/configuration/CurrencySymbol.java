package com.posmo.administrationservice.model.configuration;

public enum CurrencySymbol {
$,₹,€,£
}
