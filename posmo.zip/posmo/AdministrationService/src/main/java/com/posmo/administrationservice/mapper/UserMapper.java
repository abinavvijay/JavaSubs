package com.posmo.administrationservice.mapper;


import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.posmo.administrationservice.dto.account.user.AllUserPermissionsDto;
import com.posmo.administrationservice.dto.account.user.DetailedUserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserAddDto;
import com.posmo.administrationservice.dto.account.user.UserDetailsDto;
import com.posmo.administrationservice.dto.account.user.UserDto;
import com.posmo.administrationservice.dto.account.user.UserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserOrganizationDto;
import com.posmo.administrationservice.dto.account.user.UserPermissionDto;
import com.posmo.administrationservice.dto.account.user.UserStatusDto;
import com.posmo.administrationservice.model.Country;
import com.posmo.administrationservice.model.Feature;
import com.posmo.administrationservice.model.account.Role;
import com.posmo.administrationservice.model.account.User;
import com.posmo.administrationservice.model.account.UserPermission;
import com.posmo.administrationservice.model.enums.ERole;
import com.posmo.administrationservice.model.subscription.SubscriptionFeature;
import com.posmo.administrationservice.repository.FeatureRepository;
import com.posmo.administrationservice.repository.RoleRepository;
import com.posmo.administrationservice.repository.SubscriptionFeatureRepository;


/**
 * 
 * This interface converts user entities to dtos
 *
 */
@Mapper
@Component
public abstract class UserMapper {
	
	
	@Autowired
	protected FeatureRepository featureRepository;
	
	@Autowired
	protected RoleRepository roleRepository;
	
	@Autowired
	protected SubscriptionFeatureRepository subscriptionFeatureRepository;
	

	public abstract AllUserPermissionsDto convertToAllUserPermissionsDto(User user);

	public abstract UserDto convertToUserDto(User user);
	
	public abstract User convertToUser(UserDto userDto);


	public abstract UserInfoDto convertToUserInfoDto(User user);

	public abstract User convertUserInfoToUser(UserInfoDto userInfoDto);
	
	public abstract DetailedUserInfoDto convertToDetailedUserInfoDto(User user);

	public abstract User convertDetailedUserInfoToUser(DetailedUserInfoDto detailedUserInfoDto);
	
	@Mapping(target ="accountStatus", source="account.accountStatus")
	@Mapping(target ="accountSubscriptionStatus", source="accountSubscription.status")
	public abstract UserStatusDto convertToUserStatusDto(User user);
	
	
	public abstract UserOrganizationDto convertToUserOrganizationDto(User user);
	
	public abstract UserDetailsDto convertToUserDetailsDto(User user);

	public abstract User convertUserOrganizationDtoToUser(UserOrganizationDto userOrganizationDto);
	
	public abstract void updateUser(UserDto userDto,@MappingTarget User user);

	String toString(Country country) {
		if(country!=null) {
		return country.getCountryName();
		}
		return null;
	}
	
	String toString(URI uri) {
		if(uri!=null) {
			return uri.toString();
		}
		return null;
		
	}
	
	URI toURI(String string) {
		URI uri = null;
		try {
			uri = new URI(string);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return uri;
		
	}
	public abstract List<UserDto> convertToUserListDto(List<User> user);

	
	String toString(Feature feature) {
		if (feature!=null && feature.getFeatureCode()!=null) {
		return feature.getFeatureCode();
		}
		else return "";
	}
	
	@Mapping(target ="featureCode",source="subscriptionFeature.feature.featureCode")
	@Mapping(target ="subscriptionCode",source="subscriptionFeature.subscription.subscriptionCode")
	public abstract UserPermissionDto convertToUserPermissionDto(UserPermission userPermission);
	
	@Mapping(target ="subscriptionFeature",expression = "java(toSubscriptionFeature(userPermissionDto.getSubscriptionCode(),userPermissionDto.getFeatureCode()))")
	public abstract UserPermission convertToUserPermission(UserPermissionDto userPermissionDto);
	
	public abstract List<UserPermissionDto> convertToUserPermissionDtoList(List<UserPermission> userPermission);
	
	public abstract List<UserPermission> convertToUserPermissionList(List<UserPermissionDto> userPermissionDto);
	
	public abstract User convertUserAddDtoToUser(UserAddDto userAddDto);
	
	
	SubscriptionFeature toSubscriptionFeature(String subscriptionCode, String featureCode){
		Optional<SubscriptionFeature> subscriptionFeature = subscriptionFeatureRepository.findSubscriptionFeatureForUserPermission(subscriptionCode, featureCode);
		if(subscriptionFeature.isPresent()) {
			return subscriptionFeature.get();
		}else {
			return null;
		}
		
	}
	
	Feature toFeature(String featureCode) {
		Optional<Feature> feature=featureRepository.findByFeatureCode(featureCode);
		if(feature.isPresent()) {
			return feature.get();
		}else {
			return null;
		}
	}

	public Role ToRole(ERole name) {
	Optional<Role> role = roleRepository.findByName(name);
	if(role.isPresent()) {
		return role.get();
	}else {
		 Role newRole = new Role(UUID.randomUUID(),name,"");
		 newRole = roleRepository.save(newRole);
		 System.out.println(newRole);
		 role=roleRepository.findByName(newRole.getName());
		 return role.get();
	}
	}

	
}
