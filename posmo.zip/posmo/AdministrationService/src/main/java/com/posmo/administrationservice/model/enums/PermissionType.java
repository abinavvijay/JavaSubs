package com.posmo.administrationservice.model.enums;

public enum PermissionType {
	USER_BASED,
	ROLE_BASED
	

}
