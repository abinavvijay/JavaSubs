package com.posmo.administrationservice.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.posmo.administrationservice.model.account.Account;
import com.posmo.administrationservice.model.account.AccountSubscription;
import com.posmo.administrationservice.model.account.User;

@Repository
public interface UserRepository extends JpaRepository<User, UUID> {

	@Query("select u from User u where u.username = :username")
	User findByUsername(@Param("username") String username);

	User findByEmail(String email);
	
	@Query("select u from User u  where u.role.name = com.posmo.administrationservice.model.enums.ERole.ROLE_SUPERADMIN or u.role.name = com.posmo.administrationservice.model.enums.ERole.ROLE_ACCOUNTADMIN or u.role.name = com.posmo.administrationservice.model.enums.ERole.ROLE_ENGAGEMENTADMIN")
	List<User> findUsersForTablet();

	Boolean existsByUsername(String username);

	Boolean existsByEmail(String email);

	@Query("select u from User u where u.id = :id")
	User findByUUID(@Param("id") UUID id);

	@Modifying
	@Transactional
	@Query(value = "update \"user\" set account_id =:accountId where username = :username", nativeQuery = true)
	void updateUserAccount(@Param("accountId") UUID accountId, @Param("username") String username);

	@Modifying
	@Transactional
	@Query(value = "update \"user\" set account_subscription_id =:accountSubscriptionId where username = :username", nativeQuery = true)
	void updateUserAccountSubscription(@Param("accountSubscriptionId") UUID accountSubscriptionId,
			@Param("username") String username);


	@Modifying
	@Transactional
	@Query(value = "delete from \"user\" u using user_profile p where u.profile_id = p.profile_id and u.username=:username ", nativeQuery = true)
	void deleteByUserName(@Param("username") String username);

	@Modifying
	@Transactional
	@Query(value = "delete from user_organization where user_id=:userId", nativeQuery = true)
	void deleteUserOrganizationForUser(@Param("userId") UUID userId);

	@Query(value = "select * from \"user\" limit :limit offset :offset", nativeQuery = true)
	List<User> findPagewiseUsers(@Param("limit") int limit, @Param("offset") int offset);

	@Query("select u from User u where u.role.name= \'ROLE_SUPERADMIN\'")
	List<User> findSuperAdmins();
	
	@Modifying
	@Transactional
	@Query(value = "update \"user\"  set account_id =:accountId where user_id=:userId", nativeQuery = true)
	void saveUserAccountData(@Param("userId") UUID userId,@Param("accountId")  UUID accountId);

	@Modifying
	@Transactional
	@Query(value = "update \"user\"  set account_subscription_id =:accounSubscriptiontId where user_id=:userId", nativeQuery = true)
	void saveUserAccountSubscriptionData(@Param("userId") UUID userId,@Param("accounSubscriptiontId")  UUID accountSubscriptionId);


}
