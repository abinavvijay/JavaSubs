package com.posmo.administrationservice.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.posmo.administrationservice.dto.ProductDto;
import com.posmo.administrationservice.dto.ProductModulesAndSubCountDto;
import com.posmo.administrationservice.exceptions.ProductNotFoundException;
import com.posmo.administrationservice.mapper.ProductMapper;
import com.posmo.administrationservice.model.FunctionalModule;
import com.posmo.administrationservice.model.Product;
import com.posmo.administrationservice.repository.ProductRepository;
import com.posmo.administrationservice.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired 
	private ProductRepository productRepository;


	@Autowired 
	private ProductMapper productMapper;



	@Override
	public List<ProductDto> getAllProducts() throws ProductNotFoundException {
		List<Product> producList=productRepository.findAll();
		List<ProductDto> productDtoList=new ArrayList<>();
		if(producList!=null) {

			for(Product pr:producList) {
				ProductDto productDto = productMapper.convertToProductDto(pr);
				productDtoList.add(productDto);
			}
		}
		return productDtoList;
	}

	
	@Override
	public ProductModulesAndSubCountDto getProductModulesAndSubCount(String productCode) throws ProductNotFoundException {
		Product product=productRepository.findProductByCode( productCode);
		int count=0;
		ProductModulesAndSubCountDto countDto = new ProductModulesAndSubCountDto(); 
		countDto.setBusinessModuleCount(product.getBusinessModules().size());
		countDto.setFunctionalModuleCount(product.getBusinessModules()
				                          .stream()
				                          .mapToLong(businessModule ->businessModule.getFunctionalModules().size())
				                          .sum());	    
		countDto.setFeatureCount(product.getBusinessModules()
                .stream()
                .mapToLong(businessModule ->businessModule.getFunctionalModules()
                		.stream()
                		.mapToLong(functionalModule-> functionalModule.getFeatures().size())
                		.sum()
                		)
                .sum());	
		countDto.setSubscriptionCount(product.getSubscriptions().size());
		return countDto;
	}
}
