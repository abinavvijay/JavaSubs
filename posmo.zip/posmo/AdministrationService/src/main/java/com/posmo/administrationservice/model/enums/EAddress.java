package com.posmo.administrationservice.model.enums;

public enum EAddress {
POSTAL,
PHYSICAL
}
