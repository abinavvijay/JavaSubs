package com.posmo.administrationservice.exceptions;

public class PermissionUpdateException extends Exception {

	public PermissionUpdateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PermissionUpdateException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public PermissionUpdateException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public PermissionUpdateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PermissionUpdateException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
