package com.posmo.administrationservice.dto;

import java.util.List;
import java.util.UUID;

import com.posmo.administrationservice.dto.subscription.PricingDto;
import com.posmo.administrationservice.dto.subscription.SubscriptionFeatureDto;
import com.posmo.administrationservice.dto.subscription.SubscriptionPackageSpecificationDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductSubscriptionDto {

	private UUID id;
	private String name;
	private boolean subscriptionActive;
	private SubscriptionPackageSpecificationDto subscriptionPackageSpecification;
	private String description;
	private String subscriptionCode;
	private List<PricingDto> pricings;
}
