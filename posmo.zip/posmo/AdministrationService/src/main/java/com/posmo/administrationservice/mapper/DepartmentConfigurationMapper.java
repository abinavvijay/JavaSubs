package com.posmo.administrationservice.mapper;

import com.posmo.administrationservice.dto.configuration.DepartmentConfigurationDto;
import com.posmo.administrationservice.model.configuration.DepartmentConfiguration;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface DepartmentConfigurationMapper {


    DepartmentConfiguration convertToDepartmentConfigurationEntity(DepartmentConfigurationDto departmentConfigurationDto);
    DepartmentConfigurationDto convertToDepartmentConfigurationDto(DepartmentConfiguration departmentConfiguration);
}
