package com.posmo.administrationservice.dto.configuration;

import java.util.UUID;

import com.posmo.administrationservice.dto.CurrencyDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationConfigurationDto {

	private UUID id;

	private CurrencyDto currency;

}
