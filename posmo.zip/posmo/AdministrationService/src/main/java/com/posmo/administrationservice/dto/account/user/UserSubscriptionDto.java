package com.posmo.administrationservice.dto.account.user;

import java.util.List;
import java.util.UUID;

import com.posmo.administrationservice.dto.ProductDto;
import com.posmo.administrationservice.dto.subscription.PricingDto;
import com.posmo.administrationservice.dto.subscription.SubscriptionFeatureDto;
import com.posmo.administrationservice.dto.subscription.SubscriptionPackageSpecificationDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserSubscriptionDto {

	private UUID id;
	private String productCode;
	private String subscriptionCode;
}
