package com.posmo.administrationservice.exceptions;

public class OrganizationAlreadyExistsException extends Exception {

	public OrganizationAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrganizationAlreadyExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public OrganizationAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public OrganizationAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public OrganizationAlreadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
