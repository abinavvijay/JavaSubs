package com.posmo.administrationservice.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.posmo.administrationservice.dto.account.ClientAccountSubscriptionDto;
import com.posmo.administrationservice.dto.account.ClientAddDto;
import com.posmo.administrationservice.dto.account.ClientDetailedInfoDto;
import com.posmo.administrationservice.dto.account.ClientDto;
import com.posmo.administrationservice.exceptions.AccountSubscriptionNotFoundException;
import com.posmo.administrationservice.exceptions.ClientAccountStatusNotFoundException;
import com.posmo.administrationservice.exceptions.ClientNotFoundException;
import com.posmo.administrationservice.exceptions.PrimaryContactNotFoundException;
import com.posmo.administrationservice.exceptions.UserNotFoundException;
import com.posmo.administrationservice.mapper.AccountMapper;
import com.posmo.administrationservice.mapper.AddressMapper;
import com.posmo.administrationservice.mapper.ClientMapper;
import com.posmo.administrationservice.mapper.PrimaryContactMapper;
import com.posmo.administrationservice.mapper.UserMapper;
import com.posmo.administrationservice.model.Address;
import com.posmo.administrationservice.model.Country;
import com.posmo.administrationservice.model.account.Account;
import com.posmo.administrationservice.model.account.AccountSubscription;
import com.posmo.administrationservice.model.account.Client;
import com.posmo.administrationservice.model.account.PrimaryContact;
import com.posmo.administrationservice.model.account.User;
import com.posmo.administrationservice.model.enums.EStatus;
import com.posmo.administrationservice.model.subscription.Subscription;
import com.posmo.administrationservice.repository.AccountRepository;
import com.posmo.administrationservice.repository.AccountSubscriptionRepository;
import com.posmo.administrationservice.repository.AddressRepository;
import com.posmo.administrationservice.repository.ClientRepository;
import com.posmo.administrationservice.repository.CountryRepository;
import com.posmo.administrationservice.repository.PrimaryContactRepository;
import com.posmo.administrationservice.repository.SubscriptionRepository;
import com.posmo.administrationservice.repository.UserRepository;
import com.posmo.administrationservice.service.ClientService;
import com.posmo.administrationservice.service.UserPermissionsService;
import com.posmo.administrationservice.service.UserService;
import com.posmo.administrationservice.util.Properties;

@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	ClientRepository clientReposistory;

	@Autowired
	UserPermissionsService userPermissionsService;

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private PrimaryContactRepository primaryContactRepository;

	@Autowired
	private PrimaryContactMapper primaryContactMapper;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private AddressMapper addressMapper;

	@Autowired
	private ClientMapper clientMapper;

	@Autowired
	private AccountMapper accountMapper;
	
	@Autowired
	private UserMapper userMapper;

	@Autowired
	private UserService userService;
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;

	@Autowired
	private AccountSubscriptionRepository accountSubscriptionRepository;
	
	@Autowired
	com.posmo.administrationservice.util.EmailNotification emailNotification;
	
	@Value("${EmailDetails.loginURL}")
	private String LOGINURL;

	@Override
	public ClientDto getClientDetailsById(UUID id) {
		Client client = clientReposistory.findByUUID(id);
		System.out.println(client.getPrimaryContact());
		return clientMapper.convertToClientDto(client);
	}

	@Override
	public ClientDetailedInfoDto getClientInfoDetails(UUID id) {
		Client client = clientReposistory.findByUUID(id);
		return clientMapper.convertToClientDetailedInfoDto(client);
	}

	@Override
	public ClientDto updateClient(ClientDto clientdto) {
		Client client = clientReposistory.findByUUID(clientdto.getId());

		if (client.getAddress().getCountry().getId() != null) {
			if (!client.getAddress().getCountry().getId().equals(clientdto.getAddress().getCountry().getId())) {
				Country country = countryRepository.findByUUID(clientdto.getAddress().getCountry().getId());

				client.getAddress().setCountry(country);
			}
		}

		clientMapper.updateClient(clientdto, client);

		return clientMapper.convertToClientDto(clientReposistory.save(client));
	}
 
	@Transactional
	@Override
	public ClientDto addClient(ClientAddDto clientAddDto) throws Exception{
		PrimaryContact primaryContact = primaryContactMapper.convertToPrimaryContact(clientAddDto.getPrimaryContact());
		Country clientCountry = countryRepository.findByUUID(clientAddDto.getAddress().getCountry().getId());
		Address address = addressMapper.convertToAddress(clientAddDto.getAddress());
		address.setCountry(clientCountry);

		addressRepository.save(address);

		Client newClient = clientMapper.convertToCLientAdd(clientAddDto);
		newClient.setPrimaryContact(primaryContact);
		newClient.setAddress(address);
		newClient = clientReposistory.save(newClient);
		Account account = addClientAccount(clientAddDto);
		Optional<Account> optAccount = accountRepository.findById(account.getId());
		if (optAccount.isPresent()) {
			newClient.setAccount(optAccount.get());
			newClient = clientReposistory.save(newClient);
		}
		ClientDto response =  clientMapper.convertToClientDto(newClient);
		
		if(response != null) {
			
			String clientAdminName = newClient.getPrimaryContact().getFirstName()+ " "+ newClient.getPrimaryContact().getLastName();
			
			String clientAdminEmail = newClient.getPrimaryContact().getPrimaryContactEmail();
			
			String emailSubject="POSMO - CLIENT SETUP";
			
	        String emailBody = "Dear "+ clientAdminName + ", \n\n" + "You have been setup as an Client Admin for the Client: "+ newClient.getName()+". Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+clientAdminEmail+"\n\n"+"Pin: "+ clientAddDto.getClientPin();
//	       
	        emailNotification.sendMail(clientAdminEmail, emailSubject,emailBody, clientAdminName);
			
		}
		
		
		
		
		return response;
	}

	@Transactional
	private Account addClientAccount(ClientAddDto clientAddDto) throws UserNotFoundException {
		Account account = new Account();
		account.setAccountEmail(clientAddDto.getPrimaryContact().getPrimaryContactEmail());
		account.setClientName(clientAddDto.getName());
		account.setAccountStatus(EStatus.ACTIVE);
		String username = "";
		try {
			User user = userService.saveClientAsUser(clientAddDto);
			account.setDefaultUser(user);
			account.addMetaData(clientAddDto.getPrimaryContact().getPrimaryContactEmail());
			username = user.getUsername();

		} catch (PrimaryContactNotFoundException e) {
			account.addMetaData();
		}
		account = accountRepository.save(account);
		List<String> subscriptionCodes = new ArrayList<String>();
		subscriptionCodes.add("ERP_PRM");
		account.setAccountSubscriptions(createAccountSubscriptionsByCode(subscriptionCodes,clientAddDto.getName()));
		account = accountRepository.save(account);
		userService.saveAccountAndSubscriptionData(account.getAccountEmail(),"ERP_PRM",account.getId() );
		AccountSubscription clientAccountSubscription = accountSubscriptionRepository.getMasterAccountSubscription(account.getId());
		try {
			userPermissionsService.setAllUserPermissions(username,clientAccountSubscription.getSubscription().getSubscriptionCode());
		} catch (UserNotFoundException e) {
			e.printStackTrace();
		}
		return account;
	}


	@Override
	public List<AccountSubscription> createAccountSubscriptionsByCode(List<String> subscriptionCodes, String activatedBy) {
		List<AccountSubscription> accountSubscriptions = new ArrayList<>();
		
		for(String subscriptionCode:subscriptionCodes) {
		Optional<Subscription> subscription = subscriptionRepository.findBySubscriptionCode(subscriptionCode);
		
		if (subscription.isPresent()) {
			AccountSubscription accSubscription = new AccountSubscription(UUID.randomUUID(), subscription.get(),
					activatedBy, new Date(), new Date(), EStatus.ACTIVE);

			accountSubscriptions.add(accSubscription);

		}
		}
		return accountSubscriptions; 
	}

	@Override
	public List<ClientDetailedInfoDto> viewAllClients() {
		List<Client> clients = clientReposistory.findAll();
		List<ClientDetailedInfoDto> clientDtos = new ArrayList<ClientDetailedInfoDto>();

		for (int i = 0; i < clients.size(); i++) {
			ClientDetailedInfoDto c = clientMapper.convertToClientDetailedInfoDto(clients.get(i));

			clientDtos.add(c);

		}
		return clientDtos;
	}

	@Override
	public Client getClient(String clientName) throws ClientNotFoundException {
		Client client = clientReposistory.findByClientName(clientName);
		return client;
	}

	@Override
	public String deleteClient(UUID id) throws ClientNotFoundException {

		Client client = clientReposistory.findByUUID(id);

		clientReposistory.delete(client);

		return "Client Deleted Successfully";
	}

	@Override
	public ClientAccountSubscriptionDto getAccountSubscriptionsForClient(UUID clientId)
			throws AccountSubscriptionNotFoundException {
		
		Client client = clientReposistory.findByUUID(clientId);
		if (client!=null && client.getAccount()!=null) {
			return clientMapper.convertToAccountSubsciptionDto(client.getAccount());
		}
		else {
			throw new AccountSubscriptionNotFoundException(Properties.accountSubscriptionNotFound);
		}
	}

	@Override
	public ClientDetailedInfoDto editClientEstatus(UUID id, EStatus accountStatus)
			throws ClientAccountStatusNotFoundException {
		Client actStatus = clientReposistory.getOne(id);
		List<User> users = actStatus.getAccount().getUsers();
		actStatus.getAccount().setAccountStatus(accountStatus);
		for(User user : users){
			if (accountStatus.compareTo(EStatus.ACTIVE) == 0) {
				user.setUserStatus(EStatus.ACTIVE);
			}
			else if (accountStatus.compareTo(EStatus.INACTIVE) == 0){
				user.setUserStatus(EStatus.INACTIVE);
			}
		}
		actStatus = clientReposistory.save(actStatus);
		return clientMapper.convertToClientDetailedInfoDto(actStatus);

		}

	@Override
	public ClientDetailedInfoDto getClientDetailsByAccountId(UUID id) throws ClientNotFoundException {
		Client client = clientReposistory.findClientByAccountId(id);
		return clientMapper.convertToClientDetailedInfoDto(client);

	}

	@Override
	public ClientDetailedInfoDto viewClientByEmail(String primaryContactEmail) throws  ClientNotFoundException{
		Client client = clientReposistory.findByPrimaryEmail(primaryContactEmail);
				return clientMapper.convertToClientDetailedInfoDto(client);
	}


	
}
