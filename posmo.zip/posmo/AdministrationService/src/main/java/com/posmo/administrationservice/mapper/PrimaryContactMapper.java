package com.posmo.administrationservice.mapper;


import com.posmo.administrationservice.dto.account.PrimaryContactDto;
import com.posmo.administrationservice.model.account.PrimaryContact;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;

/**
 *
 * This interface converts user entities to dtos
 *
 */
@Mapper
(componentModel="spring")
@Component

public interface PrimaryContactMapper {

    PrimaryContactMapper mapper = Mappers.getMapper(PrimaryContactMapper.class);


    PrimaryContactDto convertToPrimaryContactDto(PrimaryContact primaryContact);

    PrimaryContact convertToPrimaryContact(PrimaryContactDto primaryContactDto);

    void updatePrimaryContact(PrimaryContactDto primaryContactDto, @MappingTarget PrimaryContact primaryContact);


    default String toString(URI uri) {
        return uri.toString();

    }

    default URI toURI(String string) {
        URI uri = null;
        try {
            uri = new URI(string);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return uri;

    }
}
