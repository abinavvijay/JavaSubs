package com.posmo.administrationservice.exceptions;

public class PrimaryContactNotFoundException extends Exception {

    public PrimaryContactNotFoundException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public PrimaryContactNotFoundException(String message, Throwable cause, boolean enableSuppression,
                                   boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }

    public PrimaryContactNotFoundException(String message, Throwable cause) {
        super(message, cause);

    }

    public PrimaryContactNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public PrimaryContactNotFoundException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
