package com.posmo.administrationservice.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.dto.OrganizationIntegrationDto;
import com.posmo.administrationservice.exceptions.IntegrationNotFoundException;
import com.posmo.administrationservice.exceptions.OrganizationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.OrganizationNotFoundException;
import com.posmo.administrationservice.exceptions.UserNotFoundException;
import com.posmo.administrationservice.exceptions.UserOrganizationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.UserOrganizationDeletionException;
import com.posmo.administrationservice.mapper.AddressMapper;
import com.posmo.administrationservice.mapper.ClientMapper;
import com.posmo.administrationservice.mapper.ContactInfoMapper;
import com.posmo.administrationservice.mapper.IntegrationMapper;
import com.posmo.administrationservice.mapper.OrganizationMapper;
import com.posmo.administrationservice.mapper.PrimaryContactMapper;
import com.posmo.administrationservice.model.Address;
import com.posmo.administrationservice.model.Country;
import com.posmo.administrationservice.model.Integration;
import com.posmo.administrationservice.model.Organization;
import com.posmo.administrationservice.model.OrganizationIntegration;
import com.posmo.administrationservice.model.account.Client;
import com.posmo.administrationservice.model.account.ClientVatInfo;
import com.posmo.administrationservice.model.account.PrimaryContact;
import com.posmo.administrationservice.model.account.User;
import com.posmo.administrationservice.model.enums.EAddress;
import com.posmo.administrationservice.repository.AddressRepository;
import com.posmo.administrationservice.repository.ClientContactInfoRepository;
import com.posmo.administrationservice.repository.ClientRepository;
import com.posmo.administrationservice.repository.ClientVatInfoRepository;
import com.posmo.administrationservice.repository.CountryRepository;
import com.posmo.administrationservice.repository.IntegrationRepository;
import com.posmo.administrationservice.repository.OrganizationIntegrationRepository;
import com.posmo.administrationservice.repository.OrganizationRepository;
import com.posmo.administrationservice.repository.PrimaryContactRepository;
import com.posmo.administrationservice.repository.UserRepository;
import com.posmo.administrationservice.service.OrganizationService;
import com.posmo.administrationservice.service.UserService;
import com.posmo.administrationservice.util.Properties;

@Service
public class OrganizationServiceImpl implements OrganizationService {

	@Autowired
	private OrganizationRepository organizationRepository;

	@Autowired
	private OrganizationIntegrationRepository organizationIntegrationRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private PrimaryContactRepository primaryContactRepository;

	@Autowired
	private ClientContactInfoRepository clientContactInfoRepository;

	@Autowired
	private ClientVatInfoRepository clientVatInfoRepository;

	@Autowired
	private IntegrationRepository integrationRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private OrganizationMapper organizationMapper;

	@Autowired
	private AddressMapper addressMapper;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	ClientRepository clientRepository;

	@Autowired
	private PrimaryContactMapper primaryContactMapper;

	@Autowired
	private ContactInfoMapper contactInfoMapper;

	@Autowired
	private ClientMapper clientMapper;

	

	@Autowired
	private IntegrationMapper integrationMapper;
	
	@Autowired
	com.posmo.administrationservice.util.EmailNotification emailNotification;
	
	@Value("${EmailDetails.loginURL}")
	private String LOGINURL;

	@Transactional
	@Override
	public OrganizationDto addOrganization(OrganizationDto organizationDto) throws OrganizationAlreadyExistsException, Exception {

		Country postalAddressCountry = null;
		Country physicalAddressCountry =null;
		Address physicalAddress = null;
		Address postalAddress = null;
		PrimaryContact primaryContact = null;
		if(organizationDto.getPostalAddress()!=null && organizationDto.getPostalAddress().getCountry() != null &&organizationDto.getPostalAddress().getCountry().getId()!=null) {
			postalAddressCountry = countryRepository.findByUUID(organizationDto.getPostalAddress().getCountry().getId());
			postalAddress = addressMapper.convertToAddress(organizationDto.getPostalAddress());
			postalAddress.setCountry(postalAddressCountry);
			System.out.println(postalAddress.getCountry());
			postalAddress.setAddressName(EAddress.POSTAL);
		}
		if(organizationDto.getPhysicalAddress()!=null && organizationDto.getPhysicalAddress().getCountry()!=null && organizationDto.getPhysicalAddress().getCountry().getId()!=null) {
			physicalAddressCountry = countryRepository
					.findByUUID(organizationDto.getPhysicalAddress().getCountry().getId());
			physicalAddress = addressMapper.convertToAddress(organizationDto.getPhysicalAddress());
			physicalAddress.setCountry(physicalAddressCountry);
			physicalAddress.setAddressName(EAddress.PHYSICAL);
		}

		if(organizationDto.getPrimaryContact() !=null) {
			primaryContact = primaryContactMapper.convertToPrimaryContact(organizationDto.getPrimaryContact());
		}


		Country clientVatCountry = countryRepository.findByUUID(organizationDto.getVatCountryId());

		ClientVatInfo vatInfo = new ClientVatInfo();
		vatInfo.setCountry(postalAddressCountry);
		vatInfo.setTaxRegistrationNo(organizationDto.getTaxRegistrationNo());

		Client client = clientRepository.findByUUID(organizationDto.getClientId());


		clientVatInfoRepository.save(vatInfo);

		Organization newOrganization = organizationMapper.convertToOrganization(organizationDto);




		newOrganization.addMetaData(newOrganization.getName());
		newOrganization.setPostalAddress(postalAddress);
		newOrganization.setPhysicalAddress(physicalAddress);
		newOrganization.setPrimaryContact(primaryContact);
		newOrganization.setVatEditableCountryId(organizationDto.getPostalId());
		newOrganization.setVatCountryCode(organizationDto.getPostalTaxCode());
		newOrganization.setVatCountryName(organizationDto.getPostalAddressCountry());
		newOrganization.setVatInfo(vatInfo);
		newOrganization.setClient(client);
		newOrganization = organizationRepository.save(newOrganization);
		addNewOrganizationIntegrations(newOrganization.getId());
		if(newOrganization.getClient()!=null && newOrganization.getClient().getAccount()!=null
				&& newOrganization.getClient().getAccount().getAccountEmail()!=null) {
			addOrganizationToDefaultUser(newOrganization.getClient().getAccount().getAccountEmail(),newOrganization.getId());
		}
		try {
			userService.addOrganizationToSuperAdmins(newOrganization.getId());
		}catch(UserNotFoundException e) {
			System.out.println("Faced issues in adding restaurant to user");
		}
		OrganizationDto response = organizationMapper.convertToOrganizationDto(newOrganization);
		
		if(response != null) {
			
			Client organizationClient = newOrganization.getClient();
			
			String clientAdminName = organizationClient.getPrimaryContact().getFirstName()+ " "+ organizationClient.getPrimaryContact().getLastName();
			
			String clientAdminEmail = organizationClient.getPrimaryContact().getPrimaryContactEmail();
			
			String emailSubject="ROS - Restaurant SetUp";
			
	        String emailBody = "Dear "+ clientAdminName + ", \n\n" + "Restaurant: "+newOrganization.getName() +" have been setup for the Client: "+ organizationClient.getName()+". Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+clientAdminEmail+"\n\n";
	       
	        emailNotification.sendMail(clientAdminEmail, emailSubject,emailBody, clientAdminName);
			
		}
		
		return response;
	}


	private void addOrganizationToDefaultUser(String accountEmail,UUID organizationId) {
		User user = userRepository.findByUsername(accountEmail);
		organizationRepository.addOrganizationToUser(user.getId(), organizationId);

	}

	@Transactional
	private void updateOrganizationIntegrations(UUID organizationId) {
		List<Integration> integrations = integrationRepository.findAllIntegrations();
		Organization organization = organizationRepository.findByUUID(organizationId);
		List<OrganizationIntegration> organizationIntegrations = new ArrayList();
		if (organization.getOrganizationIntegrations() != null && organization.getOrganizationIntegrations().size() != 0) {
			organizationIntegrations = organization.getOrganizationIntegrations();
			for (Integration integration : integrations) {
				if (!organizationIntegrationRepository.checkifIntegrationExists(integration.getId(), organizationId)) {
					organizationIntegrations.add(CreateOrganizationIntegrationFromIntegration(integration));
				}
			}
			organization.setOrganizationIntegrations(organizationIntegrations);
			organizationIntegrationRepository.saveAll(organizationIntegrations);
		} else {
			addNewOrganizationIntegrations(organizationId);
		}

	}

	private void addNewOrganizationIntegrations(UUID organizationId) {
		List<Integration> integrations = integrationRepository.findAllIntegrations();
		Organization organization = organizationRepository.findByUUID(organizationId);
		List<OrganizationIntegration> organizationIntegrations = new ArrayList();
		for (Integration integration : integrations) {
			organizationIntegrations.add(CreateOrganizationIntegrationFromIntegration(integration));
		}
		organization.setOrganizationIntegrations(organizationIntegrations);
		organizationIntegrationRepository.saveAll(organizationIntegrations);
	}

	@Transactional
	private OrganizationIntegration CreateOrganizationIntegrationFromIntegration(Integration integration) {
		OrganizationIntegration organizationIntegration = new OrganizationIntegration();
		organizationIntegration.setId(UUID.randomUUID());
		organizationIntegration.setIntegration(integration);
		organizationIntegration.setIntegrationStatus(false);
		organizationIntegration.setIntegrationCredentials("");
		organizationIntegration.addMetaData();
		return organizationIntegrationRepository.save(organizationIntegration);
	}

	@Override
	public OrganizationDto findByUUID(UUID organizationUUID) {
		return null;
	}

	@Override
	public String deleteOrganization(UUID organizationUUID) throws OrganizationNotFoundException {

		Organization organization = organizationRepository.findByUUID(organizationUUID);

		organizationRepository.delete(organization);

		return "Organization Deleted Successfully";
	}

	@Override
	public OrganizationIntegrationDto editIntegrationStatus(UUID id, boolean integrationStatus,String integrationCredentials)
			throws IntegrationNotFoundException {

		OrganizationIntegration organizationIntegration = organizationIntegrationRepository.getOne(id);
		organizationIntegration.setIntegrationStatus(integrationStatus);
		organizationIntegration.setIntegrationCredentials(integrationCredentials);
		organizationIntegration = organizationIntegrationRepository.save(organizationIntegration);
		return integrationMapper.convertToOrganizationIntegrationDto(organizationIntegration);
	}

	@Override
		public OrganizationDto editOrganization(OrganizationDto organizationDto) throws OrganizationNotFoundException {
		Organization organization =  organizationRepository.findByUUID(organizationDto.getId());
		System.out.println(organization.getClient().getId());

		if (organization.getClient() != null && organizationDto.getClientId() != null
				&& !organization.getClient().getId().equals(organizationDto.getClientId())) {
			Client client = clientRepository.findByUUID(organizationDto.getClientId());
			organization.setClient(client);
		}
		if (organization.getVatInfo().getCountry() != null && organization.getVatInfo().getCountry().getId() != null) {
			if (!organization.getVatInfo().getCountry().getId().equals(organizationDto.getVatCountryId())) {
				Country clientVatCountry = countryRepository.findByUUID(organizationDto.getVatCountryId());

				organization.getVatInfo().setCountry(clientVatCountry);
				organization.getVatInfo().setTaxRegistrationNo(organizationDto.getTaxRegistrationNo());
			}
			if (organization.getVatInfo().getCountry().getId().equals(organizationDto.getVatCountryId())) {
				organization.getVatInfo().setTaxRegistrationNo(organizationDto.getTaxRegistrationNo());
			}
		}
		updateOrganizationIntegrations(organization.getId());

		System.out.println(organizationDto.getPostalAddressCountry());

		organizationDto.setVatEditableCountryId((organizationDto.getPostalId()));
		organizationDto.setVatCountryName(organizationDto.getPostalAddressCountry());
		organizationDto.setVatCountryCode(organizationDto.getPostalTaxCode());

		System.out.println(organization.getVatCountryName());

		System.out.println("here");


		organizationMapper.updateOrganization(organizationDto, organization);
		return organizationMapper.convertToOrganizationDto(organizationRepository.save(organization));
		}


	@Override
	public OrganizationDto addOrganizationIntegrations(OrganizationDto organizationDto) {
		Organization organization;
		Optional<Organization> optOrganization = organizationRepository.findById(organizationDto.getId());
		if (optOrganization.isPresent()) {
			organization = organizationRepository.save(organizationMapper.convertToOrganization(organizationDto));

		} else {
			organization = optOrganization.get();
			organization = organizationRepository.save(organization);
		}

		return organizationMapper.convertToOrganizationDto(organization);

	}

	@Override
	public List<OrganizationIntegrationDto> getOrganizationIntegrations(UUID organizationId)
			throws OrganizationNotFoundException {
		Organization organization = organizationRepository.findByUUID(organizationId);
		return integrationMapper.convertToOrganizationIntegrationDtoList(organization.getOrganizationIntegrations());

	}

	@Override
	public List<OrganizationDto> getOrganizationDetails(UUID clientId) {
		List<Organization> organization = organizationRepository.findByClientUUID(clientId);
		return organizationMapper.convertToOrganizationDtoList(organization);
	}

	@Override
	public List<OrganizationDto> getOrganizationDetails() {
		List<Organization> organization = organizationRepository.getAllOrganizations();
		return organizationMapper.convertToOrganizationDtoList(organization);
	}

	@Override
	public OrganizationDto getOrganizationById(UUID id) {
		Organization organization = organizationRepository.findByUUID(id);
		return organizationMapper.convertToOrganizationDto(organization);
	}

	@Transactional
	@Override
	public String addOrganizationToUser(UUID userId, UUID organizationId)
			throws UserOrganizationAlreadyExistsException, OrganizationNotFoundException {
		if (organizationRepository.findByUUID(organizationId) != null) {
			if (!organizationRepository.checkIfUserOrganizationExists(userId, organizationId)) {

				organizationRepository.addOrganizationToUser(userId, organizationId);
				return Properties.userOrganizationsSuccessful;

			} else {
				throw new UserOrganizationAlreadyExistsException(Properties.userOrganizationAlreadyExists + " : "
						+ organizationId + " and user id : " + userId + "\n");
			}
		} else {
			throw new OrganizationNotFoundException(Properties.organizationNotFound + " : " + organizationId + "\n");
		}
	}

	@Transactional
	@Override
	public String addOrganizationsToUser(UUID userId, List<UUID> organizationIds) {
		String errorDefault = "Faced errors in following : \n";

		String error = new String(errorDefault);

		for (UUID organizationId : organizationIds) {
			try {
				this.addOrganizationToUser(userId, organizationId);
			} catch (UserOrganizationAlreadyExistsException e) {
				System.out.println(e.getMessage());
				error = error + e.getMessage();
			} catch (OrganizationNotFoundException e) {
				System.out.println(e.getMessage());
				error = error + e.getMessage();
			}
		}

		if (error.equalsIgnoreCase(errorDefault)) {
			return Properties.userOrganizationsSuccessful;
		} else {
			return error;
		}
	}

	@Override
	public String updateUserOrganization(UUID userId, UUID organizationId)
			throws UserOrganizationAlreadyExistsException, OrganizationNotFoundException {
		if (organizationRepository.findByUUID(organizationId) != null) {
			if (!organizationRepository.checkIfUserOrganizationExists(userId, organizationId)) {

				organizationRepository.addOrganizationToUser(userId, organizationId);
				return Properties.userOrganizationsSuccessful;

			} else {
				throw new UserOrganizationAlreadyExistsException(Properties.userOrganizationAlreadyExists + " : "
						+ organizationId + " and user id : " + userId + "\n");
			}
		} else {
			throw new OrganizationNotFoundException(Properties.organizationNotFound + " : " + organizationId + "\n");
		}
	}

	@Override
	public String updateUserOrganizationConnections(UUID userId, List<UUID> organizationIds){
		String errorDefault = "Faced errors in following : \n";
		String error = new String(errorDefault);

		User user = userRepository.getById(userId);
		Set<Organization> organizations = new HashSet();
		if(user.getOrganizations()!=null) {
			organizations=user.getOrganizations();
			try {
				organizations= deleteUserOrganizations(userId,organizations,organizationIds);
			}catch(UserOrganizationDeletionException e) {
				error = error + Properties.userOrganizationDeletionFailed;
			}

		}
		for (UUID organizationId : organizationIds) {
			if(organizations.stream().anyMatch(organization -> organization.getId().equals(organizationId))) {
				System.out.println("id matches existing object");
			}
			else {
				try {
					this.addOrganizationToUser(userId, organizationId);
				} catch (UserOrganizationAlreadyExistsException e) {

				} catch (OrganizationNotFoundException e) {
					System.out.println(e.getMessage());
					error = error + e.getMessage();
				}
			}
		}

		if (error.equalsIgnoreCase(errorDefault)) {
			return Properties.userOrganizationsSuccessful;
		} else {
			return error;
		}
	}

	private Set<Organization> deleteUserOrganizations(UUID userId, Set<Organization> organizations, List<UUID> organizationIds) throws UserOrganizationDeletionException{
		for(Organization organization : organizations) {
			if(organizationIds.stream().noneMatch(organizationId -> organization.getId().equals(organizationId))) {
				System.out.println("removing "+organization.getName());
				organizations.remove(organization);
				organizationRepository.deleteUserOrganization(userId,organization.getId());
			}
		}
		return organizations;
	}

	@Override
	public List<OrganizationDto> getAllOrganizations(int limit, int pageNo) throws OrganizationNotFoundException {
		List<Organization> organization = organizationRepository.findPagewiseOrganizations(limit,pageNo*limit);
		return organizationMapper.convertToOrganizationDtoList(organization);
	}


	@Override
	public String setOrganizationPin(UUID clientId, UUID organizationId, String pin) throws Exception {


		List<Organization> organizations = organizationRepository.findByClientUUID(clientId);
		
		boolean duplicatePinCheck = false;
		
		for(Organization organization: organizations) {
			
			if(organization.getOrganizationPinHash() != null && ! duplicatePinCheck) {
				
				if (BCrypt.checkpw(pin, organization.getOrganizationPinHash()))
					duplicatePinCheck = true;
				
			}
			
		}
		
		if(duplicatePinCheck)
			throw new Exception("Please select a unique Pin for the Organization!");
		
		else {
			
			Organization org = organizationRepository.getById(organizationId);
			
			if(org == null)
				throw new Exception("Organization with Organization id: "+ organizationId + " doesnot exists!");

			
			org.setOrganizationPinHash(BCrypt.hashpw(pin, BCrypt.gensalt()));
			
			org.setTabletValidation(false);
			
			organizationRepository.save(org);
			
			Client organizationClient = org.getClient();
			
			String clientAdminName = organizationClient.getPrimaryContact().getFirstName()+ " "+ organizationClient.getPrimaryContact().getLastName();
			
			String clientAdminEmail = organizationClient.getPrimaryContact().getPrimaryContactEmail();
			
			String emailSubject="POSMO - ORGANIZATION PIN SETUP";
			
	        String emailBody = "Dear "+ clientAdminName + ", \n\n" + "Restaurant: "+org.getName() +" pin has been set successfuly for the Client: "+ organizationClient.getName()+". Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+clientAdminEmail+"\n\n+"+"Pin: "+pin;
	       
	        emailNotification.sendMail(clientAdminEmail, emailSubject,emailBody, clientAdminName);
			
			return "Pin Set successfully for Organization: "+ org.getName();
		}
		

	}


	@Override
	public String editOrganizationPin(UUID clientId, UUID organizationId, String oldPin, String newPin) throws Exception {
		Organization org = organizationRepository.getById(organizationId);
		
		if(org == null)
			throw new Exception("Organization with Organization id: "+ organizationId + " doesnot exists!");
		
		if(org.getOrganizationPinHash() == null)
			throw new Exception("Organization Pin for Organization id: "+ organizationId + " doesnot exists!");
		
		if(org.getOrganizationPinHash() != null && ! (BCrypt.checkpw(oldPin, org.getOrganizationPinHash())))
			throw new Exception("Old Pin doesnot Match!!");
		
		else {
			
			List<Organization> organizations = organizationRepository.findByClientUUID(clientId);
			
			boolean duplicatePinCheck = false;
			
			for(Organization organization: organizations) {
				
				if(organization.getOrganizationPinHash() != null && ! duplicatePinCheck) {
					
					if (BCrypt.checkpw(newPin, organization.getOrganizationPinHash()))
						duplicatePinCheck = true;
					
				}
				
			}
			
			if(duplicatePinCheck)
				throw new Exception("Please select a unique Pin for the Organization!");
			
			else {
			
			org.setOrganizationPinHash(BCrypt.hashpw(newPin, BCrypt.gensalt()));
			
			org.setTabletValidation(false);
			
			organizationRepository.save(org);
			
			Client organizationClient = org.getClient();
			
			String clientAdminName = organizationClient.getPrimaryContact().getFirstName()+ " "+ organizationClient.getPrimaryContact().getLastName();
			
			String clientAdminEmail = organizationClient.getPrimaryContact().getPrimaryContactEmail();
			
			String emailSubject="POSMO - ORGANIZATION PIN CHANGE";
			
	        String emailBody = "Dear "+ clientAdminName + ", \n\n" + "Organization: "+org.getName() +" pin has been changed successfuly for the Client: "+ organizationClient.getName()+". Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+clientAdminEmail+"\n\n+"+"New Pin: "+newPin;
	       
	        emailNotification.sendMail(clientAdminEmail, emailSubject,emailBody, clientAdminName);
			
			return "Pin updated successfully for Organization: "+ org.getName();
			
			}
		}
		
	}


	@Override
	public String verifyOrganizationPin(UUID organizationId, String pin) throws Exception {
		
		Organization org = organizationRepository.getById(organizationId);
		
		if(org == null)
			throw new Exception("Organization with Organization id: "+ organizationId + " doesnot exists!");
		
		if(org.getOrganizationPinHash() == null)
			throw new Exception("Organization Pin for Organization: "+ org.getName() + " doesnot exists!");
		
		if(BCrypt.checkpw(pin, org.getOrganizationPinHash())) {
			
			org.setTabletValidation(true);
			
			organizationRepository.save(org);

			return  "Organization Validated Successfully";
		}
		else
			return  "Organization Validated Failed, Please enter the correct Pin for Organization: "+ org.getName();

	}

}
