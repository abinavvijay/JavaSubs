package com.posmo.administrationservice.util;

public class Properties {

	public static String subscriptionNotFound = "Subscription not found";
	
	public static String azureUserNotCreated = "Azure user not created";
	
	public static String azureUserAlreadyExists = "Azure user Already Exists";
	
	public static String azureErrorMessage = "Another object with the same value for property userPrincipalName already exists.";
	
	public static String userDeleted = "User Doesn't Exist";
	
	public static String userNotFound = "User not found";
	
	public static String allSubscriptionsSaved = "Subscription Features set successfully";
	
	public static String userOrganizationAlreadyExists = "user Organization Already Exists for organization id ";
	
	public static String organizationNotFound = "Organization not for organization id ";
	
	public static String userOrganizationsSuccessful ="Organizations successufully added to the user";
	
	public static String userOrganizationDeletionFailed ="User Organization connection could not be removed";

	public static String subscriptionAlreadyExists = "Subscription already exists with given subscription code ";

	public static String accountSubscriptionNotFound = "Account subscription not found for client "; 
}
