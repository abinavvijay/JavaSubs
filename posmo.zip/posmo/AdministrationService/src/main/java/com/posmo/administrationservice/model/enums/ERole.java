package com.posmo.administrationservice.model.enums;

public enum ERole {
	ROLE_SUPERADMIN,
	ROLE_ENGAGEMENTADMIN,
	ROLE_ACCOUNTADMIN,
	ROLE_ACCOUNTMANAGER,
	ROLE_CONSULTANT
	
}