package com.posmo.administrationservice.model.enums;

public enum IntegrationType {
	POS,
	DELIVERY,
	PAYMENT

}
