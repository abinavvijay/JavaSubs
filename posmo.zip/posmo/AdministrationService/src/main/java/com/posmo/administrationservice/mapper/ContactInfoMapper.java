package com.posmo.administrationservice.mapper;

import com.posmo.administrationservice.dto.account.ContactInfoDto;
import com.posmo.administrationservice.model.account.ContactInfo;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;

/**
 *
 * This interface converts user entities to dtos
 *
 */
@Mapper
(componentModel="spring")
@Component
public interface ContactInfoMapper {

    ContactInfoMapper mapper = Mappers.getMapper(ContactInfoMapper.class);


    ContactInfoDto convertToContactInfoDto(ContactInfo contactInfo);

    ContactInfo convertToContactInfo(ContactInfoDto contactInfoDto);

    void updateContactInfo(ContactInfoDto contactInfoDto, @MappingTarget ContactInfo contactInfo);


    default String toString(URI uri) {
        return uri.toString();

    }

    default URI toURI(String string) {
        URI uri = null;
        try {
            uri = new URI(string);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return uri;

    }
}
