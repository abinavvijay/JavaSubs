package com.posmo.administrationservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.posmo.administrationservice.dto.ProductDto;
import com.posmo.administrationservice.dto.ProductModulesAndSubCountDto;
import com.posmo.administrationservice.exceptions.ProductNotFoundException;

@Service
public interface ProductService {

	List<ProductDto> getAllProducts() throws ProductNotFoundException;

	ProductModulesAndSubCountDto getProductModulesAndSubCount(String productCode) throws ProductNotFoundException;
}
