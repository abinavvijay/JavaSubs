package com.posmo.administrationservice.dto.account;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.posmo.administrationservice.dto.ProductDto;
import com.posmo.administrationservice.dto.subscription.SubscriptionDto;
import com.posmo.administrationservice.model.Product;
import com.posmo.administrationservice.model.account.Account;
import com.posmo.administrationservice.model.account.Role;
import com.posmo.administrationservice.model.account.User;
import com.posmo.administrationservice.model.account.UserPermission;
import com.posmo.administrationservice.model.enums.EStatus;
import com.posmo.administrationservice.model.subscription.Subscription;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AccountSubscriptionDto {
	private SubscriptionDto subscription;
	private String activatedBy;
	private Date activatedDate;
	private Date expiryDate;
	private EStatus status;
	
}
