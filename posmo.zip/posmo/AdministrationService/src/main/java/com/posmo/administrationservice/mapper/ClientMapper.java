package com.posmo.administrationservice.mapper;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.posmo.administrationservice.dto.account.ClientAccountSubscriptionDto;
import com.posmo.administrationservice.dto.account.ClientAddDto;
import com.posmo.administrationservice.dto.account.ClientDetailedInfoDto;
import com.posmo.administrationservice.dto.account.ClientDto;
import com.posmo.administrationservice.model.Country;
import com.posmo.administrationservice.model.Feature;
import com.posmo.administrationservice.model.account.Account;
import com.posmo.administrationservice.model.account.Client;
import com.posmo.administrationservice.repository.FeatureRepository;

@Mapper
@Component
public abstract class ClientMapper {

	@Autowired
	protected FeatureRepository featureRepository;


	@Mapping(target = "address.country.id", source = "address.country.id")
	@Mapping(target = "address.country.countryName", source = "address.country.countryName")
	@Mapping(target = "primaryContact", source = "primaryContact")
	public abstract ClientDto convertToClientDto(Client client);

	public abstract ClientDetailedInfoDto convertToClientDetailedInfoDto(Client client);

	public abstract Client convertClientDetailedInfoDtoToClient(ClientDetailedInfoDto client);

	@Mapping(target = "primaryContact", source = "primaryContact")
	public abstract Client convertToCLient(ClientDto clientDto);

	@Mapping(target = "primaryContact", source = "primaryContact")
	public abstract Client convertToCLientAdd(ClientAddDto clientDto);

	@Mapping(target = "primaryContact", source = "primaryContact")
	public abstract ClientAddDto convertToCLientAddDto(Client client);

	public abstract void updateClient(ClientDto clientDto, @MappingTarget Client client);

	public abstract ClientDto convertToViewCLient(Client client);

	public abstract ClientAccountSubscriptionDto convertToAccountSubsciptionDto(Account account);
	
	String toString(Country country) {
		return country.getCountryName();
	}

	String toString(URI uri) {
		return uri.toString();

	}

	URI toURI(String string) {
		URI uri = null;
		try {
			uri = new URI(string);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return uri;

	}

	String toString(Feature feature) {
		if (feature!=null && feature.getFeatureCode()!=null) {
		return feature.getFeatureCode();
		}
		else return "";
	}
	
	Feature toFeature(String featureCode) {
		Optional<Feature> feature=featureRepository.findByFeatureCode(featureCode);
		if(feature.isPresent()) {
			return feature.get();
		}else {
			return null;
		}
	}


}
