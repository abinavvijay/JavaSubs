package com.posmo.administrationservice.model.enums;

public enum EStatus {
ACTIVE,
INACTIVE
}
