package com.posmo.administrationservice.service;

import java.util.List;
import java.util.Set;
import java.util.UUID;

//import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.dto.account.ClientAddDto;
import com.posmo.administrationservice.dto.account.user.AllUserPermissionsDto;
import com.posmo.administrationservice.dto.account.user.DetailedUserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserAddDto;
import com.posmo.administrationservice.dto.account.user.UserDetailsDto;
import com.posmo.administrationservice.dto.account.user.UserDto;
import com.posmo.administrationservice.dto.account.user.UserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserOrganizationDto;
import com.posmo.administrationservice.dto.account.user.UserStatusDto;
import com.posmo.administrationservice.exceptions.PrimaryContactNotFoundException;
import com.posmo.administrationservice.exceptions.UserAlreadyExistsException;
import com.posmo.administrationservice.exceptions.UserNotFoundException;
import com.posmo.administrationservice.model.account.User;
import com.posmo.administrationservice.model.account.UserProfile;
import com.posmo.administrationservice.model.enums.EStatus;

@Service
public interface UserService {
	
	AllUserPermissionsDto getUserPermissions(String username)throws UserNotFoundException;
	
	AllUserPermissionsDto getUserPermissions(UUID userUUID)throws UserNotFoundException;
	
	UserInfoDto getUserInfo (String username) throws UserNotFoundException;
	
	public UserStatusDto getUserStatus (String username) throws UserNotFoundException;
	
	public UserOrganizationDto getOrganizationsForUser(String username) throws UserNotFoundException;
	
	UserDto addUser (UserDto user) throws UserAlreadyExistsException, Exception;

	UserDto findByUUID(UUID userUUID) throws UserNotFoundException;

	String deleteUser(String username) throws UserNotFoundException;

	DetailedUserInfoDto getDetailedUserInfo(String username) throws UserNotFoundException;

	UserDto editUser(UserDto userDto) throws UserNotFoundException;

	UserDto getUser(String username) throws UserNotFoundException;

	List<UserDto> getAllUserInfo()  throws UserNotFoundException;

	List<UserDto> getUserInfoByOrganizationId(UUID organizationId)throws UserNotFoundException;

	UserDto addUser(UserAddDto userAddDto, String subscriptionCode, UUID accountId) throws Exception;

	List<UserDto> getAllUserInfo(int limit, int pageNo)throws UserNotFoundException;

	void addOrganizationToSuperAdmins(UUID id) throws UserNotFoundException;

	UserDto addPOSMOTeam(UserAddDto userDto) throws UserAlreadyExistsException, UserNotFoundException;

	User saveClientAsUser(ClientAddDto clientAddDto)throws PrimaryContactNotFoundException, UserNotFoundException;

	UserProfile setUserProfileForClient(ClientAddDto client);

	User saveAccountAndSubscriptionData(String username, String subscriptionCode, UUID accountId);

	UserDto editUserStatus(UUID userId, EStatus status)throws UserNotFoundException;
	
	UserDetailsDto getUserDetails(String username) throws UserNotFoundException;
	
	String addPOSMOTeamPin(String username, String pin) throws Exception;
	
	Set<OrganizationDto> validateEntryPin(String pin) throws Exception;

	String editTabletPin(String username, String oldPin, String newpin) throws Exception;
	
	
}
