package com.posmo.administrationservice.mapper;


import java.net.URI;
import java.net.URISyntaxException;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import com.posmo.administrationservice.dto.account.AccountDto;
import com.posmo.administrationservice.model.Country;
import com.posmo.administrationservice.model.Feature;
import com.posmo.administrationservice.model.account.Account;


/**
 * 
 * This interface converts account entities to dtos
 *
 */
@Mapper
@Component
public interface AccountMapper {


	AccountDto convertToAccountDto(Account account);

	default String toString(Feature feature) {

		if (feature!=null && feature.getFeatureCode()!=null) {
		return feature.getFeatureCode();
		}
		else return "";
	}


	default String toString(Country country) {
		return country.getCountryName();
	}
	
	default String toString(URI uri) {
		return uri.toString();
		
	}
	
	default URI toURI(String string) {
		URI uri = null;
		try {
			uri = new URI(string);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return uri;
		
	}

	
}
