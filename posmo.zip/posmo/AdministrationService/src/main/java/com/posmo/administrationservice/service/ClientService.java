package com.posmo.administrationservice.service;

import com.posmo.administrationservice.dto.OrganizationIntegrationDto;
import com.posmo.administrationservice.dto.account.AccountDto;
import com.posmo.administrationservice.dto.account.AccountSubscriptionDto;
import com.posmo.administrationservice.dto.account.ClientAccountDto;
import com.posmo.administrationservice.dto.account.ClientAccountSubscriptionDto;
import com.posmo.administrationservice.dto.account.ClientAddDto;
import com.posmo.administrationservice.dto.account.ClientDetailedInfoDto;
import com.posmo.administrationservice.dto.account.ClientDto;
import com.posmo.administrationservice.exceptions.AccountSubscriptionNotFoundException;
import com.posmo.administrationservice.exceptions.ClientAccountStatusNotFoundException;
import com.posmo.administrationservice.exceptions.ClientNotFoundException;
import com.posmo.administrationservice.model.account.AccountSubscription;
import com.posmo.administrationservice.model.account.Client;
import com.posmo.administrationservice.model.enums.EStatus;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public interface ClientService {


	ClientDto addClient(ClientAddDto dto) throws Exception;

	ClientDto getClientDetailsById(UUID id);

	ClientDto updateClient(ClientDto clientdto);

	List<ClientDetailedInfoDto> viewAllClients();
	
	ClientDetailedInfoDto getClientInfoDetails(UUID id);

	Client getClient(String clientName) throws ClientNotFoundException;
	
	String deleteClient(UUID id) throws ClientNotFoundException;

	ClientAccountSubscriptionDto getAccountSubscriptionsForClient(UUID clientId) throws AccountSubscriptionNotFoundException;

	ClientDetailedInfoDto editClientEstatus(UUID id, EStatus accountStatus)throws ClientAccountStatusNotFoundException;

	ClientDetailedInfoDto getClientDetailsByAccountId(UUID id) throws ClientNotFoundException;

	List<AccountSubscription> createAccountSubscriptionsByCode(List<String> subscriptionCodes, String activatedBy);

	ClientDetailedInfoDto viewClientByEmail(String primaryContactEmail) throws ClientNotFoundException;
	
	
	
	

}
