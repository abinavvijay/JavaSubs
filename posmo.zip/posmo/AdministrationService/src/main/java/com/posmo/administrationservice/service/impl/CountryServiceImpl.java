package com.posmo.administrationservice.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.posmo.administrationservice.dto.CountryDto;
import com.posmo.administrationservice.exceptions.CountryAlreadyExistsException;
import com.posmo.administrationservice.mapper.CountryMapper;
import com.posmo.administrationservice.model.Country;
import com.posmo.administrationservice.repository.CountryRepository;
import com.posmo.administrationservice.service.CountryService;

@Service
public class CountryServiceImpl implements CountryService {

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private CountryMapper countryMapper;


    @Override
    public List<CountryDto> get() {
        List<Country> countries = countryRepository.get();
        return countryMapper.convertToCountryDtoList(countries);
    }

    @Override
    public CountryDto get(UUID uuid) {
        Country country = countryRepository.findByUUID(uuid);
        return countryMapper.convertToCountryDto(country);
    }

	@Override
	public List<CountryDto> addAllCountries(List<CountryDto> countriesDto) throws CountryAlreadyExistsException{
		List<Country>countries = countryMapper.convertToCountryList(countriesDto);
		countries.forEach(country -> country = countryRepository.save(country));
		return countryMapper.convertToCountryDtoList(countries);
	}
}
