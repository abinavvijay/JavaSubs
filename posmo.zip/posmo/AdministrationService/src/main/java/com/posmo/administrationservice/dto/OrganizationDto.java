package com.posmo.administrationservice.dto;

import java.util.List;
import java.util.UUID;

import com.posmo.administrationservice.dto.account.ContactInfoDto;
import com.posmo.administrationservice.dto.account.PrimaryContactDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationDto {
	private UUID id;

	private String name;

	private String legalName;

	private String ownerName;

	private String ownerEmail;

	private UUID clientId;
	
	private Boolean tabletValidation;

	private String vatEditableCountryId;

	private String physicalId;

	private String postalId;

	private String postalAddressCountry;

	private String physicalAddressCountry;

	private String postalTaxCode;

	private String physicalTaxCode;

	private String vatCountryCode;

	private String vatCountryName;

	private String clientLegalName;
	
	private String clientBusinessName;

	private AddressDto postalAddress;

	private AddressDto physicalAddress;

	private PrimaryContactDto primaryContact;

	private ContactInfoDto contactInformation;

	private UUID vatCountryId;

	private String taxRegistrationNo;




	private List<DepartmentDto> departments;

	private List<OrganizationIntegrationDto> organizationIntegrations;
}
