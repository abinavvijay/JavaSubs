package com.posmo.administrationservice.dto.account.user;

import java.util.List;
import java.util.UUID;

import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.model.Organization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserOrganizationDto {

	private UUID id;
	private String username;
	private UUID AzureUUID;
	private String azureUPN;
	private List<OrganizationDto> organizations;
}
