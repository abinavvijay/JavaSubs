package com.posmo.administrationservice.exceptions;

public class UserOrganizationDeletionException extends Exception {

	public UserOrganizationDeletionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserOrganizationDeletionException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public UserOrganizationDeletionException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public UserOrganizationDeletionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UserOrganizationDeletionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
