package com.posmo.administrationservice.dto;

import java.util.List;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.posmo.administrationservice.dto.subscription.SubscriptionDto;
import com.posmo.administrationservice.model.BusinessModule;
import com.posmo.administrationservice.model.Product;
import com.posmo.administrationservice.model.subscription.Subscription;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductModulesAndSubCountDto {

	private long businessModuleCount;
	private long functionalModuleCount;
	private long featureCount;
	private long subscriptionCount;

}
