package com.posmo.administrationservice.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.posmo.administrationservice.dto.CurrencyDto;
import com.posmo.administrationservice.dto.configuration.DepartmentConfigurationDto;
import com.posmo.administrationservice.dto.configuration.OrganizationConfigurationDto;
import com.posmo.administrationservice.exceptions.ConfigurationNotFoundException;
import com.posmo.administrationservice.exceptions.CurrencyAlreadyExistsException;
import com.posmo.administrationservice.log.PosmoLogDebug;
import com.posmo.administrationservice.service.OrganizationConfigurationService;
import com.posmo.administrationservice.util.ExceptionHandler;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = "/organizationconfiguration")
@CrossOrigin("*")
@Slf4j
public class OrganizationConfigurationController {

	@Autowired
	private OrganizationConfigurationService organizationConfigurationService;

	@Operation(summary = "add organization dept configuration")
	@PostMapping("/departmentconfiguration")
	@ResponseBody
	public ResponseEntity<?> addDepartmentConfiguration(
			@RequestBody DepartmentConfigurationDto departmentConfigurationDto) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<DepartmentConfigurationDto>(
					organizationConfigurationService.addDepartmentConfiguration(departmentConfigurationDto),
					HttpStatus.OK);
		} catch (ConfigurationNotFoundException e) {
			response = new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}

	@Operation(summary = "Editing the organization Department Configuration")
	@PutMapping("/editdepartmentConfig")
	@ResponseBody
	public ResponseEntity<?> editDepartmentConfiguration(
			@RequestBody DepartmentConfigurationDto departmentConfigurationDto) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<DepartmentConfigurationDto>(
					organizationConfigurationService.editDepartmentConfiguration(departmentConfigurationDto),
					HttpStatus.OK);
		} catch (ConfigurationNotFoundException e) {
			response = new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}

	@Operation(summary = "Get the Organization Department Configuration By Id")
	@GetMapping("/getdepartmentConfigurationbyid/{id}")
	@ResponseBody
	public ResponseEntity<?> getDepartmentConfigurationById(@PathVariable(value = "id") UUID id) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<DepartmentConfigurationDto>(
					organizationConfigurationService.getDepartmentConfigurationById(id), HttpStatus.OK);
		} catch (ConfigurationNotFoundException e) {
			response = new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}

	@Operation(summary = "delete department configuration by id")
	@DeleteMapping("/deletedepartmentconfiguration")
	public ResponseEntity<?> deleteDepartmentConfiguration(@RequestParam UUID id, @RequestParam UUID customId) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<String>(
					organizationConfigurationService.deleteDepartmentConfiguration(id, customId), HttpStatus.OK);

		} catch (ConfigurationNotFoundException e) {
			response = new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}

	@PutMapping
	@PosmoLogDebug
	@Operation(summary = "Editing the Organization Configuration")
	public ResponseEntity<?> editConfiguration(@RequestBody OrganizationConfigurationDto dto,
			@RequestParam("organizationId") UUID organizationId) {
		ResponseEntity<?> response;
		try {
			log.info("Updating Organization Configuration: {}", dto);
			response = new ResponseEntity<OrganizationConfigurationDto>(
					organizationConfigurationService.updateConfiguration(dto, organizationId), HttpStatus.OK);

		} catch (NullPointerException ex) {
			log.error(ex.getMessage());
			response = new ResponseEntity<ExceptionHandler>(new ExceptionHandler(ex.getMessage()), HttpStatus.OK);
		} catch (ConfigurationNotFoundException e) {
			log.error(e.getMessage());
			response = new ResponseEntity<ExceptionHandler>(new ExceptionHandler(e.getMessage()), HttpStatus.OK);
		}
		return response;
	}

	@GetMapping("/loadorganizationconfig/{id}")
	@ResponseBody
	@PosmoLogDebug
	@Operation(summary = "Load  Organization Configuration based on Organization Id")
	public ResponseEntity<?> getConfigurationById(@PathVariable(value = "id") UUID id) {
		ResponseEntity<?> response;
		try {
			log.info("Getting Organization Confiuration by id : {}", id);
			response = new ResponseEntity<OrganizationConfigurationDto>(
					organizationConfigurationService.findByOrganizationId(id), HttpStatus.OK);
		} catch (ConfigurationNotFoundException e) {
			log.error(e.getMessage());
			response = new ResponseEntity<ExceptionHandler>(new ExceptionHandler(e.getMessage()), HttpStatus.OK);
		}
		return response;
	}

	@GetMapping("/getcurrencylist")

	@ResponseBody

	@PosmoLogDebug

	@Operation(summary = "Get CurrencyTypes List")

	public ResponseEntity<?> getAllCurrencyTypes() {

		ResponseEntity<?> response;

		try {

			log.info("Get Currency List");

			response = new ResponseEntity<List<CurrencyDto>>(organizationConfigurationService.getAllCurrencyList(),
					HttpStatus.OK);

		} catch (ConfigurationNotFoundException e) {

			log.error(e.getMessage());

			response = new ResponseEntity<ExceptionHandler>(new ExceptionHandler(e.getMessage()), HttpStatus.OK);

		}

		return response;

	}

	@PostMapping("/savecurrencylist")

	@ResponseBody

	@PosmoLogDebug

	@Operation(summary = "Save CurrencyTypes List")

	public ResponseEntity<?> saveCurrencyList(@RequestBody List<CurrencyDto> currencyDtos) {

		ResponseEntity<?> response;

		try {

			log.info("Save Currency List");

			response = new ResponseEntity<List<CurrencyDto>>(
					organizationConfigurationService.saveCurrencyList(currencyDtos), HttpStatus.OK);

		} catch (CurrencyAlreadyExistsException e) {

			log.error(e.getMessage());

			response = new ResponseEntity<ExceptionHandler>(new ExceptionHandler(e.getMessage()), HttpStatus.OK);

		}

		return response;

	}

}
