package com.posmo.administrationservice.model.configuration;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.posmo.administrationservice.model.BaseEntity;
import com.posmo.administrationservice.model.Organization;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="organization_config")
public class OrganizationConfiguration extends BaseEntity implements Serializable {

	/**
	 * Sriharsha
	 * */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="organization_config_id")
	private UUID id;

	
	@OneToOne(cascade = { CascadeType.REFRESH, CascadeType.DETACH})
	@JoinColumn(name = "currency_id")
	private Currency currency;
	
}
