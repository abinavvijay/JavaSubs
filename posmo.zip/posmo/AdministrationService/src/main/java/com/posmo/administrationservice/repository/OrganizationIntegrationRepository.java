package com.posmo.administrationservice.repository;


import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.posmo.administrationservice.model.Integration;
import com.posmo.administrationservice.model.OrganizationIntegration;

@Repository
public interface OrganizationIntegrationRepository extends JpaRepository<OrganizationIntegration, UUID> {
	
    @Transactional
	@Query(value="SELECT EXISTS(SELECT * FROM organization_integration WHERE integration_id = :integrationId and organization_id =:organizationId)",nativeQuery = true)
	boolean checkifIntegrationExists(@Param("integrationId")UUID integrationId,@Param("organizationId") UUID organizationId);

    @Transactional
    @Modifying
    @Query(value="delete from organization_integration where organization_integration_id=:organizationIntegrationId",nativeQuery = true)
	 void deleteOrganizationIntegration(@Param("organizationIntegrationId") UUID organizationIntegrationId);


}
