package com.posmo.administrationservice.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCrypt;
//import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.dto.account.ClientAddDto;
import com.posmo.administrationservice.dto.account.ClientDto;
import com.posmo.administrationservice.dto.account.user.AllUserPermissionsDto;
import com.posmo.administrationservice.dto.account.user.DetailedUserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserAddDto;
import com.posmo.administrationservice.dto.account.user.UserDetailsDto;
import com.posmo.administrationservice.dto.account.user.UserDto;
import com.posmo.administrationservice.dto.account.user.UserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserOrganizationDto;
import com.posmo.administrationservice.dto.account.user.UserStatusDto;
import com.posmo.administrationservice.exceptions.PrimaryContactNotFoundException;
import com.posmo.administrationservice.exceptions.OrganizationNotFoundException;
import com.posmo.administrationservice.exceptions.UserAlreadyExistsException;
import com.posmo.administrationservice.exceptions.UserNotFoundException;
import com.posmo.administrationservice.exceptions.UserOrganizationAlreadyExistsException;
import com.posmo.administrationservice.mapper.ClientMapper;
import com.posmo.administrationservice.mapper.OrganizationMapper;
import com.posmo.administrationservice.mapper.UserMapper;
import com.posmo.administrationservice.model.Organization;
import com.posmo.administrationservice.model.account.Account;
import com.posmo.administrationservice.model.account.AccountSubscription;
import com.posmo.administrationservice.model.account.Client;
import com.posmo.administrationservice.model.account.User;
import com.posmo.administrationservice.model.account.UserProfile;
import com.posmo.administrationservice.model.enums.ERole;
import com.posmo.administrationservice.model.enums.EStatus;
import com.posmo.administrationservice.model.subscription.Subscription;
import com.posmo.administrationservice.repository.AccountRepository;
import com.posmo.administrationservice.repository.AccountSubscriptionRepository;
import com.posmo.administrationservice.repository.OrganizationRepository;
import com.posmo.administrationservice.repository.SubscriptionRepository;
import com.posmo.administrationservice.repository.UserRepository;
import com.posmo.administrationservice.service.ClientService;
import com.posmo.administrationservice.service.OrganizationService;
import com.posmo.administrationservice.service.UserPermissionsService;
import com.posmo.administrationservice.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private AccountSubscriptionRepository accountSubscriptionRepository;
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	@Autowired
	private ClientService clientService;
	
	@Autowired
	private UserPermissionsService userPermissionsService;
	
	@Autowired
	private OrganizationRepository organizationRepository;
	
	@Autowired
	private OrganizationService organizationService;
	
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private ClientMapper clientMapper;
	
	@Autowired
	private OrganizationMapper organizationMapper;	
	
	@Autowired
	com.posmo.administrationservice.util.EmailNotification emailNotification;
	
	@Value("${EmailDetails.loginURL}")
	private String LOGINURL;
	
	@Value("${EmailDetails.appLoginURL}")
	private String APPLOGINURL;



	@Override
	public AllUserPermissionsDto getUserPermissions(String username) throws UserNotFoundException {
		User user = userRepository.findByUsername(username);
		return userMapper.convertToAllUserPermissionsDto(user);
	}

	@Override
	public AllUserPermissionsDto getUserPermissions(UUID userUUID) throws UserNotFoundException {
		User user = userRepository.findByUUID(userUUID);
		AllUserPermissionsDto  allUserPermissionsDto = userMapper.convertToAllUserPermissionsDto(user);
		return allUserPermissionsDto;
	}
	
	@Override
	public UserDto getUser(String username) throws UserNotFoundException {
		User user = userRepository.findByUsername(username);
		UserDto  userDto = userMapper.convertToUserDto(user);
		return userDto;
	}

	@Override
	public UserInfoDto getUserInfo(String username) throws UserNotFoundException {
		User user = userRepository.findByUsername(username);
		if(user == null)
		throw new UserNotFoundException("Username not found");
		UserInfoDto  userInfoDto = userMapper.convertToUserInfoDto(user);
		return userInfoDto;
	}


	@Override
	public DetailedUserInfoDto getDetailedUserInfo(String username) throws UserNotFoundException {
		User user = userRepository.findByUsername(username);
		if(user == null)
			throw new UserNotFoundException("Username not found");
		DetailedUserInfoDto  detailedUserInfoDto = userMapper.convertToDetailedUserInfoDto(user);
		return detailedUserInfoDto;
	}


	@Override
	public UserStatusDto getUserStatus(String username) throws UserNotFoundException {
		User user = userRepository.findByUsername(username);
		if(user == null)
			throw new UserNotFoundException("Username not found");
		UserStatusDto userStatusDto = userMapper.convertToUserStatusDto(user);
		return userStatusDto;
		
	}


	@Transactional
	@Override
	public UserDto addUser(UserDto userDto) throws UserAlreadyExistsException,Exception{
 		User user = userMapper.convertToUser(userDto);
		user.addMetaData(user.getUsername());
		user.setAccount(null);
		user.setUserPermissions(null);
		user.setAccountSubscription(null);
		user=userRepository.save(user);
		String username = user.getUsername();
		String subscriptionCode = userDto.getAccountSubscription().getSubscription().getSubscriptionCode();
		System.out.println("subscriptionCode " + subscriptionCode);
		UUID accountId = userDto.getAccount().getId(); 
		saveAccountAndSubscriptionData(username,subscriptionCode,accountId);
		user = userRepository.getById(user.getId());
		UserDto response = userMapper.convertToUserDto(user);
		
		if(response != null) {
			
			String name = user.getUserProfile().getFirstName()+" "+ user.getUserProfile().getLastName();
			
			String emailSubject="POSMO - USER SETUP";
			
	        String emailBody = "Dear "+ name + ", \n\n" + "You have been setup as an User for the Client: "+ user.getAccount().getClientName() +". Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+user.getUsername()+"\n\n";
	        
	        emailNotification.sendMail(user.getUsername(), emailSubject,emailBody, name);
			
			
			
		}
		
		return response;
	}
	@Transactional
	@Override
	public UserDto addUser(UserAddDto userAddDto, String subscriptionCode, UUID accountId) throws Exception{
		User user = userMapper.convertUserAddDtoToUser(userAddDto);
		user.addMetaData(user.getUsername());
		user.setUserPermissions(null);
		user=userRepository.save(user);
		
		saveAccountAndSubscriptionData(user.getUsername(), subscriptionCode ,accountId);
		user = userRepository.getById(user.getId());
		UserDto response = userMapper.convertToUserDto(user);
		
		if(response != null) {
			
			String name = user.getUserProfile().getFirstName()+" "+ user.getUserProfile().getLastName();
			
			String emailSubject="POSMO - USER SETUP";
			
	        String emailBody = "Dear "+ name + ", \n\n" + "You have been setup as an User for the Client: "+ user.getAccount().getClientName() +". Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+user.getUsername()+"\n\n"+"Pin: "+ userAddDto.getUserPassword();
	        
	        emailNotification.sendMail(user.getUsername(), emailSubject,emailBody, name);
					       
		}
		
		return response;
	}
	
	@Override
	public User saveAccountAndSubscriptionData(String username, String subscriptionCode, UUID accountId) {
		User user = userRepository.findByUsername(username);
		System.out.println(user.getUsername());
		AccountSubscription accSubscription = new AccountSubscription();
		System.out.println("checking ");
		Optional<Subscription> subscription = subscriptionRepository.findBySubscriptionCode(subscriptionCode);
		
		Optional<Account> optAccount = null;
		if(accountId!=null) {
			optAccount= accountRepository.findById(accountId);
		}
		Account account=  new Account();
		if(optAccount!=null && optAccount.isPresent()) {
			System.out.println("account found ");
			account = optAccount.get();
			user.setAccount(account);
		}else {
			System.out.println("account not found ");
			account.setAccountEmail(username); 
			account.setAccountStatus(EStatus.ACTIVE);
			account.setUsers(null);
			account.setDefaultUser(null);
			if(subscription.isPresent()) {
				List<AccountSubscription> accountSubscriptions = new ArrayList<>();
				accSubscription = new AccountSubscription(UUID.randomUUID(),subscription.get() ,username, new Date(),new Date(),EStatus.ACTIVE);
				accountSubscriptions.add(accSubscription);
				account.setAccountSubscriptions(accountSubscriptions);
				account = accountRepository.save(account);
		}
		}
		
		userRepository.updateUserAccount(account.getId(),username);
		accSubscription = accountSubscriptionRepository.findAccountSubscription(account.getId(), subscription.get().getId());
		if(accSubscription!=null) {
			userRepository.updateUserAccountSubscription(accSubscription.getId(), username);
		}
		
		return userRepository.findByUsername(username);
	}

	@Override
	public UserDto editUser(UserDto userDto)  throws UserNotFoundException{
		User user = userRepository.findByUUID(userDto.getId());
		if(user == null)
			throw new UserNotFoundException("Username not found");
		user.editMetaData(user.getUsername());
		userMapper.updateUser(userDto,user);
		return userMapper.convertToUserDto( userRepository.save(user));
	}
	

	@Override
	public String deleteUser(String username) throws UserNotFoundException {
		User user = userRepository.findByUsername(username);
		if(user == null)
			throw new UserNotFoundException("Username not found");
		userRepository.deleteUserOrganizationForUser(user.getId());
		userRepository.deleteByUserName(username);
		
		return "User Deleted Successfully!";
	}


	
	@Override
	public UserDto findByUUID(UUID userUUID) throws UserNotFoundException {
		User user =userRepository.findByUUID(userUUID);
		if(user == null)
			throw new UserNotFoundException("Username not found");
		return userMapper.convertToUserDto(user);
	}

	@Override
	public UserOrganizationDto getOrganizationsForUser(String username) throws UserNotFoundException {
		User user = userRepository.findByUsername(username);
		if(user==null)
			throw new UserNotFoundException("user not found");
		UserOrganizationDto userOrganizationDto = userMapper.convertToUserOrganizationDto(user);
		return userOrganizationDto;
	}

	@Override
    public List<UserDto> getAllUserInfo() throws UserNotFoundException {
        List<User> user = userRepository.findAll();
        if(user.isEmpty())
        	throw new UserNotFoundException("users are not found");
        return userMapper.convertToUserListDto(user);
    }

	@Override
    public List<UserDto> getUserInfoByOrganizationId(UUID organizationId) throws UserNotFoundException {
         Organization organization = organizationRepository.findByUUID(organizationId);
        
         if(organization == null)
         	throw new UserNotFoundException("users are not found");
        Set<User> user = organization.getUsers();
        List<UserDto>  userInfoDto = userMapper.convertToUserListDto(new ArrayList(user));       
        return userInfoDto;
    }

	@Override
	public List<UserDto> getAllUserInfo(int limit, int pageNo) throws UserNotFoundException {
		 List<User> users = userRepository.findPagewiseUsers(limit,pageNo*limit);
		 if(users.isEmpty())
	        	throw new UserNotFoundException("users are not found");
	        return userMapper.convertToUserListDto(users);
	}
	
	@Override
	public void addOrganizationToSuperAdmins(UUID organizationId) throws UserNotFoundException{
		List<User> superAdmins = userRepository.findSuperAdmins();
		if(superAdmins.isEmpty())
        	throw new UserNotFoundException("users are not found");
		superAdmins.forEach(superAdmin -> organizationRepository.addOrganizationToUser(superAdmin.getId(), organizationId));
			}

	@Override
	public UserDto addPOSMOTeam(UserAddDto userDto) throws UserAlreadyExistsException, UserNotFoundException {
		User user = userMapper.convertUserAddDtoToUser(userDto);
		user.addMetaData(user.getUsername());	
		Optional<Account> masterAccount = accountRepository.getPOSMOTeamAccount();
		Account account = masterAccount.isPresent() ? masterAccount.get() : createPOSMOTeamAccount();
		AccountSubscription masterAccountSubscription = accountSubscriptionRepository.getMasterAccountSubscription(account.getId());
		if(masterAccountSubscription==null)
			throw new UserAlreadyExistsException("masterAccountSubscription is null");
		user.setAccount(account);
		user.setAccountSubscription(masterAccountSubscription);
		user = userRepository.save(user);
		try {
			userPermissionsService.setAllUserPermissions(userDto.getUsername(),masterAccountSubscription.getSubscription().getSubscriptionCode());
		} catch (UserNotFoundException e) {
			e.printStackTrace();
		}
		if(user.getRole().getName().equals(ERole.ROLE_SUPERADMIN)) {
			addOrganizationsForSuperAdmin(user.getId());
		}
		return userMapper.convertToUserDto(user);
	}
	
	private void addOrganizationsForSuperAdmin(UUID userId) throws UserNotFoundException {
		List<Organization> organizations= organizationRepository.findAll();
		if(organizations.isEmpty())
        	throw new UserNotFoundException("organizations list is empty");
		
		List<UUID> organizationIds= organizations.stream()
								.map(organization -> organization.getId())
								.collect(Collectors.toList());
		String s="";
			try {
				s =organizationService.addOrganizationsToUser(userId, organizationIds);
			} catch (OrganizationNotFoundException | UserOrganizationAlreadyExistsException e) {
				System.out.println(e.getMessage());
			}
	}
	@Transactional
	private Account createPOSMOTeamAccount() {
		Account account = new Account();
		account.setId(UUID.randomUUID());
		account.setAccountEmail("SuperAdmin@Posmo.com");
		account.setAccountStatus(EStatus.ACTIVE);
		account.setClientName("Super Admin");
		account.addMetaData("SuperAdmin@Posmo.com");
		List<String> subscriptionCodes = new ArrayList<String>();
		subscriptionCodes.add("ERP_PRM");
		account.setAccountSubscriptions(clientService.createAccountSubscriptionsByCode(subscriptionCodes,"SuperAdmin@Posmo.com"));
		account = accountRepository.save(account);
		return account;
	}

	@Override
	@Transactional
	public User saveClientAsUser(ClientAddDto clientAddDto) throws PrimaryContactNotFoundException, UserNotFoundException {
		User user = new User();
		user.setRole(userMapper.ToRole(ERole.ROLE_CONSULTANT));
		user.setUsername(clientAddDto.getPrimaryContact().getPrimaryContactEmail());
		user.setEmail(clientAddDto.getPrimaryContact().getPrimaryContactEmail());
		user.setUserStatus(EStatus.ACTIVE);
		user.setAzureUPN(clientAddDto.getAzureUPN());
		user.setUserProfile(setUserProfileForClient(clientAddDto));
		user.addMetaData(clientAddDto.getPrimaryContact().getPrimaryContactEmail());
		
		
		List<User> tabletUsers = userRepository.findUsersForTablet();	
		
		String clientPin = clientAddDto.getClientPin();
		
		if(clientPin != null) {
		
			boolean duplicatePinCheck = false;
		
			for(User tabletUser: tabletUsers) {
				
				
				if(tabletUser.getUserPinHash() != null && ! duplicatePinCheck) {
					
					if (BCrypt.checkpw(clientPin, tabletUser.getUserPinHash()))
						duplicatePinCheck = true;
					
				}
				
			}
			if(duplicatePinCheck)
				throw new PrimaryContactNotFoundException("Please select a unique Pin for the Client!");
			
			user.setUserPinHash( BCrypt.hashpw(clientPin, BCrypt.gensalt()));
			
		}
		
		else
			user.setUserPinHash(null);
		
		return userRepository.save(user);
	}
	
	@Override
	public UserProfile setUserProfileForClient(ClientAddDto client) {
		UserProfile userProfile = new UserProfile();
		userProfile.setFirstName(client.getPrimaryContact().getFirstName());
		userProfile.setLastName(client.getPrimaryContact().getLastName());
		userProfile.setPersonalEmail(client.getPrimaryContact().getPrimaryContactEmail());
		userProfile.setEmail(client.getPrimaryContact().getPrimaryContactEmail());
		userProfile.setPhoneNo(client.getPrimaryContact().getPrimaryContactPhoneNo());
		userProfile.setImageURL("https://icon-library.com/images/clients-icon-png/clients-icon-png-9.jpg");
		return userProfile;
	}

	@Override
	public UserDto editUserStatus(UUID userId, EStatus status) throws UserNotFoundException{
		User user =userRepository.findByUUID(userId);
		if(user==null)
        	throw new UserNotFoundException("user is not found");
		
		user.setUserStatus(status);
		user= userRepository.save(user);
		return userMapper.convertToUserDto(user);
	}

	@Override
	public UserDetailsDto getUserDetails(String username) throws UserNotFoundException {
		
		User user = userRepository.findByUsername(username);
		
		if(user == null)
			throw new UserNotFoundException("User with username: "+ username + " doesnot exists!");
		
		UserDetailsDto userDetailsDto = userMapper.convertToUserDetailsDto(user);
		
		Client client = user.getOrganizations().iterator().next().getClient();
		
		ClientDto clientDto = clientMapper.convertToClientDto(client);
		
		userDetailsDto.setClient(clientDto);
		
		
		return userDetailsDto;
	}

	@Override
	public String addPOSMOTeamPin(String username, String pin) throws Exception {
		User user = userRepository.findByUsername(username);
		
		if(user == null)
			throw new Exception("User with username: "+ username + " doesnot exists!");
		
		if(user.getRole().getName().equals(com.posmo.administrationservice.model.enums.ERole.ROLE_SUPERADMIN) || user.getRole().getName().equals(com.posmo.administrationservice.model.enums.ERole.ROLE_ACCOUNTADMIN) || user.getRole().getName().equals(com.posmo.administrationservice.model.enums.ERole.ROLE_ENGAGEMENTADMIN))  {
			
			List<User> tabletUsers = userRepository.findUsersForTablet();
			
			
			
				boolean duplicatePinCheck = false;
			
				for(User tabletUser: tabletUsers) {
					
					
					if(tabletUser.getUserPinHash() != null && !duplicatePinCheck) {
						
						if (BCrypt.checkpw(pin, tabletUser.getUserPinHash()))
							duplicatePinCheck = true;
						
					}
					
				}
				if(duplicatePinCheck)
					throw new Exception("Please select a unique Pin for the User!");
				
				user.setUserPinHash( BCrypt.hashpw(pin, BCrypt.gensalt()));
				
				userRepository.save(user);
				
				String name = user.getUserProfile().getFirstName()+" "+ user.getUserProfile().getLastName();
				
				String userRole = user.getRole().getName().toString();

				
				String emailSubject="POSMO - "+userRole+" PIN SETUP";
				
		        String emailBody = "Dear "+ name + ", \n\n" + "Your tablet pin have been set successfully."+" Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+user.getUsername()+"\n\n"+"Pin: "+pin;
		        
		        emailNotification.sendMail(user.getUsername(), emailSubject,emailBody, name);
				
				return "Pin set successfully for username: " + username;
			
		}
		
		return "User is not a SuperAdmin or an Account officer or a Client Admin";
	}

	@Override
	public String editTabletPin(String username,String oldPin, String newpin) throws Exception {

		User user = userRepository.findByUsername(username);
		
		if(user == null)
			throw new Exception("User with username: "+ username + " doesnot exists!");
		
		
		
		if(user.getRole().getName().equals(com.posmo.administrationservice.model.enums.ERole.ROLE_SUPERADMIN) || user.getRole().getName().equals(com.posmo.administrationservice.model.enums.ERole.ROLE_ACCOUNTADMIN) || user.getRole().getName().equals(com.posmo.administrationservice.model.enums.ERole.ROLE_ENGAGEMENTADMIN))  {
			
			if(user.getUserPinHash() == null)
				throw new Exception(" Pin doesnot exists for this user!");
				
				if(! (BCrypt.checkpw(oldPin, user.getUserPinHash())))
					throw new Exception("Old Pin doesnot Match!");	
			
			
			List<User> tabletUsers = userRepository.findUsersForTablet();
			
			if(tabletUsers.isEmpty())
				throw new Exception("Users Tabletlist is empty");
			
			
				boolean duplicatePinCheck = false;
			
				for(User tabletUser: tabletUsers) {
					
					
					if(tabletUser.getUserPinHash() != null && !duplicatePinCheck) {
						
						if (BCrypt.checkpw(newpin, tabletUser.getUserPinHash()))
							duplicatePinCheck = true;
						
					}
					
				}
				if(duplicatePinCheck)
					throw new Exception("Please select a unique Pin for the User!");
				
				user.setUserPinHash( BCrypt.hashpw(newpin, BCrypt.gensalt()));
				
				userRepository.save(user);
				
				String name = user.getUserProfile().getFirstName()+" "+ user.getUserProfile().getLastName();
				
				String userRole = user.getRole().getName().toString();
				
				String emailSubject="POSMO - "+userRole+" PIN CHANGE";
				
		        String emailBody = "Dear "+ name + ", \n\n" + "Your tablet pin been changed successfully."+" Please use the below URL to login/reset your login password. \n\n"+LOGINURL+"\n\n"+"Username: "+user.getUsername()+"\n\n"+"New Pin: "+newpin;
		        
		        emailNotification.sendMail(user.getUsername(), emailSubject,emailBody, name);
				
				return "Pin set successfully for username: " + username;
			
		}
		
		return "User is not a SuperAdmin or an Account officer or a Client Admin";
	}

	@Override
	public Set<OrganizationDto> validateEntryPin(String pin) throws Exception {

		List<User> tabletUsers = userRepository.findUsersForTablet();
		if(tabletUsers.isEmpty())
			throw new Exception("Users Tabletlist is empty");
		
		Set<OrganizationDto> organizationDtos = new HashSet<OrganizationDto>();
		
		boolean pinMatch = false;

		
		for(User tabletUser: tabletUsers) {
			
			if (tabletUser.getUserPinHash() != null && BCrypt.checkpw(pin, tabletUser.getUserPinHash())) {
				
				pinMatch = true;
				
				Set<Organization> organizations = tabletUser.getOrganizations();
				
				for(Organization organization : organizations)
					organizationDtos.add(	organizationMapper.convertToOrganizationDto(organization));
					
			}

		}

		if(!pinMatch)
			throw new Exception("Old Pin doesnot Match!");	
		
		return organizationDtos;
	}
	
	

}
