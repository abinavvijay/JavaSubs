package com.posmo.administrationservice.dto.account;

import java.util.List;
import java.util.UUID;

import com.posmo.administrationservice.model.enums.ERole;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RoleDto {
	private UUID id;
	
	private ERole name;
	
	private String code;
	
}
