package com.posmo.administrationservice.dto;

import java.net.URI;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.posmo.administrationservice.dto.account.ClientDto;
import com.posmo.administrationservice.model.BusinessModule;
import com.posmo.administrationservice.model.LineOfBusiness;
import com.posmo.administrationservice.model.Organization;
import com.posmo.administrationservice.model.account.Client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LineOfBusinessDto {
	private UUID id;
	
	private String LOBName;

	private String LOBCode;
	
	private List<BusinessModuleDto> businessModules;

}
