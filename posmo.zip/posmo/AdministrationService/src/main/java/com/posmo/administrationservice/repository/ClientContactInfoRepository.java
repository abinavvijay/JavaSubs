package com.posmo.administrationservice.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.posmo.administrationservice.model.account.ContactInfo;

import java.util.UUID;

@Repository
public interface ClientContactInfoRepository extends JpaRepository<ContactInfo, UUID> {


    @Query("select u from ContactInfo u where u.id = :id")
    ContactInfo findByUUID(@Param("id") UUID id);


}
