package com.posmo.administrationservice.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.posmo.administrationservice.dto.account.user.AllUserPermissionsDto;
import com.posmo.administrationservice.dto.account.user.DetailedUserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserAddDto;
import com.posmo.administrationservice.dto.account.user.UserDetailsDto;
import com.posmo.administrationservice.dto.account.user.UserDto;
import com.posmo.administrationservice.dto.account.user.UserInfoDto;
import com.posmo.administrationservice.dto.account.user.UserOrganizationDto;
import com.posmo.administrationservice.dto.account.user.UserStatusDto;
import com.posmo.administrationservice.exceptions.ErrorHandler;
import com.posmo.administrationservice.exceptions.UserAlreadyExistsException;
import com.posmo.administrationservice.exceptions.UserNotFoundException;
import com.posmo.administrationservice.model.enums.EStatus;
import com.posmo.administrationservice.service.UserService;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user")
@CrossOrigin("*")
@Slf4j
public class UserController {
	@Autowired
	private UserService userService;

	@Operation(summary = "add user")
	@PostMapping
	@Hidden
	public ResponseEntity<?> addUser(@RequestBody UserDto user) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserDto>(userService.addUser(user), HttpStatus.OK);
		} catch (UserAlreadyExistsException e) {
			e.printStackTrace();
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.BAD_REQUEST);
		}

		catch (Exception e) {
			e.printStackTrace();
			response = new ResponseEntity<Exception>(new Exception(e.getMessage()), HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@Operation(summary = "add user")
	@PostMapping("/add")
	public ResponseEntity<?> addUser(@RequestBody UserAddDto user, @RequestParam String SubscriptionCode,
			@RequestParam UUID accountId) throws Exception {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserDto>(userService.addUser(user, SubscriptionCode, accountId),
					HttpStatus.OK);
		} catch (UserAlreadyExistsException e) {
			e.printStackTrace();
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@Operation(summary = "add SuperAdmin/Account officer in Posmo Team")
	@PostMapping("/addposmoteam")
	public ResponseEntity<?> addPOSMOTeam(@RequestBody UserAddDto userDto) throws UserNotFoundException {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserDto>(userService.addPOSMOTeam(userDto), HttpStatus.OK);
		} catch (UserAlreadyExistsException e) {
			e.printStackTrace();
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	@Operation(summary = "update user details")
	@PutMapping
	public ResponseEntity<?> editUser(@RequestBody UserDto user) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserDto>(userService.editUser(user), HttpStatus.OK);

		} catch (UserNotFoundException e) {
			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Operation(summary = "delete user")
	@DeleteMapping
	public ResponseEntity<?> deleteUser(@RequestParam String username) {

		ResponseEntity<?> response;

		try {

			response = new ResponseEntity<String>(userService.deleteUser(username), HttpStatus.OK);

		} catch (UserNotFoundException e) {
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return response;
	}

	@Operation(summary = "get user")
	@GetMapping
	public ResponseEntity<?> getUser(@RequestParam String username) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserInfoDto>(userService.getUserInfo(username), HttpStatus.OK);

		} catch (UserNotFoundException e) {

			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}

		return response;
	}

	@Operation(summary = "get user info")
	@GetMapping("/userinfo")
	public ResponseEntity<?> getUserInfo(@RequestParam String username) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserInfoDto>(userService.getUserInfo(username), HttpStatus.OK);

		} catch (UserNotFoundException e) {
			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}

		return response;
	}

	@Operation(summary = "get Detailed user info")
	@GetMapping("/detaileduserinfo")
	public ResponseEntity<?> getDetailedUserInfo(@RequestParam String username) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<DetailedUserInfoDto>(userService.getDetailedUserInfo(username),
					HttpStatus.OK);

		} catch (UserNotFoundException e) {
			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}

		return response;
	}

	@Operation(summary = "get user permissions")
	@GetMapping("/permission")
	public ResponseEntity<?> getUserPermisssions(@RequestParam String username) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<AllUserPermissionsDto>(userService.getUserPermissions(username),
					HttpStatus.OK);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return response;
	}

	@Operation(summary = "get user permissions using UUID")
	@GetMapping("/permissions")
	public ResponseEntity<?> getUserPermisssions(@RequestParam UUID userUUID) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<AllUserPermissionsDto>(userService.getUserPermissions(userUUID),
					HttpStatus.OK);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return response;
	}

	@Operation(summary = "get user account status")
	@GetMapping("/userstatus")
	public ResponseEntity<?> getUserStatus(@RequestParam String username) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserStatusDto>(userService.getUserStatus(username), HttpStatus.OK);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return response;
	}

	@Operation(summary = "get organizations mapped to a user")
	@GetMapping("/userorganizations")
	public ResponseEntity<?> getRestaurantsForUser(@RequestParam String username) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserOrganizationDto>(userService.getOrganizationsForUser(username),
					HttpStatus.OK);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return response;
	}

	@Operation(summary = "get all user info")
	@GetMapping("/alluserinfo")
	public ResponseEntity<?> getAllUserInfo() {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<List<UserDto>>(userService.getAllUserInfo(), HttpStatus.OK);

		} catch (UserNotFoundException e) {
			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}

		return response;
	}

	@Operation(summary = "get all user info")
	@GetMapping("/allusers")
	public ResponseEntity<?> getAllUserInfo(int limit, int pageNo) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<List<UserDto>>(userService.getAllUserInfo(limit, pageNo), HttpStatus.OK);

		} catch (UserNotFoundException e) {
			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}

		return response;
	}

	@Operation(summary = "get user info from organization selection")
	@GetMapping("/userinfobyorganizationid")
	public ResponseEntity<?> getUserInfoByRestaurantId(@RequestParam UUID organizationId) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<List<UserDto>>(userService.getUserInfoByOrganizationId(organizationId),
					HttpStatus.OK);

		} catch (UserNotFoundException e) {
			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}

		return response;
	}

	@Operation(summary = "edit user status")
	@PutMapping("/edituserstatus")
	public ResponseEntity<?> editUserStatus(@RequestParam UUID userId, @RequestParam EStatus status) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserDto>(userService.editUserStatus(userId, status), HttpStatus.OK);

		} catch (UserNotFoundException e) {

			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Operation(summary = "get client details for user ")
	@GetMapping("/userclient")
	public ResponseEntity<?> getUserDetails(@RequestParam String username) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<UserDetailsDto>(userService.getUserDetails(username), HttpStatus.OK);

		} catch (UserNotFoundException e) {
			System.out.println("user not found");
			response = new ResponseEntity<UserNotFoundException>(new UserNotFoundException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return response;
	}

	@Operation(summary = "add POSMO Team Pin")
	@PatchMapping("/addposmoteampin")
	@ResponseBody
	public ResponseEntity<?> addPOSMOTeamPin(@RequestParam String username, @RequestParam String pin) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<Object>(userService.addPOSMOTeamPin(username, pin), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<ErrorHandler>(
					new ErrorHandler(HttpStatus.BAD_REQUEST.value(), e.getMessage()), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}

	@Operation(summary = "edit Tablet Pin for SuperAdmin, ClientAdmin and Account Officer")
	@PatchMapping("/edittabletpin")
	@ResponseBody
	public ResponseEntity<?> editTabletPin(@RequestParam String username, @RequestParam String oldPin,
			@RequestParam String newPin) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<Object>(userService.editTabletPin(username, oldPin, newPin), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<ErrorHandler>(
					new ErrorHandler(HttpStatus.BAD_REQUEST.value(), e.getMessage()), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}

	@Operation(summary = "Validate Entry Pin")
	@GetMapping("/validateentrypin")
	@ResponseBody
	public ResponseEntity<?> validateEntryPin(@RequestParam String pin) {
		ResponseEntity<?> response;
		try {
			response = new ResponseEntity<Object>(userService.validateEntryPin(pin), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<ErrorHandler>(
					new ErrorHandler(HttpStatus.BAD_REQUEST.value(), e.getMessage()), HttpStatus.BAD_REQUEST);
			e.printStackTrace();
		}
		return response;
	}

}
