package com.posmo.administrationservice.service;

import java.util.List;
import java.util.UUID;

import com.posmo.administrationservice.dto.CurrencyDto;
import com.posmo.administrationservice.dto.configuration.DepartmentConfigurationDto;
import com.posmo.administrationservice.dto.configuration.OrganizationConfigurationDto;
import com.posmo.administrationservice.exceptions.ConfigurationNotFoundException;
import com.posmo.administrationservice.exceptions.CurrencyAlreadyExistsException;

public interface OrganizationConfigurationService {

	OrganizationConfigurationDto addConfiguration(OrganizationConfigurationDto organizationConfigurationDto)
			throws ConfigurationNotFoundException;

	DepartmentConfigurationDto addDepartmentConfiguration(DepartmentConfigurationDto departmentConfigurationDto) throws ConfigurationNotFoundException;

	DepartmentConfigurationDto editDepartmentConfiguration(DepartmentConfigurationDto departmentConfigurationDto) throws ConfigurationNotFoundException;

	DepartmentConfigurationDto getDepartmentConfigurationById(UUID id) throws ConfigurationNotFoundException;

	String deleteDepartmentConfiguration(UUID id, UUID customId) throws ConfigurationNotFoundException;

	OrganizationConfigurationDto updateConfiguration(OrganizationConfigurationDto organizationConfigurationDto, UUID organizationId)
			throws ConfigurationNotFoundException;

	OrganizationConfigurationDto getConfigurationById(UUID id) throws ConfigurationNotFoundException;
	
	OrganizationConfigurationDto findByOrganizationId(UUID id) throws ConfigurationNotFoundException;

	List<CurrencyDto> getAllCurrencyList() throws ConfigurationNotFoundException;

	
    List<CurrencyDto> saveCurrencyList(List<CurrencyDto> currencyDtos) throws CurrencyAlreadyExistsException;
}
