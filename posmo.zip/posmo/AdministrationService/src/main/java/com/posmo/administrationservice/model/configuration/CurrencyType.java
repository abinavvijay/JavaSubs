package com.posmo.administrationservice.model.configuration;

public enum CurrencyType {
	  USD,INR, EUR,GBP

}
