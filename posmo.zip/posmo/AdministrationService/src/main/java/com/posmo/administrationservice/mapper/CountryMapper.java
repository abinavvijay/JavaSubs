package com.posmo.administrationservice.mapper;

import com.posmo.administrationservice.dto.CountryDto;
import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.model.Country;
import com.posmo.administrationservice.model.Organization;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

/**
 *
 * This interface converts user entities to dtos
 *
 */
@Mapper
(componentModel="spring")
@Component

public interface CountryMapper {

    CountryMapper mapper = Mappers.getMapper(CountryMapper.class);


    CountryDto convertToCountryDto(Country country);

    Country convertToCountry(CountryDto countryDto);

    void updateCountry(CountryDto countryDto, @MappingTarget Country country );


    List<CountryDto> convertToCountryDtoList(List<Country> countries);


    default String toString(URI uri) {
        return uri.toString();

    }

    default URI toURI(String string) {
        URI uri = null;
        try {
            uri = new URI(string);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return uri;

    }
    
	List<Country> convertToCountryList(List<CountryDto> countriesDto);
}
