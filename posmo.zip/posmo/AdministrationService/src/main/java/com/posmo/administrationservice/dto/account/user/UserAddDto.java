package com.posmo.administrationservice.dto.account.user;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.dto.account.AccountSubscriptionDto;
import com.posmo.administrationservice.dto.account.RoleDto;
import com.posmo.administrationservice.dto.account.UserAccountDto;
import com.posmo.administrationservice.dto.account.UserAccountSubscriptionDto;
import com.posmo.administrationservice.model.enums.EStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserAddDto {
	private UUID id;
	
	private String email;
	private String username;
	private String code;
	private UUID AzureUUID;
	private String azureUPN;
	private String userPassword;
	private RoleDto role;
	
	private EStatus userStatus;

	@Temporal(value = TemporalType.DATE)
	private Date createdDate;

	@Temporal(value = TemporalType.DATE)
	private Date lastModifiedDate;

	private String recordCreatedBy;

	private String modifiedBy;

	private UserProfileDto userProfile;

}
