package com.posmo.administrationservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

import com.posmo.administrationservice.dto.CurrencyDto;
import com.posmo.administrationservice.dto.configuration.OrganizationConfigurationDto;
import com.posmo.administrationservice.model.configuration.Currency;
import com.posmo.administrationservice.model.configuration.OrganizationConfiguration;

/**
 * 
 * This interface represents the converting entities and dtos
 *
 */
@Mapper
@Component
public interface OrganizationConfigurationMapper {

	OrganizationConfigurationMapper mapper = Mappers.getMapper(OrganizationConfigurationMapper.class);
	
	@Mapping(target = "currency.symbol",source="currency.symbol")
	OrganizationConfiguration convertToOrganizationConfigEntity(OrganizationConfigurationDto organizationConfigurationDto);
	@Mapping(target = "currency",source="currency")
	OrganizationConfigurationDto convertToOrganizationConfigDto(OrganizationConfiguration entity);


	void updateOrganizationConfig(OrganizationConfigurationDto dto, @MappingTarget OrganizationConfiguration configuration);

	

	
	
	CurrencyDto convertToCurrencyDto(Currency currency);
	
	Currency convertToCurrency(CurrencyDto currencyDto);

}




