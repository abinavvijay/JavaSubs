package com.posmo.administrationservice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.posmo.administrationservice.dto.CurrencyDto;
import com.posmo.administrationservice.dto.configuration.CustomDepartmentDto;
import com.posmo.administrationservice.dto.configuration.DepartmentConfigurationDto;
import com.posmo.administrationservice.dto.configuration.OrganizationConfigurationDto;
import com.posmo.administrationservice.exceptions.ConfigurationNotFoundException;
import com.posmo.administrationservice.exceptions.CurrencyAlreadyExistsException;
import com.posmo.administrationservice.log.PosmoLogDebug;
import com.posmo.administrationservice.mapper.DepartmentConfigurationMapper;
import com.posmo.administrationservice.mapper.OrganizationConfigurationMapper;
import com.posmo.administrationservice.model.Organization;
import com.posmo.administrationservice.model.configuration.Currency;
import com.posmo.administrationservice.model.configuration.DepartmentConfiguration;
import com.posmo.administrationservice.model.configuration.OrganizationConfiguration;
import com.posmo.administrationservice.repository.CurrencyRepository;
import com.posmo.administrationservice.repository.DepartmentConfigurationRepository;
import com.posmo.administrationservice.repository.OrganizationConfigurationRepository;
import com.posmo.administrationservice.repository.OrganizationRepository;
import com.posmo.administrationservice.service.OrganizationConfigurationService;

@Service
public class OrganizationConfigurationServiceImpl implements OrganizationConfigurationService {

	@Autowired
	private DepartmentConfigurationMapper departmentConfigurationMapper;

	@Autowired
	private DepartmentConfigurationRepository departmentConfigurationRepository;

	@Autowired
	private OrganizationConfigurationRepository organizationConfigurationRepository;

	
	@Autowired
	private OrganizationConfigurationMapper organizationConfigurationMapper;

	
	@Autowired
	private OrganizationRepository organizationRepository;
	
	@Autowired
	private CurrencyRepository currencyRepository;

	@Override
	@PosmoLogDebug
	public OrganizationConfigurationDto addConfiguration(OrganizationConfigurationDto organizationConfigurationDto) {

		OrganizationConfiguration entity = organizationConfigurationMapper
				.convertToOrganizationConfigEntity(organizationConfigurationDto);
		return organizationConfigurationMapper
				.convertToOrganizationConfigDto(organizationConfigurationRepository.save(entity));
	}

	@Override
	public DepartmentConfigurationDto addDepartmentConfiguration(DepartmentConfigurationDto departmentConfigurationDto) throws ConfigurationNotFoundException {
		if(departmentConfigurationRepository.existsById(departmentConfigurationDto.getId())){
			DepartmentConfigurationDto departmentConfigurationDto1 = departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfigurationRepository.getOne(departmentConfigurationDto.getId()));

			CustomDepartmentDto departmentDto = departmentConfigurationDto.getCustomDepartment().get(0);

			departmentConfigurationDto1.getCustomDepartment().add(departmentDto);
			DepartmentConfiguration departmentConfiguration = departmentConfigurationMapper.convertToDepartmentConfigurationEntity(departmentConfigurationDto1);
			return departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfigurationRepository.save(departmentConfiguration));
		}else{
			DepartmentConfiguration departmentConfiguration = departmentConfigurationMapper.convertToDepartmentConfigurationEntity(departmentConfigurationDto);
			return  departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfigurationRepository.save(departmentConfiguration));
		}
	}

	@Override
	public DepartmentConfigurationDto editDepartmentConfiguration(DepartmentConfigurationDto departmentConfigurationDto) throws ConfigurationNotFoundException {
		DepartmentConfigurationDto departmentConfigurationDto1 = departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfigurationRepository.getOne(departmentConfigurationDto.getId()));
		UUID id = departmentConfigurationDto.getCustomDepartment().get(0).getCustomId();
		CustomDepartmentDto departmentDto = departmentConfigurationDto.getCustomDepartment().get(0);
		int i = 0;
		for (CustomDepartmentDto departmentDto1 : departmentConfigurationDto1.getCustomDepartment()) {
			if (departmentDto1.getCustomId().equals(id)) {
				break;

			}
			i++;
		}

		if (i < departmentConfigurationDto1.getCustomDepartment().size()) {
			departmentConfigurationDto1.getCustomDepartment().remove(i);
		}

		departmentConfigurationDto1.getCustomDepartment().add(departmentDto);
		DepartmentConfiguration departmentConfiguration = departmentConfigurationMapper.convertToDepartmentConfigurationEntity(departmentConfigurationDto1);
		return departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfigurationRepository.save(departmentConfiguration));
	}

	@Override
	public DepartmentConfigurationDto getDepartmentConfigurationById(UUID id) throws ConfigurationNotFoundException {
		if(departmentConfigurationRepository.existsById(id)){
		DepartmentConfiguration departmentConfiguration = departmentConfigurationRepository.getOne(id);
		return departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfiguration);
	}else
		throw new ConfigurationNotFoundException("Department Configuration Not Found");
}

	@Override
	public String deleteDepartmentConfiguration(UUID id, UUID customId) throws ConfigurationNotFoundException {
		DepartmentConfigurationDto departmentConfigurationDto1 = departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfigurationRepository.getOne(id));
		int i = 0;
		for (CustomDepartmentDto departmentDto1 : departmentConfigurationDto1.getCustomDepartment()) {
			if (departmentDto1.getCustomId().equals(customId)) {
				break;

			}
			i++;
		}

		if (i < departmentConfigurationDto1.getCustomDepartment().size()) {
			departmentConfigurationDto1.getCustomDepartment().remove(i);
		}

		DepartmentConfiguration departmentConfiguration = departmentConfigurationMapper.convertToDepartmentConfigurationEntity(departmentConfigurationDto1);
		departmentConfigurationMapper.convertToDepartmentConfigurationDto(departmentConfigurationRepository.save(departmentConfiguration));
		return "Department Configuration Deleted Successfully";
	}


	@Override
	@PosmoLogDebug
	public OrganizationConfigurationDto updateConfiguration(OrganizationConfigurationDto OrganizationConfigurationDto,
			UUID organizationId) throws ConfigurationNotFoundException {

		OrganizationConfiguration configuration = organizationConfigurationMapper
				.convertToOrganizationConfigEntity(OrganizationConfigurationDto);
		Optional<Organization> optionalOrganization = organizationRepository.findById(organizationId);

		Organization organization = null;

		if (optionalOrganization.isPresent()) {

			organization = optionalOrganization.get();

			if (organization.getOrganizationConfiguration() != null) {

				configuration = organizationConfigurationRepository
						.getOne(organization.getOrganizationConfiguration().getId());
				organizationConfigurationMapper.updateOrganizationConfig(OrganizationConfigurationDto, configuration);
				organization = organizationRepository.save(organization);
			} else {
				organization.setOrganizationConfiguration(configuration);
				organization = organizationRepository.save(organization);
			}
		}

		return organizationConfigurationMapper.convertToOrganizationConfigDto(organization.getOrganizationConfiguration());
	}

	@Override
	public OrganizationConfigurationDto getConfigurationById(UUID id) {
		OrganizationConfiguration entity = organizationConfigurationRepository.getOne(id);
		OrganizationConfigurationDto organizationConfigurationDto;
		organizationConfigurationDto = organizationConfigurationMapper.convertToOrganizationConfigDto(entity);

		return organizationConfigurationDto;
	}

	

	

	@Override
	public OrganizationConfigurationDto findByOrganizationId(UUID id) throws ConfigurationNotFoundException {

		Organization organization = null;
		OrganizationConfiguration entity = null;
		Optional<Organization> optionalOrganization = organizationRepository.findById(id);
		if (optionalOrganization.isPresent()) {
			organization = optionalOrganization.get();

			if (organization.getOrganizationConfiguration() != null) {
				entity = organization.getOrganizationConfiguration();
				OrganizationConfigurationDto organizationConfigurationDto;
				return organizationConfigurationDto = organizationConfigurationMapper.convertToOrganizationConfigDto(entity);
			} else {
				return null;
			}
		}
		return null;

	}
	
	@Override

	public List<CurrencyDto> getAllCurrencyList() throws ConfigurationNotFoundException {

		List<Currency> currencyTypes = currencyRepository.findUniqueCurrencyType();

		List<CurrencyDto> currencyDtos = new ArrayList<>();

		for (Currency currencytype: currencyTypes) {

			currencyDtos.add(new CurrencyDto(currencytype.getId(), currencytype.getCurrencyType() ,currencytype.getSymbol()));

		}

		return currencyDtos;

	}

	 

	@Override
	public List<CurrencyDto> saveCurrencyList(List<CurrencyDto> currencyDtos) throws CurrencyAlreadyExistsException {

		List<Currency> currencies =new ArrayList<>();
		currencyDtos.forEach(currencyDto -> currencies.add(new Currency(UUID.randomUUID(), currencyDto.getCurrencyType(), currencyDto.getSymbol())));
		currencies.forEach(currency -> {
			currency = currencyRepository.save(currency);
		});


		List<CurrencyDto> currencyDtoList = new ArrayList<>();

		for (Currency currency: currencies) {

			currencyDtoList.add(new CurrencyDto(currency.getId(), currency.getCurrencyType() ,currency.getSymbol()));

		}

		return currencyDtoList;

	}

	

	}

