package com.posmo.administrationservice.service;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.posmo.administrationservice.dto.OrganizationDto;
import com.posmo.administrationservice.dto.OrganizationIntegrationDto;
import com.posmo.administrationservice.exceptions.IntegrationNotFoundException;
import com.posmo.administrationservice.exceptions.OrganizationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.OrganizationIntegrationAlreadyExistsException;
import com.posmo.administrationservice.exceptions.OrganizationNotFoundException;
import com.posmo.administrationservice.exceptions.UserOrganizationAlreadyExistsException;

@Service
public interface OrganizationService {


	OrganizationDto addOrganization(OrganizationDto organizationDto) throws OrganizationAlreadyExistsException, Exception;

	OrganizationDto findByUUID(UUID organizationUUID);

	String deleteOrganization(UUID organizationUUID) throws OrganizationNotFoundException;

	OrganizationDto editOrganization(OrganizationDto OrganizationDto) throws OrganizationNotFoundException;

	OrganizationDto addOrganizationIntegrations(OrganizationDto OrganizationDto)
			throws OrganizationIntegrationAlreadyExistsException;

	OrganizationIntegrationDto editIntegrationStatus(UUID id, boolean integrationStatus, String integrationCredentials)
			throws IntegrationNotFoundException;

	List<OrganizationIntegrationDto> getOrganizationIntegrations(UUID organizationId) throws OrganizationNotFoundException;

	List<OrganizationDto> getOrganizationDetails(UUID clientId) throws OrganizationNotFoundException;

	List<OrganizationDto> getOrganizationDetails() throws OrganizationNotFoundException;

	OrganizationDto getOrganizationById(UUID id) throws OrganizationNotFoundException;

	String addOrganizationToUser(UUID userId, UUID OrganizationId)
			throws OrganizationNotFoundException, UserOrganizationAlreadyExistsException;

	String addOrganizationsToUser(UUID userId, List<UUID> organizationIds)
			throws OrganizationNotFoundException, UserOrganizationAlreadyExistsException;

	String updateUserOrganizationConnections(UUID userId, List<UUID> organizationIds);

	String updateUserOrganization(UUID userId, UUID organizationId)
			throws UserOrganizationAlreadyExistsException, OrganizationNotFoundException;

	List<OrganizationDto> getAllOrganizations(int limit, int pageNo) throws OrganizationNotFoundException;
	
	String setOrganizationPin(UUID clientId, UUID organizationId, String pin) throws Exception;
	
	String editOrganizationPin(UUID clientId,UUID organizationId, String oldPin, String newPin) throws Exception;

	String verifyOrganizationPin(UUID OrganizationId, String pin) throws Exception;



}
