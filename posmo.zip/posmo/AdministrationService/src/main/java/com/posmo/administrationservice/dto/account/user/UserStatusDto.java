package com.posmo.administrationservice.dto.account.user;

import java.util.UUID;

import com.posmo.administrationservice.model.enums.EStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserStatusDto {

	private UUID id;
	
	private String username;
	private UUID AzureUUID;
	private String azureUPN;
	private EStatus userStatus;
	
	private EStatus accountStatus;
	
	private EStatus accountSubscriptionStatus;
	
}
