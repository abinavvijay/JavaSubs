package com.cmd.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cmd.model.Appointment;

public interface CmdRepository extends JpaRepository<Appointment, UUID>{

}
