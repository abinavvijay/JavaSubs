package com.cmd.controller.dto;

import java.sql.Time;
import java.util.Date;
import java.util.UUID;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.cmd.model.Clinic;
import com.cmd.model.Doctor;
import com.cmd.model.Injury;
import com.cmd.model.Patient;
import com.cmd.model.Report;
import com.cmd.model.TimeSlots;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@Builder                 //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields.
@AllArgsConstructor      //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
public class CmdDto {
	
	private UUID appointmentId;
		
	private Date appointmentDate;
	
	private String durationTime;

	private TimeSlots timeOfAppointmant;	
	
	private Doctor doctor;
	
	private Patient patient;
	
//	private String clinicName;
//	private Clinic clinicName;
//	private String reason;
//	private Report report;
//	private String doctorName;
//	private String patientName;
//	private Injury injury;



	
	
	





	

}
