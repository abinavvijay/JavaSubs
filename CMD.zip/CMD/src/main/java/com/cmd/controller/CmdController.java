package com.cmd.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cmd.controller.dto.CmdDto;
import com.cmd.exception.ThisAppointmentAlreadyExist;
import com.cmd.service.CmdService;
import com.cmd.service.impl.CmdServiceImpl;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@CrossOrigin("*") 
@RequestMapping("/Add New Appointment")
public class CmdController {
	
	@Autowired //The @Autowired annotation is auto wire the bean by matching data type if spring container find more than one beans same data type then it find by name. You can use @Autowired annotation on setter methods to get ref id of the <property> element in XML configuration file
	private CmdServiceImpl service;
	


	@Operation(summary = "Creating New Appointment")
	@PostMapping(value = "/add appointment")  // These annotations will map the HTTP web requests to the specific handler methods. Annotation for mapping HTTP GET requests onto specific handler methods.
	public ResponseEntity<?> post(@RequestBody CmdDto cmdDto) {    // @RequestBody puts the return value into the body of the response
	ResponseEntity<?> response;    // ResponseEntity also allows us to add headers and status code.  
                                  


	try {
		
		
		response = new ResponseEntity<>(service.addAppointment(cmdDto), HttpStatus.OK);     // an HTTP response, including headers
	} catch (ThisAppointmentAlreadyExist e) {
		
		response = new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
	}

	return response;
}
}
