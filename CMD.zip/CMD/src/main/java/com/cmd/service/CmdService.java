package com.cmd.service;

import com.cmd.controller.dto.CmdDto;
import com.cmd.exception.ThisAppointmentAlreadyExist;
import com.cmd.model.Appointment;

public interface CmdService {
	
	//public Appointment addAppointment();

	public Appointment addAppointment(CmdDto cmdDto) throws ThisAppointmentAlreadyExist ;

}
