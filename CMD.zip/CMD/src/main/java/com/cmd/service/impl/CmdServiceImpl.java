package com.cmd.service.impl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmd.controller.dto.CmdDto;
import com.cmd.exception.ThisAppointmentAlreadyExist;
import com.cmd.mapper.CmdMapper;
import com.cmd.model.Appointment;
import com.cmd.repository.CmdRepository;
import com.cmd.service.CmdService;

@Service
public class CmdServiceImpl implements CmdService{
	
	@Autowired
	private CmdRepository cmdRepo;
	
	@Autowired
	private CmdMapper mapper;

//	@Override
//	public Appointment addAppoinment() {
//		// TODO Auto-generated method stub
//		return null;
	//}
	
	@Override
	public Appointment addAppointment(CmdDto cmdDto) throws ThisAppointmentAlreadyExist {
		Appointment appointment = new Appointment();
		
		appointment.setAppointmentId(cmdDto.getAppointmentId());
		appointment.setAppointmentDate(cmdDto.getAppointmentDate());
		appointment.setTimeOfAppointmant(cmdDto.getTimeOfAppointmant());
		appointment.setDurationTime(cmdDto.getDurationTime());

			if (cmdRepo.existsById(appointment.getAppointmentId())) {

				throw new ThisAppointmentAlreadyExist ("Patient alreday have an appointment");

		}
		appointment = cmdRepo.saveAndFlush(appointment);

		return mapper.convertToDto(appointment);

	}
	
	
	

}
