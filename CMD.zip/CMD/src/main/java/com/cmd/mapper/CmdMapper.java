package com.cmd.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.cmd.controller.dto.CmdDto;
import com.cmd.model.Appointment;

@Mapper
public interface CmdMapper {
	
	CmdMapper INSTANCE = Mappers.getMapper(CmdMapper.class); //Factory for obtaining mapper instances if no explicit component model such as CDI is configured via Mapper.componentModel().
	
	@Mapping(target = "appointmentId",  source = "appointment.appointmentId")
	@Mapping(target = "doctor", source = "appointment.doctor")
	@Mapping(target = "patient", source = "appointment.patient")
	@Mapping(target = "durationTime", source = "appointment.durationTime")
	@Mapping(target = "appointmentDate", source = "appointment.appointmentDate")
	@Mapping(target = "timeOfAppointmant", source = "appointment.timeOfAppointmant")
//	@Mapping(target = "injury", source = "appointment.patient.injury")
//	@Mapping(target = "clinicName", source = "appointment.clinicName")
//	@Mapping(target = "report", source = "appointment.patient.report")
	
	//public CmdDto converttoDto(Appointment appointment);

	public Appointment convertToDto(Appointment appointment);





	

	



}
