package com.cmd.exception;

public class ThisAppointmentAlreadyExist extends Exception {

	public ThisAppointmentAlreadyExist(String string) {
		// TODO Auto-generated constructor stub
	}

}
