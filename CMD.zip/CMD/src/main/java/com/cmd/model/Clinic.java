package com.cmd.model;

import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data                                    //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields.
@Entity
@NoArgsConstructor
@AllArgsConstructor

public class Clinic {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private UUID clinicId;
	
	private String clinicName;
	
	private int code;
	
//	@ManyToOne(cascade = CascadeType.ALL )
//	@JoinColumn(name = "doctorId", referencedColumnName = "id")
//	private List<Doctor> doctor;
	

}
