package com.cmd.model;

import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data                            //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields.
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Doctor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID doctorId;
	
	private String doctorName;
	
	private String specilazation;
	
	private int avialTime;
	
//	@OneToMany(targetEntity = Patient.class, cascade = CascadeType.ALL)
//	@JoinColumn(name = "doctorId", referencedColumnName = "doctorId")
//	private List<Patient> patient;
//	
//	@OneToMany(targetEntity = Doctor.class, cascade = CascadeType.ALL)
//	@JoinColumn(name = "appointmentId", referencedColumnName = "appointmentId")
//	private List<Appointment> appointments;
	
	@OneToOne(cascade = {CascadeType.ALL})
	private Clinic clinic;
	


	
	

}
