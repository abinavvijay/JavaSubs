package com.cmd.model;

import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data                                             //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields.
@Entity
@NoArgsConstructor
@AllArgsConstructor

public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private UUID patientId;
	
	private String patientName;
	
	private int time;
	
	@OneToOne(cascade = CascadeType.ALL)	
	private Report report;
	
	@Enumerated(EnumType.STRING)
	private Injury injury;
	
	@OneToOne(cascade = {CascadeType.ALL})
	private Appointment appointment;
	


}
