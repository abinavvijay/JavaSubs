package com.cmd.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data                                    //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields. 
@Entity                                  //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {

	@Id              //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private UUID appointmentId;
			
	
	private String reason;
	
	@Enumerated(EnumType.STRING)
	private TimeSlots timeOfAppointmant;	
	
	@OneToOne(cascade = CascadeType.ALL)    //Specifies a single-valued association to another entity that hasone-to-one multiplicity.
	private Doctor doctor;                  // It is not normally necessary to specify the associated target entity explicitly since it can usually beinferred from the type of the object being referenced.
	
	@OneToOne(cascade = CascadeType.ALL)
	private Patient patient;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Clinic clinicName;
	
	private Date appointmentDate;

	private String durationTime;
	
	private String patientName;

	
	
	

}
