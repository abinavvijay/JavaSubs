package com.cmd.model;

public enum TimeSlots {
	
	SLOT1_9_30AM,
	SLOT2_10AM,
	SLOT3_10_30AM,
	SLOT4_12PM,
	SLOT5_12_30PM,
	SLOT6_1PM,
	SLOT7_3PM,
	SLOT8_3_30PM,
	SLOT9_4PM,
	SLOT10_4_30PM,
	SLOT10_5_30PM,
	SLOT11_6_30PM,
	SLOT12_7PM,
	


}
