package com.cmd.model;

public enum ReportType {
	
	DOC,
	JPG,
	TXT,
	PDF

}
