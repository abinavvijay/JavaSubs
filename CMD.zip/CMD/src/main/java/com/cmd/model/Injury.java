package com.cmd.model;

public enum Injury {
	
	ACCIDENT,
	FEVER,
	COUGH,
	HEADACHE,
	MAJOR_HEALTHISSUE,
	HEARTPAIN,
	KINDEY,
	LUNGS,
	CHECKUPS
	

}
