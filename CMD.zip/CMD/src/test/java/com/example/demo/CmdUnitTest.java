package com.example.demo;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cmd.controller.dto.CmdDto;
import com.cmd.exception.ThisAppointmentAlreadyExist;
import com.cmd.mapper.CmdMapper;
import com.cmd.model.Appointment;
import com.cmd.repository.CmdRepository;
import com.cmd.service.CmdService;

@WebMvcTest
public class CmdUnitTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CmdApplicationTests cmdTest;
	
	@MockBean
	private CmdService service;
	
	@MockBean
	private CmdMapper mapper;
	
	@MockBean
	private CmdRepository cmdRepo;
	
	
	@Test	
	public Appointment addAppointment(CmdDto cmdDto) throws Exception {
		String urlString = "/appointment/addAppointment/14d06f26-08d4-4390-9de7-c3ec008a8ee9";

		Appointment appointment = new Appointment();
		
		appointment.setAppointmentId(cmdDto.getAppointmentId());
		appointment.setAppointmentDate(cmdDto.getAppointmentDate());
		appointment.setTimeOfAppointmant(cmdDto.getTimeOfAppointmant());
		appointment.setDurationTime(cmdDto.getDurationTime());

			if (cmdRepo.existsById(appointment.getAppointmentId())) {

				throw new ThisAppointmentAlreadyExist ("Patient alreday have an appointment");

		}
		appointment = cmdRepo.saveAndFlush(appointment);

		
		
		Mockito.when(service.addAppointment(Mockito.any(CmdDto.class))).thenReturn(appointment);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(urlString);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String expectedString = "{\"appointmentId\": \"14d06f26-08d4-4390-9de7-c3ec008a8ee9\",\r\n"
				+ "				  \"appointmentDate\": \"2022-04-13T12:10:08.058Z\",\r\n"
				+ "				  \"durationTime\": \"string\",\r\n"
				+ "				  \"timeOfAppointmant\": \"SLOT1_9_30AM\",\r\n"
				+ "				  \"doctor\": {\r\n"
				+ "				    \"doctorName\": \"string\",\r\n"
				+ "				    \"specilazation\": \"string\",\r\n"
				+ "				    \"avialTime\": 0\r\n"
				+ "				  },\r\n"
				+ "				  \"patient\": {\r\n"
				+ "				      \"reportType\": \"DOC\",\r\n"
				+ "				    },\r\n"
				+ "				    \"injury\": \"ACCIDENT\"\r\n"
				+ "				  }";
	
	return mapper.convertToDto(appointment);
	
}
	
}
