package com.ros.administrationservice.service;

import java.util.List;
import java.util.Set;
import java.util.UUID;

//import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.posmo.administrationservice.controller.dto.RestaurantDto;
import com.posmo.administrationservice.controller.dto.account.ClientAddDto;
import com.posmo.administrationservice.controller.dto.account.user.AllUserPermissionsDto;
import com.posmo.administrationservice.controller.dto.account.user.DetailedUserInfoDto;
import com.posmo.administrationservice.controller.dto.account.user.UserAddDto;
import com.posmo.administrationservice.controller.dto.account.user.UserDetailsDto;
import com.posmo.administrationservice.controller.dto.account.user.UserDto;
import com.posmo.administrationservice.controller.dto.account.user.UserInfoDto;
import com.posmo.administrationservice.controller.dto.account.user.UserRestaurantDto;
import com.posmo.administrationservice.controller.dto.account.user.UserStatusDto;
import com.ros.administrationservice.exceptions.PrimaryContactNotFoundException;
import com.ros.administrationservice.exceptions.UserAlreadyExistsException;
import com.ros.administrationservice.exceptions.UserNotFoundException;
import com.ros.administrationservice.model.account.User;
import com.ros.administrationservice.model.account.UserProfile;
import com.ros.administrationservice.model.enums.EStatus;

@Service
public interface UserService {


//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;
	
	AllUserPermissionsDto getUserPermissions(String username)throws UserNotFoundException;
	
	AllUserPermissionsDto getUserPermissions(UUID userUUID)throws UserNotFoundException;
	
	UserInfoDto getUserInfo (String username) throws UserNotFoundException;
	
	public UserStatusDto getUserStatus (String username) throws UserNotFoundException;
	
	public UserRestaurantDto getRestaurantsForUser(String username) throws UserNotFoundException;
	
	UserDto addUser (UserDto user) throws UserAlreadyExistsException, Exception;

	UserDto findByUUID(UUID userUUID);

	String deleteUser(String username) throws UserNotFoundException;

	DetailedUserInfoDto getDetailedUserInfo(String username) throws UserNotFoundException;

	UserDto editUser(UserDto userDto) throws UserNotFoundException;

	UserDto getUser(String username) throws UserNotFoundException;

	List<UserDto> getAllUserInfo()  throws UserNotFoundException;

	List<UserDto> getUserInfoByRestaurantId(UUID restaurantId)throws UserNotFoundException;

	UserDto addUser(UserAddDto userAddDto, String subscriptionCode, UUID accountId) throws UserAlreadyExistsException;

	List<UserDto> getAllUserInfo(int limit, int pageNo)throws UserNotFoundException;

	void addRestaurantToSuperAdmins(UUID id) throws UserNotFoundException;

	UserDto addROSTeam(UserAddDto userDto) throws UserAlreadyExistsException;

	User saveClientAsUser(ClientAddDto clientAddDto)throws PrimaryContactNotFoundException;

	UserProfile setUserProfileForClient(ClientAddDto client);

	User saveAccountAndSubscriptionData(String username, String subscriptionCode, UUID accountId);

	UserDto editUserStatus(UUID userId, EStatus status)throws UserNotFoundException;
	
	UserDetailsDto getUserDetails(String username) throws UserNotFoundException;
	
	String addROSTeamPin(String username, String pin) throws Exception;
	
	Set<RestaurantDto> validateEntryPin(String pin) throws Exception;

	String editTabletPin(String username, String oldPin, String newpin) throws Exception;
	
	
}
