package com.ros.administrationservice.model.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import com.ros.administrationservice.model.Address;
import com.ros.administrationservice.model.BaseEntity;
import com.ros.administrationservice.model.Restaurant;

import java.io.Serializable;
import java.net.URI;
import java.util.List;
import java.util.UUID;

@Data
@EqualsAndHashCode(exclude =  "restaurants")
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Client extends BaseEntity implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "client_id",length = 16)
	private UUID id;
	
	@Column(name = "business_name")
	private String name;

	@Column(name = "legal_name")
	private String legalName;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "client_id")
	private List<Restaurant> restaurants;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "account_id")
	private Account account;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id")
	private Address address;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "primary_contact_id")
	private PrimaryContact primaryContact;

}
