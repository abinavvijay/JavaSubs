package com.ros.administrationservice.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ros.administrationservice.model.account.Role;
import com.ros.administrationservice.model.enums.ERole;


public interface RoleRepository extends JpaRepository<Role, UUID> {
	Optional<Role> findByName(ERole name);

	
}
