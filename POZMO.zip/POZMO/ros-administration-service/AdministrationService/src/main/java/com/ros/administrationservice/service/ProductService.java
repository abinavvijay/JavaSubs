package com.ros.administrationservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.posmo.administrationservice.controller.dto.ProductDto;
import com.posmo.administrationservice.controller.dto.ProductModulesAndSubCountDto;
import com.ros.administrationservice.exceptions.ProductNotFoundException;

@Service
public interface ProductService {

	List<ProductDto> getAllProducts() throws ProductNotFoundException;

	ProductModulesAndSubCountDto getProductModulesAndSubCount(String productCode) throws ProductNotFoundException;
}
