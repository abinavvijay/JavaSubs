package com.ros.administrationservice.model.enums;

public enum IntegrationType {
	POS,
	DELIVERY,
	PAYMENT

}
