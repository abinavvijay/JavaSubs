package com.ros.administrationservice.model.enums;

public enum Gender {
MALE,FEMALE
}
