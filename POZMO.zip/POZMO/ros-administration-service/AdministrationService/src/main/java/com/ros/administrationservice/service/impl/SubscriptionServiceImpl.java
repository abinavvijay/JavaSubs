package com.ros.administrationservice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.posmo.administrationservice.controller.dto.ProductDto;
import com.posmo.administrationservice.controller.dto.account.AccountSubscriptionDto;
import com.ros.administrationservice.controller.dto.subscription.SubscriptionDto;
import com.ros.administrationservice.exceptions.AccountSubscriptionNotFoundException;
import com.ros.administrationservice.exceptions.SubscriptionAlreadyExistsException;
import com.ros.administrationservice.exceptions.SubscriptionNotFoundException;
import com.ros.administrationservice.mapper.ProductMapper;
import com.ros.administrationservice.mapper.SubscriptionMapper;
import com.ros.administrationservice.model.Feature;
import com.ros.administrationservice.model.Product;
import com.ros.administrationservice.model.subscription.Subscription;
import com.ros.administrationservice.model.subscription.SubscriptionFeature;
import com.ros.administrationservice.model.subscription.enums.SubcriptionFrequency;
import com.ros.administrationservice.model.subscription.enums.SubscriptionName;
import com.ros.administrationservice.model.subscription.enums.SubscriptionPricingType;
import com.ros.administrationservice.repository.FeatureRepository;
import com.ros.administrationservice.repository.PricingRepository;
import com.ros.administrationservice.repository.ProductRepository;
import com.ros.administrationservice.repository.SubscriptionFeatureRepository;
import com.ros.administrationservice.repository.SubscriptionPackageSpecificationRepository;
import com.ros.administrationservice.repository.SubscriptionRepository;
import com.ros.administrationservice.service.SubscriptionService;
import com.ros.administrationservice.util.Properties;


@Service
public class SubscriptionServiceImpl implements SubscriptionService {
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private SubscriptionFeatureRepository subscriptionFeatureRepository;
	
	@Autowired
	private FeatureRepository FeatureRepository;
	
	@Autowired
	private SubscriptionPackageSpecificationRepository packageSpecificationRepository;
	
	@Autowired
	private PricingRepository pricingRepository;
	
	@Autowired
	private SubscriptionMapper subscriptionMapper;
	
	@Autowired
	private ProductMapper productMapper;

	@Override
	public SubscriptionDto addSubscription(SubscriptionDto subsciptionDto) throws SubscriptionAlreadyExistsException {

		Subscription subscription = subscriptionMapper.convertToSubscription(subsciptionDto);
		if(getCodeIfSubscriptionExists(subsciptionDto.getSubscriptionCode())==null) {
			subscription = subscriptionRepository.save(subscription);
			SubscriptionDto subscriptionDto= subscriptionMapper.convertToSubscriptionDto(subscription);
			 return subscriptionDto;
		}
		else {
			throw new SubscriptionAlreadyExistsException(Properties.subscriptionAlreadyExists+subsciptionDto.getSubscriptionCode());
		}
	}

	private String getCodeIfSubscriptionExists(String subscriptionCode) {
		Optional<Subscription> subscription =subscriptionRepository.findBySubscriptionCode(subscriptionCode);
		if(subscription.isPresent()) {
			return subscription.get().getSubscriptionCode();
		}
		return null;
	}

	@Override
	public List<String> getSubscriptionFrequency() {
		SubcriptionFrequency frequency = SubcriptionFrequency.getInstance();
		return frequency.getSubscriptionFrequency();
	}

	@Override
	public List<String> getSubscriptionName() {
		SubscriptionName subscriptionName = SubscriptionName.getInstance();
		return subscriptionName.getSubscriptionName();
	}

	@Override
	public List<String> getSubscriptionPricingType() {
		SubscriptionPricingType subscriptionPricingType = SubscriptionPricingType.getInstance();
		return subscriptionPricingType.getSubscriptionPricingType();
	}
	
	@Override
	public List<SubscriptionDto> getAllSubscriptions() {
		List<Subscription> subscriptions = subscriptionRepository.findSubscriptions();
		List<SubscriptionDto> subscriptionDtoList = new ArrayList<>();
		if (subscriptions != null && !subscriptions.isEmpty()) {
			for (Subscription subscription : subscriptions) {
				SubscriptionDto subscriptionDto = subscriptionMapper.convertToSubscriptionDto(subscription);
				subscriptionDtoList.add(subscriptionDto);
			}
		}
		return subscriptionDtoList;
	}
	
	@Override
	public SubscriptionDto getSubscriptionById(UUID id) {
		Subscription subscription = subscriptionRepository.getById(id);
		SubscriptionDto subscriptionDto = subscriptionMapper.convertToSubscriptionDto(subscription);
		return subscriptionDto;
	}
	
	@Override
	public String updateActiveOrDeactiveSubscription(SubscriptionDto subsciptionDto) {
		Subscription subscription = subscriptionRepository.getById(subsciptionDto.getId());
		subscription.setSubscriptionActive(subsciptionDto.isSubscriptionActive());
		subscription=subscriptionRepository.save(subscription);
		String statusMsg;
		if(subscription.isSubscriptionActive()){
			statusMsg = "Activition of subscription Successfully.";
		} else {
			statusMsg = "Deactivition of subscription Successfully.";
		}
		return statusMsg;
	}
	
	@Override
	public SubscriptionDto editSubscription(SubscriptionDto subsciptionDto) throws SubscriptionNotFoundException {
		Subscription subscription = subscriptionRepository.getById(subsciptionDto.getId());
		if(subscription!=null) {
			subscription = subscriptionMapper.convertToSubscription(subsciptionDto);
			subscription = subscriptionRepository.save(subscription);
		}
		else {
			throw new SubscriptionNotFoundException(Properties.subscriptionNotFound);
		}
		return subscriptionMapper.convertToSubscriptionDto(subscription);
	}

	@Override
	public SubscriptionDto configureSubscription(SubscriptionDto subscriptionDto) throws SubscriptionNotFoundException{	
		Subscription subscription = subscriptionRepository.getById(subscriptionDto.getId());
		if(subscription!=null) {
		subscriptionMapper.updateSubscriptionFeatures(subscriptionDto.getSubscriptionFeatures(),subscription.getSubscriptionFeatures());
		subscription=subscriptionRepository.save(subscription);
		}
		else {
			throw new SubscriptionNotFoundException(Properties.subscriptionNotFound);
		}
		return subscriptionMapper.convertToSubscriptionDto(subscription);
		
		}
	

	@Override
	public ProductDto addProduct(ProductDto productDto) {
		Product product = productMapper.convertToProduct(productDto);
		product = productRepository.save(product);
		return productMapper.convertToProductDto(product);
	}

	@Override
	public List<String> getAllProductName() {
		List<Product> products = productRepository.findAll();
		List<String> productNames = new ArrayList<>();
		if(products!=null && !products.isEmpty()) {
			for(Product product : products) {
				productNames.add(product.getProductName());
			}
		}
		return productNames;
	}
	
	private String generateSubscriptionCode() {
		Random random = new Random();
		int val = random.nextInt();
		String hex = new String();
		hex = Integer.toHexString(val);
		return hex;
	}

	@Override
	public String setAllSubscriptionFeatures(String subscriptionCode) throws SubscriptionNotFoundException {
		List<Feature> features = FeatureRepository.findFeatures();
		Optional<Subscription> optSubscription = subscriptionRepository.findBySubscriptionCode(subscriptionCode);
		if(optSubscription.isPresent()){
			Subscription subscription = optSubscription.get();
		
		for (Feature feature : features) {
			Optional<SubscriptionFeature> optSubFeature = subscriptionFeatureRepository.findSubscriptionFeatureForUserPermission(subscriptionCode,feature.getFeatureCode());
			if(optSubFeature.isEmpty()) {
				SubscriptionFeature subFeature = new SubscriptionFeature(UUID.randomUUID(), subscription, feature, true);
				subscription.getSubscriptionFeatures().add(subFeature);
				
			}
		} 
		subscription =subscriptionRepository.save(subscription);
		return Properties.allSubscriptionsSaved ;
		}
		else {
			throw new SubscriptionNotFoundException(Properties.subscriptionNotFound);
		}
		
	}

}
