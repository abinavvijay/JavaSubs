package com.ros.administrationservice.model.configuration;

public enum PayrollHours {
    YES,
    NO
}
