package com.ros.administrationservice.model.enums;

public enum EStatus {
ACTIVE,
INACTIVE
}
