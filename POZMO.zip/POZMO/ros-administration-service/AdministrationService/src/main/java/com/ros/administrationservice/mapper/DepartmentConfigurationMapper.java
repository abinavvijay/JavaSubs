package com.ros.administrationservice.mapper;

import com.ros.administrationservice.controller.dto.configuration.DepartmentConfigurationDto;
import com.ros.administrationservice.model.configuration.DepartmentConfiguration;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface DepartmentConfigurationMapper {

//    DepartmentConfiguration convertToDepartmentConfigurationEntity(DepartmentConfigurationDto departmentConfigurationDto);
//    DepartmentConfigurationDto convertToDepartmentConfigurationDto(DepartmentConfiguration departmentConfiguration);

    DepartmentConfiguration convertToDepartmentConfigurationEntity(DepartmentConfigurationDto departmentConfigurationDto);
    DepartmentConfigurationDto convertToDepartmentConfigurationDto(DepartmentConfiguration departmentConfiguration);
}
