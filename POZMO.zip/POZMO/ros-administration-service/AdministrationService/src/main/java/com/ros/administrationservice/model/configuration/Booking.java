package com.ros.administrationservice.model.configuration;

public enum Booking {
    YES,
    NO
}
