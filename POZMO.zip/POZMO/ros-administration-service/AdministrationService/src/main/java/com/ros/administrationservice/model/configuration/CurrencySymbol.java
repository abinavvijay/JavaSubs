package com.ros.administrationservice.model.configuration;

public enum CurrencySymbol {
$,₹,€,£
}
