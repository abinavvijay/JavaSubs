package com.ros.administrationservice.service;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.posmo.administrationservice.controller.dto.RestaurantDto;
import com.posmo.administrationservice.controller.dto.RestaurantIntegrationDto;
import com.ros.administrationservice.exceptions.IntegrationNotFoundException;
import com.ros.administrationservice.exceptions.RestaurantAlreadyExistsException;
import com.ros.administrationservice.exceptions.RestaurantIntegrationAlreadyExistsException;
import com.ros.administrationservice.exceptions.RestaurantNotFoundException;
import com.ros.administrationservice.exceptions.UserRestaurantAlreadyExistsException;

@Service
public interface RestaurantService {

//	public RestaurantDetails loadRestaurantByRestaurantname(String restaurantname) throws RestaurantnameNotFoundException;

	RestaurantDto addRestaurant(RestaurantDto restaurant) throws RestaurantAlreadyExistsException, Exception;

	RestaurantDto findByUUID(UUID restaurantUUID);

	String deleteRestaurant(UUID restaurantUUID) throws RestaurantNotFoundException;

	RestaurantDto editRestaurant(RestaurantDto restaurantDto) throws RestaurantNotFoundException;

	RestaurantDto addRestaurantIntegrations(RestaurantDto restaurantDto)
			throws RestaurantIntegrationAlreadyExistsException;

	RestaurantIntegrationDto editIntegrationStatus(UUID id, boolean integrationStatus, String integrationCredentials)
			throws IntegrationNotFoundException;

	List<RestaurantIntegrationDto> getRestaurantIntegrations(UUID restaurantId) throws RestaurantNotFoundException;

	List<RestaurantDto> getRestaurantDetails(UUID clientId) throws RestaurantNotFoundException;

	List<RestaurantDto> getRestaurantDetails() throws RestaurantNotFoundException;

	RestaurantDto getRestaurantById(UUID id) throws RestaurantNotFoundException;

	String addRestaurantToUser(UUID userId, UUID restaurantId)
			throws RestaurantNotFoundException, UserRestaurantAlreadyExistsException;

	String addRestaurantsToUser(UUID userId, List<UUID> restaurantIds)
			throws RestaurantNotFoundException, UserRestaurantAlreadyExistsException;

	String updateUserRestaurantConnections(UUID userId, List<UUID> restaurantIds);

	String updateUserRestaurant(UUID userId, UUID restaurantId)
			throws UserRestaurantAlreadyExistsException, RestaurantNotFoundException;

	List<RestaurantDto> getAllRestaurants(int limit, int pageNo) throws RestaurantNotFoundException;
	
	String setRestaurantPin(UUID clientId, UUID restaurantId, String pin) throws Exception;
	
	String editRestaurantPin(UUID clientId,UUID restaurantId, String oldPin, String newPin) throws Exception;

	String verifyRestaurantPin(UUID restaurantId, String pin) throws Exception;



}
