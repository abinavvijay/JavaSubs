package com.ros.administrationservice.exceptions;

public class ClientAccountStatusNotFoundException extends Exception {

    public ClientAccountStatusNotFoundException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ClientAccountStatusNotFoundException(String message, Throwable cause, boolean enableSuppression,
                                   boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }

    public ClientAccountStatusNotFoundException(String message, Throwable cause) {
        super(message, cause);

    }

    public ClientAccountStatusNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public ClientAccountStatusNotFoundException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }
}
