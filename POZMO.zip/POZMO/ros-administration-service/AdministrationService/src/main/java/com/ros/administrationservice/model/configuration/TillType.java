package com.ros.administrationservice.model.configuration;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class TillType {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "third_party_id", length = 16)
	private UUID id;

	private String code;

	private String title;

}
