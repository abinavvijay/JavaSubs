package com.posmo.administrationservice.controller.dto.account;

import java.util.UUID;

import com.posmo.administrationservice.controller.dto.CountryDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ClientVatInfoDto {

	private UUID id;

	private CountryDto countryDto;
	
	private String taxRegistrationNo;
}
