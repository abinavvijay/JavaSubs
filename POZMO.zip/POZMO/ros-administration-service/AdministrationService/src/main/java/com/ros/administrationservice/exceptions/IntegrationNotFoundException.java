package com.ros.administrationservice.exceptions;

public class IntegrationNotFoundException extends Exception {

	public IntegrationNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IntegrationNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public IntegrationNotFoundException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public IntegrationNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public IntegrationNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
