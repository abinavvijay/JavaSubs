package com.ros.administrationservice.controller.dto.subscription;

import java.util.UUID;

import com.posmo.administrationservice.controller.dto.FeatureDto;
import com.posmo.administrationservice.controller.dto.account.user.UserPermissionDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionFeatureDto {

	private UUID id;
	
	private String feature;
	
	private boolean subscriptionFeatureActive;
}
