package com.ros.administrationservice.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Value;

public class EmailNotification {
	
	@Value("${EmailDetails.emailAddress}")
	private String EMAILADDRESS;
	
	@Value("${EmailDetails.emailPassword}")
	private String EMAILPASSWORD;

	
	public boolean sendMail (String email, String emailSubject, String emailBody,String name) throws Exception{
		
		String to=email;
		
		

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp-mail.outlook.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        props.put("mail.smtp.starttls.enable","true");
        props.put("mail.smtp.auth", "true");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(EMAILADDRESS,EMAILPASSWORD);
                    }
                });



        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(EMAILADDRESS, "ADMIN"));
        msg.addRecipient(Message.RecipientType.TO,
                new InternetAddress(to, name));
        msg.setSubject(emailSubject);
        msg.setText(emailBody);
        Transport.send(msg);
        System.out.println("\n\n Email sent successfully to: "+email+" \n\n");
		
		
		return true;
		
	}
	
}
