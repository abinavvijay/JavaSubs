package com.posmo.administrationservice.controller.dto;

import java.util.List;
import java.util.UUID;

import com.ros.administrationservice.model.Country;
import com.ros.administrationservice.model.configuration.CurrencySymbol;
import com.ros.administrationservice.model.configuration.CurrencyType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyDto {
	
	private UUID id;

	private CurrencyType currencyType;
	
	private CurrencySymbol symbol;
}
