package com.ros.administrationservice.exceptions;

public class UserRestaurantDeletionException extends Exception {

	public UserRestaurantDeletionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserRestaurantDeletionException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public UserRestaurantDeletionException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public UserRestaurantDeletionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UserRestaurantDeletionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
