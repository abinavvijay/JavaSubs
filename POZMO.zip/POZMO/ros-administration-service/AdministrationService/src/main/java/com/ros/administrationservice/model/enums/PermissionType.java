package com.ros.administrationservice.model.enums;

public enum PermissionType {
	USER_BASED,
	ROLE_BASED
	

}
