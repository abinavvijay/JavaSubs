package com.ros.administrationservice.model.configuration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import com.ros.administrationservice.model.BaseEntity;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class ShiftConfiguration extends BaseEntity implements Serializable {

    @Id
    @Column
    private UUID id;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn
    private List<RestaurantShifts> restaurantShifts;

}
