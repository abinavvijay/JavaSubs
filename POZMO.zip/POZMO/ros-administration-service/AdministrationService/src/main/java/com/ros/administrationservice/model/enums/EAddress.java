package com.ros.administrationservice.model.enums;

public enum EAddress {
POSTAL,
PHYSICAL
}
