package com.ros.administrationservice.model.configuration;

public enum CurrencyType {
	  USD,INR, EUR,GBP

}
