package com.ros.administrationservice.exceptions;

public class PDQMachineNotFoundException extends Exception {

    public PDQMachineNotFoundException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public PDQMachineNotFoundException(String message, Throwable cause, boolean enableSuppression,
                                   boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }

    public PDQMachineNotFoundException(String message, Throwable cause) {
        super(message, cause);

    }

    public PDQMachineNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public PDQMachineNotFoundException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
