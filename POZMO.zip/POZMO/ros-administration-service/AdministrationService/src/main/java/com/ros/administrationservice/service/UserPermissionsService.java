package com.ros.administrationservice.service;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.posmo.administrationservice.controller.dto.account.user.AllUserPermissionsDto;
import com.posmo.administrationservice.controller.dto.account.user.UserDto;
import com.posmo.administrationservice.controller.dto.account.user.UserPermissionDto;
import com.ros.administrationservice.exceptions.PermissionUpdateException;
import com.ros.administrationservice.exceptions.UserNotFoundException;

@Service
public interface UserPermissionsService {

	AllUserPermissionsDto getUserPermissionsById(UUID userId)throws UserNotFoundException;
	
	Boolean saveUserPermissions(UserDto userPermissionDTO) throws PermissionUpdateException;

	AllUserPermissionsDto saveUserPermissions(List<UserPermissionDto> userPermissionDtos, UUID userId)
			throws PermissionUpdateException;

	AllUserPermissionsDto saveUserPermissions(List<UserPermissionDto> userPermissionDtos, String username)
			throws PermissionUpdateException;


	AllUserPermissionsDto configureUserPermissions(List<UserPermissionDto> userPermissionDtos, UUID userUUId)throws UserNotFoundException, PermissionUpdateException;

	String setAllUserPermissions(String username, String subscriptionCode)throws UserNotFoundException;
}
