package com.ros.administrationservice.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ros.administrationservice.model.account.AccountSubscription;

@Repository
public interface AccountSubscriptionRepository extends JpaRepository<AccountSubscription, UUID> {
	@Query(value="select * from account_subscription where account_id = :accountId and subscription_id= :subscriptionId", nativeQuery = true)
	AccountSubscription findAccountSubscription(@Param("accountId") UUID accountId,@Param("subscriptionId") UUID subscriptionId);

	@Query(value="select * from account_subscription where account_id = :accountId limit 1", nativeQuery = true)
	AccountSubscription getMasterAccountSubscription(@Param("accountId") UUID accountId);
}
