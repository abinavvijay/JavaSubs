package com.ros.administrationservice.exceptions;

public class PDQCardNotFoundException extends Exception {

    public PDQCardNotFoundException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public PDQCardNotFoundException(String message, Throwable cause, boolean enableSuppression,
                                   boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }

    public PDQCardNotFoundException(String message, Throwable cause) {
        super(message, cause);

    }

    public PDQCardNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public PDQCardNotFoundException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
