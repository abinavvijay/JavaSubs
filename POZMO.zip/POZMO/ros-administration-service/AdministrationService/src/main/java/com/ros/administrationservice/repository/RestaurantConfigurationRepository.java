package com.ros.administrationservice.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ros.administrationservice.model.account.Client;
import com.ros.administrationservice.model.configuration.RestaurantConfiguration;

@Repository
//
public interface RestaurantConfigurationRepository extends JpaRepository<RestaurantConfiguration, UUID>{

//	@Query("SELECT r FROM RestaurantConfiguration r WHERE r.restaurant.id = :id")
//	public RestaurantConfiguration findByResaurantId(@Param("id") UUID id);
	
}
