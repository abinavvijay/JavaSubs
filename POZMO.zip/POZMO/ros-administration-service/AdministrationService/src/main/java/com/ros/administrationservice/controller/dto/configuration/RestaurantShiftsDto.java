package com.ros.administrationservice.controller.dto.configuration;

import lombok.Data;

import java.util.UUID;

import com.ros.administrationservice.model.configuration.Booking;
import com.ros.administrationservice.model.configuration.PayrollHours;
import com.ros.administrationservice.model.configuration.Schedule;

@Data
public class RestaurantShiftsDto {
    private UUID shiftId;

    private String shiftName;

    private String shiftDescription;

    private int breakDuration;

    private Booking booking;

    private PayrollHours payrollHours;

    private Schedule schedule;
}
