package com.hackathon.petzey.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.petzey.controller.dto.AddAppointmentDto;
import com.hackathon.petzey.exception.AddAppointmentException;
import com.hackathon.petzey.service.impl.AddAppointmentServiceImpl;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@CrossOrigin("*") 
@RequestMapping("/Add New Appointment")
public class AddAppointmentController {

	@Autowired
	private AddAppointmentServiceImpl service;
	
	@Operation(summary = "Creating New Appointment")
	@PostMapping(value = "/add appointment")  // These annotations will map the HTTP web requests to the specific handler methods. Annotation for mapping HTTP GET requests onto specific handler methods.
	public ResponseEntity<?> post(@RequestBody AddAppointmentDto adddDto) {    // @RequestBody puts the return value into the body of the response
	ResponseEntity<?> response;    // ResponseEntity also allows us to add headers and status code.  
                                  


	try {
		
		
		response = new ResponseEntity<>(service.addAppointment(adddDto), HttpStatus.OK);     // an HTTP response, including headers
	} catch (AddAppointmentException e) {
		
		response = new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
	}

	return response;
}
}
