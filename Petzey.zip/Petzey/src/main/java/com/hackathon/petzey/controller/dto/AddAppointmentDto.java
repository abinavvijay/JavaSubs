package com.hackathon.petzey.controller.dto;

import java.util.Date;
import java.util.UUID;

import com.hackathon.petzey.model.Clinic;
import com.hackathon.petzey.model.Doctor;
import com.hackathon.petzey.model.Owner;
import com.hackathon.petzey.model.Pet;
import com.hackathon.petzey.model.TimeSlots;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder                 //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields.
@AllArgsConstructor      //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
public class AddAppointmentDto {
	
	private UUID appointment_Id;
	
    private Date appointmentDate;
    
    private Doctor doctorName;
    
	private TimeSlots timeOfAppointment;	
	
	private String petname;
	
	private String reason;
	
	private Clinic clinicName;
	
	private Owner ownerName;
	
	
}
