package com.hackathon.petzey.model;

public enum AppointmentStatus {

	Booked,
	Cancelled,
	Pending,
	Datechange
}
