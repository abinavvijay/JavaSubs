package com.hackathon.petzey.model;

public enum PetCategory {
	
	DOG,
	CAT,
	BIRD,
	HAMSTER,
	RABBIT,
	LIZARD,
	RAT

}
