package com.hackathon.petzey.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hackathon.petzey.model.Appointment;



public interface AddAppointmentRepository extends JpaRepository<Appointment, UUID>{

}
