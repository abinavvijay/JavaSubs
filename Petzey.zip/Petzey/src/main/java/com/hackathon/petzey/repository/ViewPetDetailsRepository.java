package com.hackathon.petzey.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hackathon.petzey.model.Appointment;
import com.hackathon.petzey.model.Pet;

public interface ViewPetDetailsRepository extends JpaRepository<Appointment, UUID>{
	
	@Query(value = "select s from Appointment s where s.id=:id")
	public Pet findAppointmentById(@Param(value = "id") UUID pet_Id);


}
