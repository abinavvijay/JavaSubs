package com.hackathon.petzey.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.petzey.exception.ViewPetException;
import com.hackathon.petzey.service.impl.ViewPetDetailsServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@CrossOrigin("*") 
@RequestMapping("/View Pet Details")
public class ViewPetDetailsController {

	@Autowired
	private ViewPetDetailsServiceImpl service;
	

	@Operation(summary = "View Pet Details")
	@GetMapping(value = "/view Pet Details/{pet_Id}")
	public ResponseEntity<?> getPet(@PathVariable(value = "pet_Id") UUID pet_Id) throws ViewPetException {
		ResponseEntity<?> response = null;

		try {
			response = new ResponseEntity<>(service.viewPet(pet_Id), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
		}

		return response;
	}
}

