package com.hackathon.petzey.controller.dto;


import com.hackathon.petzey.model.AppointmentReport;
import com.hackathon.petzey.model.Owner;
import com.hackathon.petzey.model.Pet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder                 //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields.
@AllArgsConstructor      //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
public class ViewPetDetailsDto {
	
	private Pet pet_Id;
	
	private Owner owner;
	
	private AppointmentReport appointmentReport;

}
