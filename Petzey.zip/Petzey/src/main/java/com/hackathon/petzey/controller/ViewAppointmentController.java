package com.hackathon.petzey.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.petzey.exception.ViewAppointmentException;
import com.hackathon.petzey.service.impl.AddAppointmentServiceImpl;
import com.hackathon.petzey.service.impl.ViewAppointmentServiceImpl;

import io.swagger.v3.oas.annotations.Operation;
@RestController
@CrossOrigin("*") 
@RequestMapping("/View Appointment")
public class ViewAppointmentController {
	
	@Autowired
	private ViewAppointmentServiceImpl service;
	

	@Operation(summary = "View Appointment")
	@GetMapping(value = "/view Appointment/{appointment_Id}")
	public ResponseEntity<?> getAppointment(@PathVariable(value = "appointment_Id") UUID appointment_Id) throws ViewAppointmentException {
		ResponseEntity<?> response = null;

		try {
			response = new ResponseEntity<>(service.viewAppointment(appointment_Id), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
		}

		return response;
	}
}
