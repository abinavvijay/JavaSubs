package com.hackathon.petzey.service.impl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hackathon.petzey.exception.ViewAppointmentException;
import com.hackathon.petzey.model.Appointment;
import com.hackathon.petzey.repository.ViewAppointmentRepository;
import com.hackathon.petzey.service.ViewAppointmentService;

@Service
public class ViewAppointmentServiceImpl implements ViewAppointmentService {
	
	@Autowired
	private ViewAppointmentRepository viewRepo;
	
//	@Autowired
//	private ViewAppointmentMapper mapper1;

	@Override
	public Appointment viewAppointment(UUID appointment_Id) throws ViewAppointmentException {
		// TODO Auto-generated method stub

			if (viewRepo.existsById(appointment_Id)) {
				Appointment appointment = viewRepo.findById(appointment_Id).get();
				
				
			} else {
				
				throw new ViewAppointmentException("No appointment is created ");
			}

		
		return null;
//		Appointment appointment = viewRepo.findById(appointment_Id).get();
//		
//		if(appointment == null) {
//			
//			throw new ViewAppointmentException("There is no appointment created");
//
//	}
//		
//		return appointment;	
		}
		
	}

	

