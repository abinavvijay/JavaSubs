package com.hackathon.petzey;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.hackathon.petzey.mapper.AddAppointmentMapper;
import com.hackathon.petzey.mapper.AddAppointmentMapperImpl;
import com.hackathon.petzey.mapper.ViewAppointmentMapper;
import com.hackathon.petzey.mapper.ViewAppointmentMapperImpl;
import com.hackathon.petzey.mapper.ViewPetDetailsMapper;
import com.hackathon.petzey.mapper.ViewPetDetailsMapperImpl;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.servers.Server;

@SpringBootApplication
public class PetzeyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetzeyApplication.class, args);
	}
	
	@Value(value = "${swagger.url}")
	public String url;

	@Bean
	public OpenAPI customOpenAPI() {
		Server server = new Server();
		List<Server> servers = new ArrayList<>();
		server.setUrl(url);
		servers.add(server);
		OpenAPI openAPI = new OpenAPI();
		openAPI.setServers(servers);
		return openAPI;

	}
	
	@Bean
	public AddAppointmentMapper getAddAppointmentMapper() {
		
		return new AddAppointmentMapperImpl();
	}
	
	@Bean
	public ViewAppointmentMapper getViewAppointmentMapper() {
		
		return new ViewAppointmentMapperImpl();
	}
	
	@Bean
	public ViewPetDetailsMapper getViewPetDetailsMapper() {
		
		return new ViewPetDetailsMapperImpl();
		
	}

}



