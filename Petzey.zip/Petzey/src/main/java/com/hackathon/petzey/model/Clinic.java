package com.hackathon.petzey.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data                                    //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields. 
@Entity                                  //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
@AllArgsConstructor
public class Clinic {
	@Id             //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID clinic_Id;
	
	private String name;
	
	private int phoneNumber;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Address address;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Doctor doctor;

}
