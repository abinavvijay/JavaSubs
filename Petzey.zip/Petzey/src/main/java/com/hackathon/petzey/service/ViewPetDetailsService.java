package com.hackathon.petzey.service;

import java.util.UUID;

import com.hackathon.petzey.exception.ViewPetException;
import com.hackathon.petzey.model.Pet;

public interface ViewPetDetailsService {
	
	public Pet viewPet(UUID pet_Id) throws ViewPetException;

}
