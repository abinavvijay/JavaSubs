package com.hackathon.petzey.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hackathon.petzey.controller.dto.AddAppointmentDto;
import com.hackathon.petzey.exception.AddAppointmentException;
import com.hackathon.petzey.mapper.AddAppointmentMapper;
import com.hackathon.petzey.model.Appointment;
import com.hackathon.petzey.repository.AddAppointmentRepository;
import com.hackathon.petzey.service.AddAppointmentService;

@Service
public class AddAppointmentServiceImpl implements AddAppointmentService {

	@Autowired
	private AddAppointmentRepository addRepo;
	
	@Autowired
	private AddAppointmentMapper mapper;
	
	@Override
	public Appointment addAppointment(AddAppointmentDto addDto) throws AddAppointmentException {
		// TODO Auto-generated method stub
		
		Appointment appointment = new Appointment();
		
		appointment.setAppointment_Id(addDto.getAppointment_Id());
		appointment.setAppointmentDate(addDto.getAppointmentDate());
		appointment.setTimeSlot(addDto.getTimeOfAppointment());
		appointment.setPetName(addDto.getPetname());
		appointment.setReason(addDto.getReason());
		appointment.setDoctor(addDto.getDoctorName());
		appointment.setOwner(addDto.getOwnerName());
		appointment.setClinic(addDto.getClinicName());
		
		if (addRepo.existsById(appointment.getAppointment_Id())) {

			throw new AddAppointmentException ("Patient alreday have an appointment");

	}
	appointment = addRepo.saveAndFlush(appointment);

	return mapper.convertToDto(appointment);

}

		
		

	
}
