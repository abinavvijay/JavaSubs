package com.hackathon.petzey.service;

import java.util.UUID;

import com.hackathon.petzey.exception.ViewAppointmentException;
import com.hackathon.petzey.model.Appointment;

public interface ViewAppointmentService {
	
	public Appointment viewAppointment(UUID appointment_Id) throws ViewAppointmentException;

}
