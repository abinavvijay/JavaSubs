package com.hackathon.petzey.service;

import com.hackathon.petzey.controller.dto.AddAppointmentDto;
import com.hackathon.petzey.model.Appointment;
import com.hackathon.petzey.exception.*;

public interface AddAppointmentService {
	
	public Appointment addAppointment(AddAppointmentDto addDto) throws AddAppointmentException ;


}
