package com.hackathon.petzey.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data                                    //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields. 
@Entity                                  //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {
	
	@Id             //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private UUID appointment_Id;
			
	private Date appointmentDate;
	
	private String petName;
	
	private String reason;
	
	private String doctorName;
	
	private String ownerName;
	
	private String clinicName;
	
	@Enumerated(EnumType.STRING)
	private TimeSlots timeSlot;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Clinic clinic;
	

	@OneToOne(cascade = CascadeType.ALL)
	private Doctor doctor;

	@OneToOne(cascade = CascadeType.ALL)
	private Pet pet;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Owner owner;
	
	@OneToOne(cascade = CascadeType.ALL)
	private AppointmentReport appointmentReport;


}
