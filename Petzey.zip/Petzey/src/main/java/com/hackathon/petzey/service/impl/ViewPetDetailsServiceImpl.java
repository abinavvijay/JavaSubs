package com.hackathon.petzey.service.impl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hackathon.petzey.exception.ViewAppointmentException;
import com.hackathon.petzey.exception.ViewPetException;
import com.hackathon.petzey.model.Appointment;
import com.hackathon.petzey.model.Pet;
import com.hackathon.petzey.repository.ViewPetDetailsRepository;
import com.hackathon.petzey.service.ViewPetDetailsService;

@Service
public class ViewPetDetailsServiceImpl implements ViewPetDetailsService {

	@Autowired
	private ViewPetDetailsRepository petRepo;
	
	@Override
	public Pet viewPet(UUID pet_Id) throws ViewPetException {
		// TODO Auto-generated method stub
		
		if (petRepo.existsById(pet_Id)) {
			Pet pet = petRepo.findById(pet_Id).get();
			
			
		} else {
			
			throw new ViewPetException("No appointment is created ");
		}

		
		return null;

	
	}
}
