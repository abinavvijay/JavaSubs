package com.hackathon.petzey.model;

import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data                                    //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields. 
@Entity                                  //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
@AllArgsConstructor
public class Doctor {
	
	@Id             //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID doctor_Id;
	
	private String doctorName;
	
	private int phoneNumber;
	
	private String email;
	
	private String Specalization;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Clinic clinic;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Appointment appointment;

	

}
