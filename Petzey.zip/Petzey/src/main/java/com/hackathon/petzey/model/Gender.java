package com.hackathon.petzey.model;

public enum Gender {
	Male,Female

}
