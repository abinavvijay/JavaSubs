package com.hackathon.petzey.model;

public enum TimeSlots {
	
	SLOT1_10AM,
	SLOT2_11AM,
	SLOT3_12PM,
	SLOT4_1PM,
	SLOT5_3PM,
	SLOT6_4PM,
	SLOT7_5PM,
	SLOT8_6PM
	

}
