package com.hackathon.petzey.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hackathon.petzey.model.Appointment;
import com.hackathon.petzey.model.Pet;

@Mapper
public interface ViewPetDetailsMapper {
	
	ViewPetDetailsMapper INSTANCE = Mappers.getMapper(ViewPetDetailsMapper.class); //Factory for obtaining mapper instances if no explicit component model such as CDI is configured via Mapper.componentModel().
	
	@Mapping(target = "pet_Id",  source = "pet.pet_Id")
	@Mapping(target = "owner", source = "pet.owner")
	@Mapping(target = "appointmentReport", source = "pet.appointmentReport")
	
	public Pet convertToDto(Pet pet);

}
