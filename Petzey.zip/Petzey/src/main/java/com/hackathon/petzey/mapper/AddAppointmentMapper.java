
package com.hackathon.petzey.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hackathon.petzey.model.Appointment;


@Mapper
public interface AddAppointmentMapper {
	
	AddAppointmentMapper INSTANCE = Mappers.getMapper(AddAppointmentMapper.class); //Factory for obtaining mapper instances if no explicit component model such as CDI is configured via Mapper.componentModel().
	
	@Mapping(target = "appointment_Id",  source = "appointment.appointment_Id")
	@Mapping(target = "doctorName", source = "appointment.doctorName")
	@Mapping(target = "petName", source = "appointment.petName")
	@Mapping(target = "reason", source = "appointment.reason")
	@Mapping(target = "appointmentDate", source = "appointment.appointmentDate")
	@Mapping(target = "timeSlot", source = "appointment.timeSlot")
	@Mapping(target = "ownerName", source = "appointment.ownerName")
	@Mapping(target = "clinicName", source = "appointment.clinicName")
//	@Mapping(target = "report", source = "appointment.patient.report")
	

	public Appointment convertToDto(Appointment appointment);




}
