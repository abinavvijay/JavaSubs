package com.ros.inventory.dto.stock;



import java.util.UUID;

import com.ros.inventory.model.purchaseorder.UnitOfMeasurement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class WastageStockDto {
	
	private UUID id;
	
	private String name;

	private String productCode;

	private double quantity;

	private UnitOfMeasurement unitOfMeasurement;

	private double pricePerUnit;

}
