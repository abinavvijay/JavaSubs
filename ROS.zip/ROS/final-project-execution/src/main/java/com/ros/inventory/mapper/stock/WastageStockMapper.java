package com.ros.inventory.mapper.stock;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.ros.inventory.dto.stock.WastageStockDto;
import com.ros.inventory.model.product.Product;

@Mapper
public interface WastageStockMapper {
	
	@Mapping(target = "name", source = "product.name")
	@Mapping(target = "productCode", source = "product.productCode")
	@Mapping(target = "quantity", source = "product.quantity")
	@Mapping(target = "unitOfMeasurement", source = "product.unitOfMeasurement")
	@Mapping(target = "pricePerUnit", source = "product.pricePerUnit")
	public WastageStockDto convertToDto(Product product);


}
