package com.ros.inventory.model.supplier;

public enum AddressType {
	HEAD_OFFICE, BRANCH_OFFICE, CORPORATE_OFFICE, TRADE_OFFICE
}
