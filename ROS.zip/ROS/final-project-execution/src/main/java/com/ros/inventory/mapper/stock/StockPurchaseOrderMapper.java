package com.ros.inventory.mapper.stock;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.ros.inventory.controller.dto.stock.StockPurchaseOrderDto.StockPurchaseOrderDtoBuilder;
import com.ros.inventory.model.purchaseorder.PurchaseOrder;

@Mapper
public interface StockPurchaseOrderMapper { //ModelMapper is a framework that aims to simplify object mapping, by determining how objects map to each other based on conventions. It provides type-safe and refactoring-safe API.
	
	StockPurchaseOrderMapper INSTANCE = Mappers.getMapper(StockPurchaseOrderMapper.class); //Factory for obtaining mapper instances if no explicit component model such as CDI is configured via Mapper.componentModel().

	
//	@Mapping(target = "PoNumber", source = "purchaseOrder.PoNumber")
	@Mapping(target = "createdDate", source = "purchaseOrder.createdDate")
	@Mapping(target = "supplierName", source = "purchaseOrder.supplier.supplierName")
	@Mapping(target = "total", source = "purchaseOrder.total")
	@Mapping(target = "status", source = "purchaseOrder.status")
	public StockPurchaseOrderDtoBuilder convertToDto(PurchaseOrder purchaseOrder); // the conversion logic is quick and simple. We're using the map API of the mapper, and getting the data converted without writing a single line of conversion logic.




	
	
	

	

}
