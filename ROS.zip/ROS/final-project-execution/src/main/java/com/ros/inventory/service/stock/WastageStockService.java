package com.ros.inventory.service.stock;

import com.ros.inventory.dto.stock.WastageStockDto;
import com.ros.inventory.exception.stock.NoWastageStockFoundException;

public interface WastageStockService {
	
	public WastageStockDto addWastageStock(WastageStockDto wastageStockDto) throws NoWastageStockFoundException;


}
