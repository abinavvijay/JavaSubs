package com.ros.inventory.exception.stock;

public class ThisAppointmentAlreadyExist {

}
