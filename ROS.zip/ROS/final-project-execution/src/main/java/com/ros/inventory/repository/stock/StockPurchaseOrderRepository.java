package com.ros.inventory.repository.stock;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ros.inventory.model.purchaseorder.PurchaseOrder;

public interface StockPurchaseOrderRepository extends JpaRepository<PurchaseOrder, UUID>  {


}
