package com.ros.inventory.model.purchaseorder;

public enum PurchaseOrderType {
REGULAR,
SITETRANSFER
}
