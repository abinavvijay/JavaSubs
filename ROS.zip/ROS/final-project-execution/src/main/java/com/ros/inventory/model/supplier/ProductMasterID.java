package com.ros.inventory.model.supplier;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ProductMasterID implements Serializable {

	private UUID productId;
	private UUID supplierId;

}
