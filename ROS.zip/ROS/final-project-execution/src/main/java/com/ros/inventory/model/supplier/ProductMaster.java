package com.ros.inventory.model.supplier;

import java.util.Date;
import java.util.UUID;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.ros.inventory.model.purchaseorder.Product;
import com.ros.inventory.model.purchaseorder.PurchasedProduct;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
public class ProductMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;

//	@EmbeddedId
//	private ProductMasterID pmId;

	@OneToOne
	@JoinColumn(name = "product_id", referencedColumnName = "id")
	@MapsId("productId")
	private Product product;
	
	@OneToOne
	private PurchasedProduct purchaseProduct;

	@ManyToOne
	@JoinColumn(name = "supplier_id", referencedColumnName = "id")
	@MapsId("supplierId")
	@JsonManagedReference
	private Supplier supplier;

	private String unitMeasurement;

	@NotNull
	private Double pricePerUnit;

	@NotNull
	private Double vat;

	// @Formula("price_per_unit * (100 + vat) / 100")
	private double actualPrice;

	@NotNull(message = "Effective Date is compulsory to be enetered for a new entry")
	private Date effectiveDate;

	@PrePersist
	public void calculateActualPrice() {
		this.actualPrice = pricePerUnit * (100 + vat) / 100;
	}

}
