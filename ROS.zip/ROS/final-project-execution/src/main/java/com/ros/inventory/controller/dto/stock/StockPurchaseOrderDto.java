package com.ros.inventory.controller.dto.stock;


import java.util.Date;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder                 //Generates getters for all fields, a useful toString method, and hashCode and equals implementations that checkall non-transient fields.
@AllArgsConstructor      //Will also generate setters for all non-final fields, as well as a constructor.
@NoArgsConstructor
public class StockPurchaseOrderDto { //DTO stands for Data Transfer Object, which is a design pattern. It is one of the EPA patterns which we call when we need to use such objects that encapsulate and aggregate data for transfer.
	
	private long PoNumber;
	
	private Date createdDate;
	
	private String supplierName;
	
	private double total;
	
	private String status;
	
	//private PurchaseOrderStatus purchaseOrderStatus;

}
