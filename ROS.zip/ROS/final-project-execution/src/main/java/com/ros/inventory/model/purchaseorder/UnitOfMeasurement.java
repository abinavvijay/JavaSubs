package com.ros.inventory.model.purchaseorder;

public enum UnitOfMeasurement {

	KILOGRAM,
	LITRE,
	PACKETS
	
}
