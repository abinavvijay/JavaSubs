package com.ros.inventory.model.purchaseorder;

import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.ros.inventory.model.product.Product;
import com.ros.inventory.model.supplier.Supplier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PurchasedProduct {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;

	@OneToOne
	private Product product;
	
	private float quantity;
	
//	 @ManyToOne(fetch = FetchType.EAGER, optional = false)
//	  @JoinColumn(name = "suppiler_id", nullable = false)
// 	private Supplier suppiler;
	
	
}
