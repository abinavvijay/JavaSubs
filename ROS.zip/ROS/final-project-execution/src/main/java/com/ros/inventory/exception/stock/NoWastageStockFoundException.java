package com.ros.inventory.exception.stock;

public class NoWastageStockFoundException extends Exception{

	/**
	 * @param string 
	 * 
	 */
	public NoWastageStockFoundException(String string) {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
