package com.ros.inventory.repository.stock;

public interface WastageStockRepository {
	
	


}
