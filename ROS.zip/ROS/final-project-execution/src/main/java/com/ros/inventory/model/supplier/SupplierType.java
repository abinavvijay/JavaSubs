package com.ros.inventory.model.supplier;

public enum SupplierType {

	EXTERNAL, INTERNAL

}
