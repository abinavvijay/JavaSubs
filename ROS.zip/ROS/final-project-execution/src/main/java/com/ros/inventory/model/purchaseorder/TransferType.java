package com.ros.inventory.model.purchaseorder;

public enum TransferType {

	TRANSFERIN, TRANSFEROUT;
}
