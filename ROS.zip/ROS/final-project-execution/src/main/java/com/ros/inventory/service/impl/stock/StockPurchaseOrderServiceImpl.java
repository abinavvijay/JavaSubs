package com.ros.inventory.service.impl.stock;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ros.inventory.controller.dto.stock.StockPurchaseOrderDto;
import com.ros.inventory.mapper.stock.StockPurchaseOrderMapper;
import com.ros.inventory.model.purchaseorder.PurchaseOrder;
import com.ros.inventory.repository.stock.StockPurchaseOrderRepository;
import com.ros.inventory.service.stock.StockPurchaseOrderService;

@Service  //Spring @Service annotation is used with classes that provide some business functionalities. 
public class StockPurchaseOrderServiceImpl implements StockPurchaseOrderService {
	
	@Autowired //In the spring boot, the @Autowired annotation is used in setter methods to inject the value of the class properties.
	private StockPurchaseOrderRepository stockRepo;
	
	@Autowired
	private StockPurchaseOrderMapper mapper;
	
	@Override // annotation informs the compiler that the element is meant to override an element declared in a superclass. Overriding methods will be discussed in Interfaces and Inheritance. 
	public List<StockPurchaseOrderDto> viewPurchaseOrder() throws Exception {
		List<PurchaseOrder> stockPurchaseOrder = stockRepo.findAll();
		StockPurchaseOrderDto sdto = new StockPurchaseOrderDto();
		List<StockPurchaseOrderDto> sDtos = new ArrayList<>();
			
	
		if (stockPurchaseOrder.isEmpty()) {
			throw new Exception(" type Purchase does not exist. Please make a purchase");	
	}
		for (PurchaseOrder stock : stockPurchaseOrder) {
			sdto = mapper.convertToDto(stock);
		sDtos.add(sdto);
		}
		return sDtos;
	}

	@Override
	public Object viewPurchaseOrder(UUID any) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
