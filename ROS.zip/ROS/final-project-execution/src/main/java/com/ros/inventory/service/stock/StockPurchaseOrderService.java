package com.ros.inventory.service.stock;

import java.util.List;
import java.util.UUID;

import com.ros.inventory.controller.dto.stock.StockPurchaseOrderDto.StockPurchaseOrderDtoBuilder;

public interface StockPurchaseOrderService {
	
	public List<StockPurchaseOrderDtoBuilder> viewPurchaseOrder() throws  Exception; // 

	public Object viewPurchaseOrder(UUID any);
	
																				//Exception is an abnormal condition. In Java, an exception is an event that disrupts the normal flow of the program. It is an object which is thrown at runtime.

}
