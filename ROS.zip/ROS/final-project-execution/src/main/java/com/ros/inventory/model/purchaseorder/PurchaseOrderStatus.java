package com.ros.inventory.model.purchaseorder;

public enum PurchaseOrderStatus {
	
	DRAFT,
	SUBMITTED,
	PENDINGAPPROVAL,
	APPROVED,
	REJECTED,
	CANCELLED

}
