package com.ros.inventory.service.impl.stock;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;

import com.ros.inventory.dto.stock.WastageStockDto;
import com.ros.inventory.exception.stock.NoWastageStockFoundException;
import com.ros.inventory.mapper.stock.WastageStockMapper;
import com.ros.inventory.model.product.Product;
import com.ros.inventory.repository.stock.WastageStockRepository;

public class WastageStockServiceImpl {
	
	@Autowired
	private WastageStockRepository wastageRepo;
	
	@Autowired
	private WastageStockMapper mapper1;
	
	public WastageStockDto addWastageStock(WastageStockDto wastageStockDto) throws NoWastageStockFoundException {
		Product product = new Product();
		product.setId(wastageStockDto.getId());
		product.setName(wastageStockDto.getName());
		product.setProductCode(wastageStockDto.getProductCode());
		product.setQuantity(wastageStockDto.getQuantity());
		product.setUnitOfMeasurement(wastageStockDto.getUnitOfMeasurement());
		product.setPricePerUnit(wastageStockDto.getPricePerUnit());



		UUID dtoId = wastageStockDto.getId();
		if (dtoId != null) {
			if (wastageRepo.existsById(wastageStockDto.getId()))

				throw new NoWastageStockFoundException("wastage already added");

		}
		product = wastageRepo.saveAndFlush(product);

		return mapper1.convertToDto(product);

	}
	
	
//	@Override
//	public SupplierDto addInternalSupplier(InternalSupplierDto internalSupplierDto)
//			throws ThisExternalSupplierIsAlreadyExist {
//		Supplier supplier = new Supplier();
//		supplier.setType(internalSupplierDto.getType());
//		supplier.setSupplierName(internalSupplierDto.getSupplierName());
//		supplier.setPrimaryContact(internalSupplierDto.getPrimaryContact());
//		supplier.setBasicInformation(internalSupplierDto.getBasicInformation());
//
//		UUID dtoId = internalSupplierDto.getId();
//		if (dtoId != null) {
//			if (supplierRepo.existsById(internalSupplierDto.getId()))
//
//				throw new ThisExternalSupplierIsAlreadyExist("Supplier with that Id already Exists");
//
//		}
//		product = wastageRepo.saveAndFlush(product);
//
//		return mapper.convertToDto(supplier);
//
//	}

}
