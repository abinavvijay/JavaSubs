package com.ros.inventory.controller.stock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ros.inventory.service.impl.stock.StockPurchaseOrderServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

@RestController  // is a convenience annotation for creating Restful controllers. It is a specialization of @Component and is autodetected through classpath scanning. It adds the @Controller and @ResponseBody annotations. It converts the response to JSON or XML.
@CrossOrigin("*") // a cross-origin HTTP request is a request to a specific resource, which is located at a different origin, namely a domain, protocol and port, than the one of the client performing the request.
@RequestMapping("/stock")  //@RequestMapping annotation is used for mapping web requests to particular handler classes or handler methods. The classes or methods that are annotated with @RequestMapping will be scanned and registered as the URI mappings for that specific class or method
public class StockPurchaseOrderController {
	
	@Autowired //The @Autowired annotation is auto wire the bean by matching data type if spring container find more than one beans same data type then it find by name. You can use @Autowired annotation on setter methods to get ref id of the <property> element in XML configuration file
	private StockPurchaseOrderServiceImpl service;
	
	
	@Operation(summary = "View PurchaseOrder List")
	@GetMapping(value = "/view purchaseOrder")  // These annotations will map the HTTP web requests to the specific handler methods. Annotation for mapping HTTP GET requests onto specific handler methods.
	public ResponseEntity<?> getPurchaseOrderList() throws Exception {
		ResponseEntity<?> response = null;

		try {
			response = new ResponseEntity<>(service.viewPurchaseOrder(), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
		}

		return response;
	}

}
