package com.ros.inventory;


import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.ros.inventory.controller.StockPurchaseOrderController;
import com.ros.inventory.dto.stock.StockPurchaseOrderDto;
import com.ros.inventory.mapper.stock.StockPurchaseOrderMapper;
import com.ros.inventory.model.purchaseorder.PurchaseOrder;
import com.ros.inventory.repository.stock.StockPurchaseOrderRepository;
import com.ros.inventory.service.stock.StockPurchaseOrderService;


@WebMvcTest(value = StockPurchaseOrderController.class )
public class StockPurchaseOrderTest {


@Autowired
private MockMvc mockMvc;


@MockBean
private StockPurchaseOrderMapper mapper;

@MockBean
private StockPurchaseOrderService service;



@MockBean
private StockPurchaseOrderRepository stockRepo;

@Test
public List<StockPurchaseOrderDto> viewPurchaseOrder() throws Exception {
	String urlString = "/purchaseOrder/stockPurchaseOrder/16b59e34-d90a-4238-899a-75d30902e146";
	List<PurchaseOrder> PurchaseOrder = stockRepo.findAll();
	StockPurchaseOrderDto sdto = new StockPurchaseOrderDto();
  	List<StockPurchaseOrderDto> sDtos = new ArrayList<>();
		

	if (PurchaseOrder.isEmpty()) {
		throw new Exception(" type Purchase does not exist. Please make a purchase");	
}
	for (PurchaseOrder stock : PurchaseOrder) {
	
	Mockito.when(service.viewPurchaseOrder(Mockito.any(UUID.class))).thenReturn(sdto);
	RequestBuilder requestBuilder = MockMvcRequestBuilders.get(urlString);
	MvcResult result = mockMvc.perform(requestBuilder).andReturn();
	String expectedString ="[\r\n" + 
			"  {\r\n" + 
			"    \"poNumber\": 852,\r\n" + 
			"    \"purchaseOrderDate\": \"2022-03-12T07:16:32.498+00:00\",\r\n" + 
			"    \"supplierName\": \"IMTIYAZ\",\r\n" + 
			"    \"value\": 52,\r\n" + 
			"    \"purchaseOrderType\": \"APPROVED\",\r\n" + 
			"    \"invoiceStatus\": null\r\n" + 
			"  },\r\n" + 
			"  {\r\n" + 
			"    \"poNumber\": 456,\r\n" + 
			"    \"purchaseOrderDate\": \"2022-03-22T07:16:32.498+00:00\",\r\n" + 
			"    \"supplierName\": \"FARAZ\",\r\n" + 
			"    \"value\": 6543,\r\n" + 
			"    \"purchaseOrderType\": \"APPROVED\",\r\n" + 
			"    \"invoiceStatus\": null\r\n" + 
			"  }\r\n" + 
			"]";
	

	sdto = mapper.convertToDto(stock);
	sDtos.add(sdto);
	}
	return sDtos;
}

}
